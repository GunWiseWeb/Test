<?php
if ( !defined( '\\IPS\\SUITE_UNIQUE_KEY' ) ) { header( ( $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.0' ) . ' 403 Forbidden' ); exit; }

/**
 * v1.0.160 PART 1 of 1 - Update setupWizardStep5 template body to
 * adapt framing based on $values['is_completed']:
 *
 *   First-time finish (is_completed = false):
 *     - "You're almost done!" intro text
 *     - "Step 5 of 5: Preview & Save" heading
 *     - "Finish Setup" green button
 *
 *   Revisit after completion (is_completed = true):
 *     - Top banner: "You completed this wizard on [date]. Make changes
 *       and Save Changes, or click any earlier step to edit."
 *     - "Step 5 of 5: Current Configuration" heading
 *     - "Save Changes" button (does the same thing as Finish; also
 *       updates wizard_completed_at to now)
 *
 * v1.0.239: CSS is now embedded directly (was previously read from DB
 * via preg_match which was fragile). max-width fixed to 1100px to match
 * other wizard steps.
 */

$step5Tpl = <<<'TEMPLATE_EOT'
<div class="gdSetupWizard">

	<header class="gdSetupWizard__header">
		<div class="gdSetupWizard__heading">
			<h2>Feed Setup Wizard</h2>
			{{if $values['is_completed']}}
				<p>You can update any step here and save changes to apply them. Use the progress bar or Back button to jump to a different step.</p>
			{{else}}
				<p>You're almost done! Review your configuration below, then hit Finish to lock it in. You can always come back and re-run the wizard to reconfigure.</p>
			{{endif}}
		</div>
	</header>

	<nav class="gdSetupWizard__progress" aria-label="Wizard progress">
		<ol class="gdSetupWizard__steps">
			{{foreach $wizardData['steps'] as $s}}
				{{if $s['num'] < $wizardData['currentStep']}}
					{{$cls = 'is-done';}}
				{{elseif $s['num'] === $wizardData['currentStep']}}
					{{$cls = 'is-current';}}
				{{else}}
					{{$cls = 'is-upcoming';}}
				{{endif}}
				<li class="gdSetupWizard__step {$cls}">
					<span class="gdSetupWizard__stepNum">{$s['num']}</span>
					<span class="gdSetupWizard__stepLabel">{$s['label']}</span>
					<span class="gdSetupWizard__stepDesc">{$s['desc']}</span>
				</li>
			{{endforeach}}
		</ol>
	</nav>

	{{if $values['is_completed']}}
	<div class="gdSetupWizard__flash gdSetupWizard__flash--info">
		<strong>&#10003; Wizard previously completed</strong>
		Originally finished {$values['completed_at']}. You can review your current setup below or navigate back to any step to make changes. Click <em>Save Changes</em> at the bottom to re-apply your configuration.
	</div>
	{{endif}}

	{{if count($values['errors']) > 0}}
	<div class="gdSetupWizard__flash gdSetupWizard__flash--error">
		<strong>Could not finalize:</strong>
		<ul>
		{{foreach $values['errors'] as $err}}
			<li>{$err}</li>
		{{endforeach}}
		</ul>
	</div>
	{{endif}}

	<section class="gdSetupWizard__card">
		{{if $values['is_completed']}}
			<h3>Step 5 of {$wizardData['totalSteps']}: Current Configuration</h3>
			<p>This is your current feed configuration. To change anything, use the progress bar above or click Back to navigate to an earlier step. Click Save Changes at the bottom to re-apply.</p>
		{{else}}
			<h3>Step 5 of {$wizardData['totalSteps']}: Preview &amp; Save</h3>
			<p>Below is a summary of how your feed will be imported. Review the field mapping, peek at how the first records would look once normalized, and then hit Finish.</p>
		{{endif}}
	</section>

	<section class="gdSetupWizard__card">
		<h4>Field Mapping</h4>
		<p>Required fields (and any optional fields you mapped) are listed below. Defaults will be applied to every record.</p>
		<table class="gdSetupWizard__summaryTable">
			<thead>
				<tr>
					<th>Our field</th>
					<th>Source</th>
					<th>Value</th>
				</tr>
			</thead>
			<tbody>
				{{foreach $values['mapping_rows'] as $row}}
					{{if $row['source'] === 'feed'}}
						{{$srcLabel = 'From feed';}}
						{{$srcCls = 'gdSetupWizard__src--feed';}}
					{{elseif $row['source'] === 'default'}}
						{{$srcLabel = 'Default';}}
						{{$srcCls = 'gdSetupWizard__src--default';}}
					{{else}}
						{{$srcLabel = 'Not mapped';}}
						{{$srcCls = 'gdSetupWizard__src--none';}}
					{{endif}}
					<tr>
						<td>
							<code>{$row['slug']}</code>
							{{if $row['req'] === 'required'}}<span class="gdSetupWizard__reqBadge gdSetupWizard__reqBadge--required">Required</span>{{endif}}
							{{if $row['req'] === 'conditional'}}<span class="gdSetupWizard__reqBadge gdSetupWizard__reqBadge--conditional">Conditional</span>{{endif}}
							<div class="gdSetupWizard__canonLabel">{$row['label']}</div>
						</td>
						<td><span class="gdSetupWizard__srcBadge {$srcCls}">{$srcLabel}</span></td>
						<td>
							{{if $row['source'] === 'feed'}}
								<code class="gdSetupWizard__sample">{$row['value']}</code>
							{{elseif $row['source'] === 'default'}}
								<code class="gdSetupWizard__sample gdSetupWizard__sample--default">{$row['value']}</code>
							{{else}}
								<span class="gdSetupWizard__samplePlaceholder">&mdash;</span>
							{{endif}}
						</td>
					</tr>
				{{endforeach}}
			</tbody>
		</table>
	</section>

	{{if count($values['preview_records']) > 0}}
	<section class="gdSetupWizard__card">
		<h4>Sample import preview</h4>
		<p>Here's how the first {$values['preview_count']} records would look after we apply your mapping. Records flagged with errors won't actually import.</p>
		<div class="gdSetupWizard__previewWrap">
			<table class="gdSetupWizard__previewTable">
				<thead>
					<tr>
						<th>#</th>
						{{foreach $values['preview_columns'] as $col}}
							<th>{$col['label']}</th>
						{{endforeach}}
						<th>Status</th>
					</tr>
				</thead>
				<tbody>
					{{foreach $values['preview_records'] as $rec}}
						{{if $rec['has_errors']}}
							{{$badgeCls = 'gdSetupWizard__statusBadge gdSetupWizard__status--error';}}
							{{$badgeLabel = 'Errors';}}
						{{elseif $rec['has_warnings']}}
							{{$badgeCls = 'gdSetupWizard__statusBadge gdSetupWizard__status--warn';}}
							{{$badgeLabel = 'Warnings';}}
						{{else}}
							{{$badgeCls = 'gdSetupWizard__statusBadge gdSetupWizard__status--ok';}}
							{{$badgeLabel = 'Valid';}}
						{{endif}}
						<tr>
							<td>{$rec['row']}</td>
							{{foreach $values['preview_columns'] as $col}}
								{{$cell = isset( $rec['cells'][ $col['slug'] ] ) ? $rec['cells'][ $col['slug'] ] : '';}}
								<td>
									{{if $cell !== ''}}
										<code class="gdSetupWizard__sample">{$cell}</code>
									{{else}}
										<span class="gdSetupWizard__samplePlaceholder">&mdash;</span>
									{{endif}}
								</td>
							{{endforeach}}
							<td><span class="{$badgeCls}">{$badgeLabel}</span></td>
						</tr>
					{{endforeach}}
				</tbody>
			</table>
		</div>
	</section>
	{{endif}}

	<section class="gdSetupWizard__card">
		<h4>Validation summary</h4>
		<div class="gdSetupWizard__step5Stats">
			<div class="gdSetupWizard__stat gdSetupWizard__stat--good">
				<span class="gdSetupWizard__statNum">{$values['valid_records']}</span>
				<span class="gdSetupWizard__statLabel">Valid records</span>
			</div>
			<div class="gdSetupWizard__stat gdSetupWizard__stat--bad">
				<span class="gdSetupWizard__statNum">{$values['error_records']}</span>
				<span class="gdSetupWizard__statLabel">With errors</span>
			</div>
			<div class="gdSetupWizard__stat gdSetupWizard__stat--warn">
				<span class="gdSetupWizard__statNum">{$values['warning_records']}</span>
				<span class="gdSetupWizard__statLabel">With warnings</span>
			</div>
		</div>
		{{if $values['has_errors']}}
		<div class="gdSetupWizard__warning">
			<strong>Heads up:</strong> Some records had validation errors. You can still finish the wizard - those records will be skipped at import time. Fix the underlying issues in your feed (or via <a href="{$values['urls']['step3']}">step 3 mapping</a>) and re-run the wizard later to revalidate.
		</div>
		{{endif}}
	</section>

	{{if !$values['is_completed']}}
	<section class="gdSetupWizard__card gdSetupWizard__card--info">
		<h4>What happens after Finish?</h4>
		<ul class="gdSetupWizard__nextSteps">
			<li>Your feed configuration is saved and the import scheduler will pick it up on its next run.</li>
			<li>You'll land on the <strong>Feed Settings</strong> page where you can upload feed files (manual mode) or check your import history.</li>
			<li>You can re-run this wizard anytime from the sidebar to reconfigure from scratch.</li>
		</ul>
	</section>
	{{endif}}

	<form method="post" action="{$values['urls']['save_step5']}" class="gdSetupWizard__form" data-step="5">
		<input type="hidden" name="csrfKey" value="{$values['csrfKey']}">

		<div class="gdSetupWizard__actions">
			<a href="{$values['urls']['step4']}" class="gdSetupWizard__btn gdSetupWizard__btn--ghost">&larr; Back to Step 4</a>
			{{if $values['is_completed']}}
				<button type="submit" class="gdSetupWizard__btn gdSetupWizard__btn--primary">&#10003; Save Changes</button>
			{{else}}
				<button type="submit" class="gdSetupWizard__btn gdSetupWizard__btn--primary">&#10003; Finish Setup</button>
			{{endif}}
		</div>
	</form>

</div>
<style>
.gdSetupWizard {
	font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
	color: #0f172a;
	max-width: 1100px;
	margin: 0 auto;
	padding: 24px 16px 80px;
}
.gdSetupWizard *, .gdSetupWizard *::before, .gdSetupWizard *::after { box-sizing: border-box; }

.gdSetupWizard__header { margin-bottom: 24px; }
.gdSetupWizard__header h2 { margin: 0 0 8px; font-size: 1.65em; font-weight: 700; }
.gdSetupWizard__header p { margin: 0; color: #64748b; max-width: 700px; }

.gdSetupWizard__progress { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; margin-bottom: 24px; }
.gdSetupWizard__steps { display: grid; grid-template-columns: repeat(5, 1fr); gap: 12px; margin: 0; padding: 0; list-style: none; }
.gdSetupWizard__step { display: flex; flex-direction: column; gap: 4px; padding: 10px 12px; border-radius: 8px; background: #fff; border: 1px solid #e2e8f0; }
.gdSetupWizard__step.is-current { background: #eff6ff; border-color: #2563eb; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }
.gdSetupWizard__step.is-done { background: #f0fdf4; border-color: #86efac; }
.gdSetupWizard__step.is-upcoming { opacity: 0.65; }
.gdSetupWizard__stepNum { display: inline-flex; align-items: center; justify-content: center; width: 22px; height: 22px; border-radius: 50%; background: #cbd5e1; color: #fff; font-size: 11px; font-weight: 700; }
.gdSetupWizard__step.is-current .gdSetupWizard__stepNum { background: #2563eb; }
.gdSetupWizard__step.is-done .gdSetupWizard__stepNum { background: #16a34a; }
.gdSetupWizard__stepLabel { font-size: 13px; font-weight: 600; }
.gdSetupWizard__stepDesc { font-size: 11.5px; color: #64748b; }

.gdSetupWizard__flash { border-radius: 8px; padding: 14px 16px; margin-bottom: 16px; font-size: 14px; }
.gdSetupWizard__flash strong { display: block; margin-bottom: 4px; }
.gdSetupWizard__flash--success { background: #f0fdf4; border: 1px solid #86efac; color: #14532d; }
.gdSetupWizard__flash--error { background: #fef2f2; border: 1px solid #fca5a5; color: #7f1d1d; }
.gdSetupWizard__flash--error ul { margin: 4px 0 0; padding-left: 20px; }
.gdSetupWizard__flash--error li { margin: 2px 0; }
.gdSetupWizard__flash--info { background: #eff6ff; border: 1px solid #93c5fd; color: #1e3a8a; }
.gdSetupWizard__flash--info em { font-style: normal; font-weight: 600; }

.gdSetupWizard__card { background: #fff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 20px; margin-bottom: 16px; }
.gdSetupWizard__card h3 { margin: 0 0 8px; font-size: 1.1em; font-weight: 700; }
.gdSetupWizard__card h4 { margin: 0 0 12px; font-size: 1em; font-weight: 600; color: #1e40af; padding-bottom: 8px; border-bottom: 1px solid #e2e8f0; }
.gdSetupWizard__card p { margin: 0 0 12px; color: #475569; font-size: 14px; }
.gdSetupWizard__card p:last-child { margin-bottom: 0; }
.gdSetupWizard__card--info { background: #eff6ff; border-color: #93c5fd; }
.gdSetupWizard__card--info h4 { color: #1e3a8a; border-bottom-color: #bfdbfe; }
.gdSetupWizard__card--info p { color: #1e40af; }

.gdSetupWizard__nextSteps { margin: 0; padding-left: 22px; font-size: 14px; color: #1e40af; }
.gdSetupWizard__nextSteps li { margin: 6px 0; line-height: 1.5; }

.gdSetupWizard__summaryTable, .gdSetupWizard__previewTable { width: 100%; border-collapse: collapse; font-size: 13px; }
.gdSetupWizard__summaryTable th, .gdSetupWizard__previewTable th {
	text-align: left; padding: 8px 10px; background: #f8fafc; font-weight: 600; color: #334155;
	font-size: 11.5px; text-transform: uppercase; letter-spacing: 0.4px;
}
.gdSetupWizard__summaryTable td, .gdSetupWizard__previewTable td {
	padding: 10px; border-top: 1px solid #f1f5f9; vertical-align: top;
}

.gdSetupWizard__summaryTable code {
	font-family: 'JetBrains Mono', ui-monospace, monospace; font-size: 12px;
	background: #f1f5f9; color: #1e40af; padding: 2px 7px; border-radius: 3px; font-weight: 600;
}
.gdSetupWizard__canonLabel { font-size: 11.5px; color: #64748b; margin-top: 2px; }

.gdSetupWizard__reqBadge {
	display: inline-block; padding: 1px 7px; border-radius: 10px;
	font-size: 10.5px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.3px;
	margin-left: 6px;
}
.gdSetupWizard__reqBadge--required { background: #fee2e2; color: #991b1b; }
.gdSetupWizard__reqBadge--conditional { background: #fef3c7; color: #92400e; }

.gdSetupWizard__srcBadge {
	display: inline-block; padding: 3px 10px; border-radius: 12px;
	font-size: 11.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.4px;
}
.gdSetupWizard__src--feed { background: #dcfce7; color: #14532d; }
.gdSetupWizard__src--default { background: #ede9fe; color: #6d28d9; }
.gdSetupWizard__src--none { background: #f1f5f9; color: #64748b; }

.gdSetupWizard__sample {
	font-family: 'JetBrains Mono', ui-monospace, monospace; font-size: 11.5px;
	background: #f1f5f9; color: #475569; padding: 3px 8px; border-radius: 4px;
	display: inline-block; max-width: 240px;
	overflow: hidden; text-overflow: ellipsis; white-space: nowrap; vertical-align: middle;
}
.gdSetupWizard__sample--default { background: #ede9fe; color: #6d28d9; }
.gdSetupWizard__samplePlaceholder { color: #cbd5e1; font-size: 13px; }

.gdSetupWizard__previewWrap { overflow-x: auto; }
.gdSetupWizard__previewTable { min-width: 100%; }
.gdSetupWizard__previewTable td { white-space: nowrap; }

.gdSetupWizard__statusBadge {
	display: inline-block; padding: 3px 10px; border-radius: 12px;
	font-size: 11.5px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.4px;
}
.gdSetupWizard__status--ok { background: #dcfce7; color: #14532d; }
.gdSetupWizard__status--warn { background: #fef3c7; color: #92400e; }
.gdSetupWizard__status--error { background: #fee2e2; color: #991b1b; }

.gdSetupWizard__step5Stats { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 12px; }
.gdSetupWizard__stat { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px 14px; display: flex; flex-direction: column; gap: 2px; }
.gdSetupWizard__stat--good { background: #f0fdf4; border-color: #86efac; }
.gdSetupWizard__stat--good .gdSetupWizard__statNum { color: #14532d; }
.gdSetupWizard__stat--bad { background: #fef2f2; border-color: #fca5a5; }
.gdSetupWizard__stat--bad .gdSetupWizard__statNum { color: #991b1b; }
.gdSetupWizard__stat--warn { background: #fffbeb; border-color: #fcd34d; }
.gdSetupWizard__stat--warn .gdSetupWizard__statNum { color: #92400e; }
.gdSetupWizard__statNum { font-size: 22px; font-weight: 700; color: #0f172a; }
.gdSetupWizard__statLabel { font-size: 12px; color: #64748b; }

.gdSetupWizard__warning {
	background: #fffbeb; border: 1px solid #fcd34d; border-radius: 8px;
	padding: 12px 16px; font-size: 13.5px; color: #78350f;
}
.gdSetupWizard__warning strong { color: #78350f; }
.gdSetupWizard__warning a { color: #78350f; text-decoration: underline; }

.gdSetupWizard__form { margin-top: 8px; }
.gdSetupWizard__actions { display: flex; justify-content: space-between; gap: 8px; flex-wrap: wrap; }
.gdSetupWizard__btn {
	padding: 12px 24px; border-radius: 8px; font-weight: 700; font-size: 15px;
	border: 1px solid transparent; text-decoration: none; cursor: pointer; transition: all 0.15s;
}
.gdSetupWizard__btn--primary { background: #16a34a; color: #fff; border-color: #16a34a; }
.gdSetupWizard__btn--primary:hover { background: #15803d; border-color: #15803d; }
.gdSetupWizard__btn--ghost { background: #fff; color: #475569; border-color: #cbd5e1; font-weight: 600; }
.gdSetupWizard__btn--ghost:hover { background: #f8fafc; color: #0f172a; }

@media (max-width: 1100px) {
	.gdSetupWizard__step5Stats { grid-template-columns: 1fr 1fr; }
}
@media (max-width: 720px) {
	.gdSetupWizard { padding: 16px 12px 60px; }
	.gdSetupWizard__steps { grid-template-columns: 1fr 1fr; }
	.gdSetupWizard__step5Stats { grid-template-columns: 1fr; }
	.gdSetupWizard__summaryTable thead { display: none; }
	.gdSetupWizard__summaryTable tr { display: block; padding: 12px 0; border-top: 1px solid #f1f5f9; }
	.gdSetupWizard__summaryTable td { display: block; padding: 4px 10px; }
	.gdSetupWizard__actions { flex-direction: column-reverse; align-items: stretch; }
	.gdSetupWizard__actions .gdSetupWizard__btn { width: 100%; text-align: center; }
}
@media (max-width: 480px) { .gdSetupWizard__steps { grid-template-columns: 1fr; } }
</style>
TEMPLATE_EOT;

try
{
    \IPS\Db::i()->update( 'core_theme_templates',
        [
            'template_data'    => '$wizardData,$values',
            'template_content' => $step5Tpl,
            'template_updated' => time(),
        ],
        [ 'template_app=? AND template_location=? AND template_group=? AND template_name=?',
          'gddealer', 'front', 'dealers', 'setupWizardStep5' ]
    );
}
catch ( \Throwable $e )
{
    try { \IPS\Log::log( 'templates_10160_part1.php update failed: ' . $e->getMessage(), 'gddealer_upg_10160' ); }
    catch ( \Throwable ) {}
}
