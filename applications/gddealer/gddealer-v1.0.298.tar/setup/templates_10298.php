<?php
/**
 * v1.0.298 — dealerProfile overlay: native IPS member-profile layout
 */

namespace IPS\gddealer\setup;

if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
    header( ( $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.0' ) . ' 403 Forbidden' );
    exit;
}

$dealerProfileTpl = <<<'TEMPLATE_EOT'
<style>
#ipsLayout_mainArea { max-width: 100% !important; }
#ipsLayout_main { max-width: 100% !important; }
</style>
<div class="gdProfile2" style="--gd-dealer-brand:{$data['dealer']['brand_color']}" {{if $data['open_listings_tab']}}data-gd-default="listings"{{endif}}>

	<header class="ipsPageHeader ipsBox ipsBox--profileHeader ipsPull i-margin-bottom_block">
		<div class="ipsCoverPhoto ipsCoverPhoto--profile">
			{{if $data['dealer']['cover_url_custom']}}
			<div class="ipsCoverPhoto__container"><img class="ipsCoverPhoto__image" src="{$data['dealer']['cover_url_custom']}" alt=""></div>
			{{else}}
			<div class="ipsCoverPhoto__container"><div class="gdProfile2__coverFallback"></div></div>
			{{endif}}
		</div>
		<div class="ipsCoverPhotoMeta">
			<div class="ipsCoverPhoto__avatar">
				{{if $data['dealer']['logo_url']}}
				<span class="ipsUserPhoto ipsUserPhoto--large"><img src="{$data['dealer']['logo_url']}" alt=""></span>
				{{elseif $data['dealer']['avatar_url']}}
				<span class="ipsUserPhoto ipsUserPhoto--large"><img src="{$data['dealer']['avatar_url']}" alt=""></span>
				{{else}}
				<span class="ipsUserPhoto ipsUserPhoto--large gdProfile2__monogram">{expression="strtoupper(substr($data['dealer']['dealer_name'], 0, 1))"}</span>
				{{endif}}
			</div>
			<div class="ipsCoverPhoto__titles">
				<div class="ipsCoverPhoto__title">
					<h1>{$data['dealer']['dealer_name']}</h1>
					{{if $data['dealer']['verified']}}<span class="ipsBadge ipsBadge--positive"><i class="fa-solid fa-shield-halved"></i> FFL Verified</span>{{endif}}
					<span class="ipsBadge gdProfile2__tierBadge" style="{expression="'background:' . $data['dealer']['tier_color']"}">{$data['dealer']['tier_label']}</span>
				</div>
				<p class="ipsCoverPhoto__desc">{{if $data['dealer']['address_city_state']}}<i class="fa-solid fa-location-dot"></i> {$data['dealer']['address_city_state']} &middot; {{endif}}<span style="{expression="'color:' . ($data['stats']['rating_color'] ?? '#1E40AF')"}">{$data['stats']['avg_overall']} &#9733; ({expression="number_format($data['stats']['total'])"})</span> &middot; {$data['dealer']['listing_count']} listings</p>
			</div>
		</div>
	</header>

	{{if !$data['dealer']['is_active']}}
	<div class="ipsMessage ipsMessage--warning i-margin-bottom_3">
		<strong>This dealer&rsquo;s listings are currently inactive.</strong>
		<p>Inventory and pricing are not being updated. Existing reviews and ratings are shown below for reference.</p>
	</div>
	{{endif}}

	{{if $data['customer_dispute']}}
	<div class="ipsMessage ipsMessage--error i-margin-bottom_3">
		<h2>{$data['dealer']['dealer_name']} has contested your review</h2>
		<p>The dealer has submitted a contest against the review you left.
			{{if $data['customer_dispute']['deadline_formatted']}}You have until <strong>{$data['customer_dispute']['deadline_formatted']}</strong> to respond, or the contest will be automatically resolved in the dealer&rsquo;s favor.{{endif}}</p>
		{{if $data['customer_dispute']['dispute_reason']}}
		<div class="gdProfile2__disputeQuote">
			<div class="gdProfile2__disputeQuoteLabel">Dealer&rsquo;s reason</div>
			<div>{$data['customer_dispute']['dispute_reason']}</div>
		</div>
		{{endif}}
		{{if $data['customer_dispute']['dispute_evidence']}}
		<div class="gdProfile2__disputeQuote">
			<div class="gdProfile2__disputeQuoteLabel">Dealer&rsquo;s evidence</div>
			<div>{$data['customer_dispute']['dispute_evidence']}</div>
		</div>
		{{endif}}
		<form method="post" action="{$data['customer_dispute']['respond_url']}">
			<input type="hidden" name="csrfKey" value="{$data['csrf_key']}">
			<div class="i-margin-top_2">
				<label><strong>Your response</strong></label>
				{$data['customer_dispute']['response_editor_html']}
			</div>
			<div class="i-margin-top_2">
				<label><strong>Supporting evidence (optional)</strong></label>
				{$data['customer_dispute']['evidence_editor_html']}
			</div>
			<button type="submit" class="ipsButton ipsButton--primary i-margin-top_2">Submit My Response</button>
		</form>
	</div>
	{{endif}}

	<div class="ipsProfile ipsProfile--profile">
		<aside class="ipsProfile__aside">
			<div class="ipsProfile__sticky-outer"><div class="ipsProfile__sticky-inner">

				<div class="ipsWidget ipsWidget--storeInfo">
					<h3 class="ipsWidget__header">{lang="gddealer_store_info"}</h3>
					<div class="ipsWidget__content ipsWidget__padding">
						{{if $data['dealer']['public_phone']}}
						<div class="gdStoreRow"><i class="fa-solid fa-phone"></i> <a href="tel:{$data['dealer']['public_phone']}">{$data['dealer']['public_phone']}</a></div>
						{{endif}}
						{{if $data['dealer']['website_url']}}
						<div class="gdStoreRow"><i class="fa-solid fa-globe"></i> <a href="{$data['dealer']['website_url']}" target="_blank" rel="nofollow noopener">{lang="gddealer_visit_website"}</a></div>
						{{endif}}
						{{if $data['dealer']['public_email']}}
						<div class="gdStoreRow"><i class="fa-solid fa-envelope"></i> <a href="mailto:{$data['dealer']['public_email']}">{$data['dealer']['public_email']}</a></div>
						{{elseif $data['dealer']['contact_email']}}
						<div class="gdStoreRow"><i class="fa-solid fa-envelope"></i> <a href="mailto:{$data['dealer']['contact_email']}">Contact</a></div>
						{{endif}}
						{{if $data['dealer']['address_public']}}
						<div class="gdStoreRow"><i class="fa-solid fa-location-dot"></i> {$data['dealer']['address_line']}</div>
						{{endif}}
						{{if $data['dealer']['has_hours']}}
						<div class="gdStoreHours">
							<div class="gdStoreRow gdStoreRow--header"><i class="fa-regular fa-clock"></i> Hours</div>
							<table class="gdStoreHours__table">
								{{foreach $data['dealer']['hours'] as $day}}
								<tr class="{{if $day['is_today']}}gdStoreHours__today{{endif}}">
									<td>{$day['label']}</td>
									<td>{{if $day['closed']}}Closed{{else}}{$day['open']} &ndash; {$day['close']}{{endif}}</td>
								</tr>
								{{endforeach}}
							</table>
						</div>
						{{endif}}
						{{if count($data['dealer']['payment_methods']) > 0}}
						<div class="gdStoreRow"><i class="fa-solid fa-credit-card"></i>
							{{foreach $data['dealer']['payment_methods'] as $pm}}<span class="gdStorePm">{$pm['label']}</span> {{endforeach}}
						</div>
						{{endif}}
						{{if count($data['dealer']['socials']) > 0}}
						<div class="gdStoreSocials">
							{{foreach $data['dealer']['socials'] as $social}}
							<a href="{$social['url']}" target="_blank" rel="noopener" class="gdStoreSocials__link" title="{$social['network']}">
								{{if $social['network'] === 'facebook'}}<i class="fa-brands fa-facebook"></i>
								{{elseif $social['network'] === 'instagram'}}<i class="fa-brands fa-instagram"></i>
								{{elseif $social['network'] === 'youtube'}}<i class="fa-brands fa-youtube"></i>
								{{elseif $social['network'] === 'twitter'}}<i class="fa-brands fa-x-twitter"></i>
								{{elseif $social['network'] === 'tiktok'}}<i class="fa-brands fa-tiktok"></i>
								{{endif}}
							</a>
							{{endforeach}}
						</div>
						{{endif}}
					</div>
				</div>

				<div class="ipsWidget ipsWidget--dealerNav">
					<h3 class="ipsWidget__header">{lang="gddealer_nav"}</h3>
					<div class="ipsWidget__content">
						<ul class="gdNavList">
							<li class="gdNavList__item" data-gd-navitem="deals"><a href="#deals" data-gd-section="deals"><i class="fa-solid fa-tags"></i> {lang="gddealer_sec_deals"} <span class="gdNavCount">{expression="count($data['deals'])"}</span></a></li>
							<li class="gdNavList__item" data-gd-navitem="coupons"><a href="#coupons" data-gd-section="coupons"><i class="fa-solid fa-ticket"></i> {lang="gddealer_sec_coupons"} <span class="gdNavCount">{expression="count($data['coupons'])"}</span></a></li>
							<li class="gdNavList__item" data-gd-navitem="listings"><a href="#listings" data-gd-section="listings"><i class="fa-solid fa-box-open"></i> {lang="gddealer_sec_listings"} <span class="gdNavCount">{expression="number_format($data['listings_total'])"}</span></a></li>
							<li class="gdNavList__item" data-gd-navitem="reviews"><a href="#reviews" data-gd-section="reviews"><i class="fa-solid fa-star"></i> {lang="gddealer_sec_reviews"} <span class="gdNavCount">{expression="number_format($data['stats']['total'])"}</span></a></li>
							<li class="gdNavList__item" data-gd-navitem="info"><a href="#info" data-gd-section="info"><i class="fa-solid fa-circle-info"></i> {lang="gddealer_sec_info"}</a></li>
						</ul>
					</div>
				</div>

				<div class="ipsWidget ipsWidget--dealerStats">
					<h3 class="ipsWidget__header">{lang="gddealer_stats"}</h3>
					<div class="ipsWidget__content ipsWidget__padding">
						<ul class="gdStatsList">
							<li><i class="fa-solid fa-box-open"></i> {$data['dealer']['listing_count']} active listings</li>
							<li><i class="fa-solid fa-tags"></i> {expression="count($data['deals'])"} deals</li>
							<li><i class="fa-solid fa-ticket"></i> {expression="count($data['coupons'])"} coupons</li>
							<li><i class="fa-solid fa-star"></i> {$data['stats']['rating_label']} ({$data['stats']['avg_overall']} avg, {expression="number_format($data['stats']['total'])"} reviews)</li>
							{{if $data['dealer']['verified']}}<li><i class="fa-solid fa-shield-halved"></i> FFL Verified</li>{{endif}}
							<li><i class="fa-solid fa-calendar"></i> Member since {$data['dealer']['member_since']}</li>
							{{if $data['dealer']['tier_perk']}}<li><i class="fa-solid fa-tag"></i> <span class="gdStorePm" style="{expression="'background:' . $data['dealer']['tier_color'] . ';color:#fff'"}">{$data['dealer']['tier_label']}</span> &mdash; {$data['dealer']['tier_perk']}</li>{{endif}}
						</ul>
					</div>
				</div>

				<div class="ipsWidget ipsWidget--dealerLinks">
					<div class="ipsWidget__content ipsWidget__padding">
						<a href="{$data['guidelines_url']}"><i class="fa-solid fa-circle-info"></i> Review Guidelines</a>
					</div>
				</div>

			</div></div>
		</aside>

		<section class="ipsProfile__main ipsBox ipsBox--profileMain ipsPull">

			<div data-gd-panel="deals" class="gdPanel">
				{{if count($data['deals']) > 0}}
				<div class="gdProfile__grid gdProfile__grid--deals">
					{{foreach $data['deals'] as $deal}}
					<div class="gdProfile__card gdProfile__dealCard">
						{{if $deal['image_url']}}
						<div class="gdProfile__dealImg">
							<img src="{$deal['image_url']}" alt="" loading="lazy">
						</div>
						{{endif}}
						<div class="gdProfile__dealBody">
							{{if $deal['brand']}}
							<div class="gdProfile__cardBrand">{$deal['brand']}</div>
							{{endif}}
							<div class="gdProfile__dealTitle">{$deal['product_title']}</div>
							<div class="gdProfile__dealPricing">
								{{if $deal['deal_price']}}
								<span class="gdProfile__dealSalePrice">{$deal['deal_price']}</span>
								{{endif}}
								{{if $deal['regular_price']}}
								<span class="gdProfile__dealRegPrice">{$deal['regular_price']}</span>
								{{endif}}
								{{if $deal['pct_off']}}
								<span class="gdProfile__dealPctOff">{$deal['pct_off']}</span>
								{{endif}}
							</div>
							{{if $deal['title']}}
							<div class="gdProfile__dealBlurb">{$deal['title']}</div>
							{{endif}}
							{{if $deal['blurb']}}
							<div class="gdProfile__dealBlurb">{$deal['blurb']}</div>
							{{endif}}
							{{if $deal['end_date']}}
							<div class="gdProfile__dealExpiry">Ends {$deal['end_date']}</div>
							{{endif}}
						</div>
					</div>
					{{endforeach}}
				</div>
				{{else}}
				<div class="gdProfile__empty">
					<i class="fa-solid fa-tags"></i>
					<p>No active deals right now.</p>
				</div>
				{{endif}}
			</div>

			<div data-gd-panel="coupons" class="gdPanel">
				{{if count($data['coupons']) > 0}}
				<div class="gdProfile__grid gdProfile__grid--coupons">
					{{foreach $data['coupons'] as $coupon}}
					<div class="gdProfile__card gdProfile__couponCard">
						<div class="gdProfile__couponBadge">{$coupon['discount_display']}</div>
						<div class="gdProfile__couponBody">
							<code class="gdProfile__couponCode">{$coupon['code']}</code>
							{{if $coupon['description']}}
							<div class="gdProfile__couponDesc">{$coupon['description']}</div>
							{{endif}}
							{{if isset($coupon['discount_type']) && $coupon['discount_type'] === 'free_shipping' && $coupon['min_purchase']}}
							<div class="gdProfile__couponMeta">On orders {$coupon['min_purchase']}+</div>
							{{elseif $coupon['min_purchase']}}
							<div class="gdProfile__couponMeta">Min. purchase: {$coupon['min_purchase']}</div>
							{{endif}}
							{{if $coupon['terms']}}
							<div class="gdProfile__couponTerms">{$coupon['terms']}</div>
							{{endif}}
							{{if $coupon['expiry']}}
							<div class="gdProfile__couponExpiry">Expires {$coupon['expiry']}</div>
							{{endif}}
							<div class="gdProfile__couponNote">Honored at {$data['dealer']['dealer_name']}&rsquo;s store</div>
						</div>
					</div>
					{{endforeach}}
				</div>
				{{else}}
				<div class="gdProfile__empty">
					<i class="fa-solid fa-ticket"></i>
					<p>No coupons right now.</p>
				</div>
				{{endif}}
			</div>

			<div data-gd-panel="listings" class="gdPanel">
				<div class="gdProfile__listingsToolbar">
					<form method="get" class="gdProfile__listingsSearch">
						<input type="hidden" name="app" value="gddealer">
						<input type="hidden" name="module" value="dealers">
						<input type="hidden" name="controller" value="profile">
						{{if $data['dealer']['dealer_slug']}}
						<input type="hidden" name="dealer_slug" value="{$data['dealer']['dealer_slug']}">
						{{endif}}
						<input type="text" name="lq" value="{$data['listings_search']}" placeholder="Search listings by name or UPC" class="gdProfile__listingsSearchInput">
						<button type="submit" class="gdProfile__listingsSearchBtn"><i class="fa-solid fa-magnifying-glass"></i></button>
						{{if $data['listings_search']}}
						<a href="?app=gddealer&amp;module=dealers&amp;controller=profile{{if $data['dealer']['dealer_slug']}}&amp;dealer_slug={$data['dealer']['dealer_slug']}{{endif}}" class="gdProfile__listingsSearchClear" title="Clear search">&times;</a>
						{{endif}}
					</form>
					<div class="gdProfile__listingsCount">{expression="number_format($data['listings_total'])"} listings</div>
				</div>
				{{if count($data['listings']) > 0}}
				<div class="gdProfile__grid gdProfile__grid--listings">
					{{foreach $data['listings'] as $listing}}
					<div class="gdProfile__card gdProfile__listingCard">
						{{if $listing['image_url']}}
						<div class="gdProfile__listingImg">
							<img src="{$listing['image_url']}" alt="" loading="lazy">
						</div>
						{{endif}}
						<div class="gdProfile__listingBody">
							{{if $listing['brand']}}
							<div class="gdProfile__cardBrand">{$listing['brand']}</div>
							{{endif}}
							<div class="gdProfile__listingTitle">{$listing['title']}</div>
							<div class="gdProfile__listingFooter">
								<span class="gdProfile__listingPrice">{$listing['price_display']}</span>
								<span class="gdProfile__listingStock">In Stock</span>
							</div>
							{{if $listing['product_url']}}
							<a href="{$listing['product_url']}" target="_blank" rel="noopener" class="gdProfile__listingLink">View at store &rarr;</a>
							{{endif}}
						</div>
					</div>
					{{endforeach}}
				</div>
				{{if $data['listings_pages'] > 1}}
				<div class="gdProfile__pagination">
					<span class="gdProfile__pageInfo">Showing {expression="number_format(($data['listings_page']-1) * $data['listings_per_page'] + 1)"}&ndash;{expression="number_format(min($data['listings_page'] * $data['listings_per_page'], $data['listings_total']))"} of {expression="number_format($data['listings_total'])"}</span>
					<div class="gdProfile__pageNav">
						{{if $data['listings_page'] > 1}}
						<a href="?app=gddealer&amp;module=dealers&amp;controller=profile{{if $data['dealer']['dealer_slug']}}&amp;dealer_slug={$data['dealer']['dealer_slug']}{{endif}}&amp;lpage={expression="$data['listings_page'] - 1"}{{if $data['listings_search']}}&amp;lq={$data['listings_search']}{{endif}}" class="gdProfile__pageBtn">&laquo; Prev</a>
						{{endif}}
						<span class="gdProfile__pageCurrent">Page {$data['listings_page']} of {$data['listings_pages']}</span>
						{{if $data['listings_page'] < $data['listings_pages']}}
						<a href="?app=gddealer&amp;module=dealers&amp;controller=profile{{if $data['dealer']['dealer_slug']}}&amp;dealer_slug={$data['dealer']['dealer_slug']}{{endif}}&amp;lpage={expression="$data['listings_page'] + 1"}{{if $data['listings_search']}}&amp;lq={$data['listings_search']}{{endif}}" class="gdProfile__pageBtn">Next &raquo;</a>
						{{endif}}
					</div>
				</div>
				{{endif}}
				{{else}}
				<div class="gdProfile__empty">
					<i class="fa-solid fa-box-open"></i>
					{{if $data['listings_search']}}
					<p>No listings match &ldquo;{$data['listings_search']}&rdquo;.</p>
					{{else}}
					<p>This dealer has no active listings yet.</p>
					{{endif}}
				</div>
				{{endif}}
			</div>

			<div data-gd-panel="reviews" class="gdPanel">
				<div class="gdProfile__reviewsLayout">
					<div class="gdProfile__reviewsSidebar">
						<div class="gdProfile__ratingOverview">
							<div class="gdProfile__ratingBig" style="{expression="'color:' . ($data['stats']['rating_color'] ?? '#1E40AF')"}">{$data['stats']['avg_overall']}</div>
							<div class="gdProfile__ratingBigLabel" style="{expression="'color:' . ($data['stats']['rating_color'] ?? '#1E40AF')"}">{$data['stats']['rating_label']}</div>
							<div class="gdProfile__ratingBigCount">{expression="number_format($data['stats']['total'])"} reviews</div>
						</div>
						<div class="gdProfile__breakdownBars">
							<div class="gdProfile__breakdownRow">
								<span class="gdProfile__breakdownLabel">Pricing</span>
								<div class="gdProfile__breakdownTrack">
									<div class="gdProfile__breakdownFill" style="{expression="'width:' . ($data['stats']['pct_pricing'] ?? 0) . '%;background:' . ($data['stats']['color_pricing'] ?? '#1E40AF')"}"></div>
								</div>
								<span class="gdProfile__breakdownValue" style="{expression="'color:' . ($data['stats']['color_pricing'] ?? '#1E40AF')"}">{$data['stats']['avg_pricing']}</span>
							</div>
							<div class="gdProfile__breakdownRow">
								<span class="gdProfile__breakdownLabel">Shipping</span>
								<div class="gdProfile__breakdownTrack">
									<div class="gdProfile__breakdownFill" style="{expression="'width:' . ($data['stats']['pct_shipping'] ?? 0) . '%;background:' . ($data['stats']['color_shipping'] ?? '#1E40AF')"}"></div>
								</div>
								<span class="gdProfile__breakdownValue" style="{expression="'color:' . ($data['stats']['color_shipping'] ?? '#1E40AF')"}">{$data['stats']['avg_shipping']}</span>
							</div>
							<div class="gdProfile__breakdownRow">
								<span class="gdProfile__breakdownLabel">Service</span>
								<div class="gdProfile__breakdownTrack">
									<div class="gdProfile__breakdownFill" style="{expression="'width:' . ($data['stats']['pct_service'] ?? 0) . '%;background:' . ($data['stats']['color_service'] ?? '#1E40AF')"}"></div>
								</div>
								<span class="gdProfile__breakdownValue" style="{expression="'color:' . ($data['stats']['color_service'] ?? '#1E40AF')"}">{$data['stats']['avg_service']}</span>
							</div>
						</div>
						<div class="gdProfile__starDist">
							{{foreach $data['star_counts'] as $starVal => $starCount}}
							{{if $starVal !== 'all'}}
							<a href="{$data['star_options'][$starVal]}" class="gdProfile__starDistRow{{if $data['star_key'] === $starVal}} gdProfile__starDistRow--active{{endif}}">
								<span class="gdProfile__starDistLabel">{$starVal}&#9733;</span>
								<div class="gdProfile__starDistTrack">
									<div class="gdProfile__starDistFill" style="{expression="'width:' . ($data['stats']['total'] > 0 ? round($starCount / $data['stats']['total'] * 100) : 0) . '%'"}"></div>
								</div>
								<span class="gdProfile__starDistCount">{$starCount}</span>
							</a>
							{{endif}}
							{{endforeach}}
						</div>
					</div>

					<div class="gdProfile__reviewsMain">
						<div class="gdProfile__reviewsToolbar">
							<div class="gdProfile__sortLinks">
								<span class="gdProfile__sortLabel">Sort:</span>
								<a href="{$data['sort_options']['newest']}" class="gdProfile__sortLink{{if $data['sort_key'] === 'newest'}} gdProfile__sortLink--active{{endif}}">Newest</a>
								<a href="{$data['sort_options']['oldest']}" class="gdProfile__sortLink{{if $data['sort_key'] === 'oldest'}} gdProfile__sortLink--active{{endif}}">Oldest</a>
								<a href="{$data['sort_options']['highest']}" class="gdProfile__sortLink{{if $data['sort_key'] === 'highest'}} gdProfile__sortLink--active{{endif}}">Highest</a>
								<a href="{$data['sort_options']['lowest']}" class="gdProfile__sortLink{{if $data['sort_key'] === 'lowest'}} gdProfile__sortLink--active{{endif}}">Lowest</a>
							</div>
							{{if $data['star_key'] !== 'all'}}
							<a href="{$data['clear_filters_url']}" class="gdProfile__clearFilters">Clear filters ({$data['total_in_filter']} shown)</a>
							{{endif}}
						</div>

						{{if $data['can_rate']}}
						<div class="gdProfile__reviewForm">
							<h3 class="gdProfile__reviewFormTitle">Leave a Review</h3>
							<form method="post" action="{$data['rate_url']}">
								<input type="hidden" name="csrfKey" value="{$data['csrf_key']}">
								<div class="gdProfile__ratingSelects">
									<div class="gdProfile__ratingSelect">
										<label>Pricing Accuracy</label>
										<select name="rating_pricing" class="ipsInput ipsInput--select" required>
											<option value="">Rate...</option>
											<option value="5">&#9733;&#9733;&#9733;&#9733;&#9733; Excellent</option>
											<option value="4">&#9733;&#9733;&#9733;&#9733;&#9734; Good</option>
											<option value="3">&#9733;&#9733;&#9733;&#9734;&#9734; Average</option>
											<option value="2">&#9733;&#9733;&#9734;&#9734;&#9734; Poor</option>
											<option value="1">&#9733;&#9734;&#9734;&#9734;&#9734; Terrible</option>
										</select>
									</div>
									<div class="gdProfile__ratingSelect">
										<label>Shipping Speed</label>
										<select name="rating_shipping" class="ipsInput ipsInput--select" required>
											<option value="">Rate...</option>
											<option value="5">&#9733;&#9733;&#9733;&#9733;&#9733; Excellent</option>
											<option value="4">&#9733;&#9733;&#9733;&#9733;&#9734; Good</option>
											<option value="3">&#9733;&#9733;&#9733;&#9734;&#9734; Average</option>
											<option value="2">&#9733;&#9733;&#9734;&#9734;&#9734; Poor</option>
											<option value="1">&#9733;&#9734;&#9734;&#9734;&#9734; Terrible</option>
										</select>
									</div>
									<div class="gdProfile__ratingSelect">
										<label>Customer Service</label>
										<select name="rating_service" class="ipsInput ipsInput--select" required>
											<option value="">Rate...</option>
											<option value="5">&#9733;&#9733;&#9733;&#9733;&#9733; Excellent</option>
											<option value="4">&#9733;&#9733;&#9733;&#9733;&#9734; Good</option>
											<option value="3">&#9733;&#9733;&#9733;&#9734;&#9734; Average</option>
											<option value="2">&#9733;&#9733;&#9734;&#9734;&#9734; Poor</option>
											<option value="1">&#9733;&#9734;&#9734;&#9734;&#9734; Terrible</option>
										</select>
									</div>
								</div>
								<div class="gdProfile__reviewEditor">
									{$data['review_body_editor_html']}
								</div>
								<div class="gdProfile__reviewFormFooter">
									<span class="gdProfile__guidelinesNote">By submitting you agree to our <a href="{$data['guidelines_url']}">review guidelines</a>.</span>
									<button type="submit" class="ipsButton ipsButton--primary">Submit Review</button>
								</div>
							</form>
						</div>
						{{elseif $data['already_rated']}}
						<div class="ipsMessage ipsMessage--info">
							You have already reviewed this dealer. Thank you for your feedback!
						</div>
						{{elseif $data['login_required']}}
						<div class="gdProfile__reviewForm gdProfile__reviewForm--login">
							<p>Sign in to leave a review for this dealer.</p>
							<a href="{$data['login_url']}" class="ipsButton ipsButton--primary">Sign In to Review</a>
						</div>
						{{endif}}

						{{if count($data['reviews']) === 0}}
						<div class="gdProfile__empty gdProfile__empty--inline">
							<i class="fa-regular fa-star"></i>
							<p>No reviews yet. Be the first to review this dealer.</p>
						</div>
						{{else}}
						<div class="gdProfile__reviewsList">
							{{foreach $data['reviews'] as $r}}
							<div class="gdProfile__reviewCard">
								<div class="gdProfile__reviewHeader">
									<div class="gdProfile__reviewAuthor">
										{{if $r['reviewer_avatar']}}
										<span class="gdProfile__reviewAvatar">
											<img src="{$r['reviewer_avatar']}" alt="" loading="lazy">
										</span>
										{{else}}
										<span class="gdProfile__reviewInitials">{$r['customer_initials']}</span>
										{{endif}}
										<div>
											<div class="gdProfile__reviewName">
												{$r['reviewer_name']}
												{{if $r['verified_buyer']}}<span class="gdProfile__verifiedBuyer" title="Verified Buyer"><i class="fa-solid fa-circle-check"></i></span>{{endif}}
											</div>
											<div class="gdProfile__reviewDate">{$r['created_at_formatted']}</div>
										</div>
									</div>
									<div class="gdProfile__reviewScore" style="{expression="'background:' . $r['avg_color'] . '18;border-color:' . $r['avg_color'] . '40'"}">
										<span style="{expression="'color:' . $r['avg_color']"}">{$r['avg_score']}</span>
										<span class="gdProfile__reviewScoreSep">/ 5</span>
									</div>
								</div>

								<div class="gdProfile__reviewStars">
									<div class="gdProfile__reviewStarGroup">
										<span class="gdProfile__reviewStarLabel">Pricing</span>
										<span class="gdProfile__reviewStarVal">{$r['stars_pricing']}</span>
									</div>
									<div class="gdProfile__reviewStarGroup">
										<span class="gdProfile__reviewStarLabel">Shipping</span>
										<span class="gdProfile__reviewStarVal">{$r['stars_shipping']}</span>
									</div>
									<div class="gdProfile__reviewStarGroup">
										<span class="gdProfile__reviewStarLabel">Service</span>
										<span class="gdProfile__reviewStarVal">{$r['stars_service']}</span>
									</div>
								</div>

								{{if $r['review_body']}}
								<div class="gdProfile__reviewBody">{$r['review_body']}</div>
								{{endif}}

								{{if $r['dispute_status'] === 'pending_customer' || $r['dispute_status'] === 'pending_admin'}}
								<div class="gdProfile__reviewDispute">&#9888; This review is currently under admin review.</div>
								{{endif}}

								{{if $r['is_own_review'] && $r['edit_review_url']}}
								<div class="gdProfile__reviewActions">
									<a href="{$r['edit_review_url']}" class="gdProfile__reviewEditLink"><i class="fa-solid fa-pen"></i> Edit your review</a>
								</div>
								{{endif}}

								{{if $r['dealer_response']}}
								<div class="gdProfile__dealerResponse">
									<div class="gdProfile__dealerResponseLabel">
										<i class="fa-solid fa-reply"></i> Dealer Response
										{{if $r['response_at']}}<span class="gdProfile__dealerResponseDate">{$r['response_at']}</span>{{endif}}
									</div>
									<div class="gdProfile__dealerResponseBody">{$r['dealer_response']}</div>
								</div>
								{{endif}}
							</div>
							{{endforeach}}
						</div>
						{{endif}}
					</div>
				</div>
			</div>

			<div data-gd-panel="info" class="gdPanel">
				<div class="gdProfile2__infoGrid">
					{{if $data['dealer']['about']}}
					<div class="gdProfile2__infoCard">
						<h3 class="gdProfile2__infoCardTitle"><i class="fa-solid fa-store"></i> About</h3>
						<div class="gdProfile2__infoCardBody">{$data['dealer']['about']}</div>
					</div>
					{{endif}}

					{{if $data['dealer']['tagline']}}
					<div class="gdProfile2__infoCard">
						<h3 class="gdProfile2__infoCardTitle"><i class="fa-solid fa-quote-left"></i> Tagline</h3>
						<div class="gdProfile2__infoCardBody">{$data['dealer']['tagline']}</div>
					</div>
					{{endif}}

					{{if $data['dealer']['shipping_policy']}}
					<div class="gdProfile2__infoCard">
						<h3 class="gdProfile2__infoCardTitle"><i class="fa-solid fa-truck"></i> Shipping Policy</h3>
						<div class="gdProfile2__infoCardBody">{$data['dealer']['shipping_policy']}</div>
					</div>
					{{endif}}

					{{if $data['dealer']['return_policy']}}
					<div class="gdProfile2__infoCard">
						<h3 class="gdProfile2__infoCardTitle"><i class="fa-solid fa-rotate-left"></i> Return Policy</h3>
						<div class="gdProfile2__infoCardBody">{$data['dealer']['return_policy']}</div>
					</div>
					{{endif}}

					{{if $data['dealer']['additional_notes']}}
					<div class="gdProfile2__infoCard">
						<h3 class="gdProfile2__infoCardTitle"><i class="fa-solid fa-note-sticky"></i> Additional Notes</h3>
						<div class="gdProfile2__infoCardBody">{$data['dealer']['additional_notes']}</div>
					</div>
					{{endif}}
				</div>
			</div>

		</section>
	</div>

</div>
TEMPLATE_EOT;

try
{
    \IPS\Db::i()->replace( 'core_theme_templates', [
        'template_set_id'   => 1,
        'template_app'      => 'gddealer',
        'template_location' => 'front',
        'template_group'    => 'dealers',
        'template_name'     => 'dealerProfile',
        'template_data'     => '$data',
        'template_content'  => $dealerProfileTpl,
        'template_updated'  => time(),
        'template_version'  => '1.0.298',
    ] );
}
catch ( \Throwable $e )
{
    try { \IPS\Log::log( 'templates_10298 dealerProfile replace failed: ' . $e->getMessage(), 'gddealer_upg_10298' ); }
    catch ( \Throwable ) {}
}
