<?php
namespace IPS\gddealer\setup;
use function defined;
if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) ) {
    header( ( $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.0' ) . ' 403 Forbidden' );
    exit;
}

$gddealerV10078Templates = [];

/* analytics */
$gddealerV10078Templates[] = [
    'set_id'            => 1,
    'app'               => 'gddealer',
    'location'          => 'front',
    'group'             => 'dealers',
    'template_name'     => 'analytics',
    'template_data'     => '$data',
    'template_content'  => <<<'TEMPLATE_EOT'
<div class="gdPageHeader">
    <div class="gdPageHeader__titleBlock">
        <h1 class="gdPageHeader__title">Analytics</h1>
        <p class="gdPageHeader__sub">{$data['range_label']} &middot; real-time click data and price competitiveness</p>
    </div>
    <div class="gdRangePills">
        <a href="{$data['range_urls']['7']}"   class="gdRangePill {expression="$data['active_range'] === '7' ? 'is-active' : ''"}">7d</a>
        <a href="{$data['range_urls']['30']}"  class="gdRangePill {expression="$data['active_range'] === '30' ? 'is-active' : ''"}">30d</a>
        <a href="{$data['range_urls']['90']}"  class="gdRangePill {expression="$data['active_range'] === '90' ? 'is-active' : ''"}">90d</a>
        <a href="{$data['range_urls']['ytd']}" class="gdRangePill {expression="$data['active_range'] === 'ytd' ? 'is-active' : ''"}">YTD</a>
    </div>
</div>

<div class="gdKpiGrid">

    <div class="gdKpi">
        <div class="gdKpi__label">Total clicks</div>
        <div class="gdKpi__value">{expression="number_format($data['clicks_now'])"}</div>
        {{if $data['clicks_delta_pct'] !== null}}
        <div class="gdKpi__delta {expression="$data['clicks_delta_pct'] > 0 ? 'gdKpi__delta--up' : ($data['clicks_delta_pct'] < 0 ? 'gdKpi__delta--down' : '')"}">
            {{if $data['clicks_delta_pct'] > 0}}&uarr; +{$data['clicks_delta_pct']}%
            {{elseif $data['clicks_delta_pct'] < 0}}&darr; {$data['clicks_delta_pct']}%
            {{else}}&mdash;
            {{endif}}
            vs. previous {$data['range_label']}
        </div>
        {{elseif $data['clicks_prev'] === 0 and $data['clicks_now'] > 0}}
        <div class="gdKpi__delta gdKpi__delta--up">&uarr; first data</div>
        {{else}}
        <div class="gdKpi__delta">No prior data</div>
        {{endif}}
    </div>

    <div class="gdKpi">
        <div class="gdKpi__label">Lowest price</div>
        <div class="gdKpi__value">{expression="number_format($data['lowest_count'])"}</div>
        <div class="gdKpi__delta">listings where you're #1</div>
    </div>

    <div class="gdKpi">
        <div class="gdKpi__label">Overpriced</div>
        <div class="gdKpi__value">{expression="number_format($data['overpriced_count'])"}</div>
        <div class="gdKpi__delta {expression="$data['overpriced_count'] > 0 ? 'gdKpi__delta--down' : ''"}">{{if $data['overpriced_count'] > 0}}more than 10% above cheapest{{else}}none{{endif}}</div>
    </div>

    <div class="gdKpi">
        <div class="gdKpi__label">Price drops</div>
        <div class="gdKpi__value">{expression="number_format($data['price_drops'])"}</div>
        <div class="gdKpi__delta">in {$data['range_label']}</div>
    </div>

</div>

{{if $data['snapshot_total'] > 0}}
<div class="gdPanel">
    <div class="gdPanel__head">
        <div>
            <div class="gdPanel__title">Price competitiveness</div>
            <div class="gdPanel__sub">How your prices stack up against competing dealers, per UPC. Computed daily.</div>
        </div>
    </div>

    <div class="gdCompBar">
        {{if $data['tier_pct']['lowest'] > 0}}
        <div class="gdCompBar__seg gdCompBar__seg--lowest" style="width: {$data['tier_pct']['lowest']}%"><span>{$data['tier_pct']['lowest']}%</span></div>
        {{endif}}
        {{if $data['tier_pct']['close'] > 0}}
        <div class="gdCompBar__seg gdCompBar__seg--close" style="width: {$data['tier_pct']['close']}%"><span>{$data['tier_pct']['close']}%</span></div>
        {{endif}}
        {{if $data['tier_pct']['overpriced'] > 0}}
        <div class="gdCompBar__seg gdCompBar__seg--overpriced" style="width: {$data['tier_pct']['overpriced']}%"><span>{$data['tier_pct']['overpriced']}%</span></div>
        {{endif}}
        {{if $data['tier_pct']['only'] > 0}}
        <div class="gdCompBar__seg gdCompBar__seg--only" style="width: {$data['tier_pct']['only']}%"><span>{$data['tier_pct']['only']}%</span></div>
        {{endif}}
    </div>

    <div class="gdCompLegend">
        <div class="gdCompLegend__item">
            <span class="gdCompLegend__dot gdCompLegend__dot--lowest"></span>
            <div>
                <div class="gdCompLegend__count">{expression="number_format($data['tier_counts']['lowest'])"}</div>
                <div class="gdCompLegend__label">Lowest price</div>
                <div class="gdCompLegend__desc">You're the cheapest option.</div>
            </div>
        </div>
        <div class="gdCompLegend__item">
            <span class="gdCompLegend__dot gdCompLegend__dot--close"></span>
            <div>
                <div class="gdCompLegend__count">{expression="number_format($data['tier_counts']['close'])"}</div>
                <div class="gdCompLegend__label">Close to lowest</div>
                <div class="gdCompLegend__desc">Within 10% of cheapest &mdash; competitive.</div>
            </div>
        </div>
        <div class="gdCompLegend__item">
            <span class="gdCompLegend__dot gdCompLegend__dot--overpriced"></span>
            <div>
                <div class="gdCompLegend__count">{expression="number_format($data['tier_counts']['overpriced'])"}</div>
                <div class="gdCompLegend__label">Overpriced</div>
                <div class="gdCompLegend__desc">More than 10% above cheapest.</div>
            </div>
        </div>
        <div class="gdCompLegend__item">
            <span class="gdCompLegend__dot gdCompLegend__dot--only"></span>
            <div>
                <div class="gdCompLegend__count">{expression="number_format($data['tier_counts']['only'])"}</div>
                <div class="gdCompLegend__label">Only seller</div>
                <div class="gdCompLegend__desc">You're the only dealer listing this UPC.</div>
            </div>
        </div>
    </div>

    {{if $data['snapshot_date']}}
    <div class="gdPanel__footer">Snapshot computed {$data['snapshot_date']}</div>
    {{endif}}
</div>
{{else}}
<div class="gdPanel" style="text-align:center;padding:40px 24px">
    <h3 style="font-size:16px;font-weight:600;margin:0 0 6px">Price competitiveness snapshot pending</h3>
    <p style="color:var(--gd-text-subtle);margin:0;font-size:13px">Rank data is computed nightly. Check back after midnight Central or once your first active listings are in the catalog.</p>
</div>
{{endif}}

<div class="gdAnalyticsSplit">

    <div class="gdPanel">
        <div class="gdPanel__head">
            <div>
                <div class="gdPanel__title">Clicks over time</div>
                <div class="gdPanel__sub">Daily click-throughs in the selected range.</div>
            </div>
        </div>
        {{if $data['clicks_now'] === 0}}
        <div class="gdEmptyState" style="padding:32px">
            <p style="margin:0;color:var(--gd-text-subtle);font-size:13px">No clicks recorded in this range yet.</p>
        </div>
        {{else}}
        <svg class="gdChart" viewBox="0 0 600 220" preserveAspectRatio="none">
            {{foreach $data['chart_y_labels'] as $yl}}
            <line class="gdChart__grid" x1="40" y1="{$yl['y']}" x2="590" y2="{$yl['y']}"/>
            <text class="gdChart__axisLabel" x="34" y="{$yl['y']}" text-anchor="end">{$yl['label']}</text>
            {{endforeach}}
            <polygon class="gdChart__area" points="{$data['chart_area']}"/>
            <polyline class="gdChart__line" points="{$data['chart_polyline']}"/>
            {{foreach $data['chart_x_labels'] as $xl}}
            <text class="gdChart__axisLabel" x="{$xl['x']}" y="210" text-anchor="middle">{$xl['label']}</text>
            {{endforeach}}
        </svg>
        {{endif}}
    </div>

    <div class="gdPanel">
        <div class="gdPanel__head">
            <div>
                <div class="gdPanel__title">Top listings</div>
                <div class="gdPanel__sub">Most-clicked products in the selected range.</div>
            </div>
        </div>
        {{if count($data['top_listings']) === 0}}
        <div class="gdEmptyState" style="padding:24px 0">
            <p style="margin:0;color:var(--gd-text-subtle);font-size:13px">No click data in this range.</p>
        </div>
        {{else}}
        <ol class="gdTopList">
            {{foreach $data['top_listings'] as $tl}}
            <li class="gdTopList__item">
                <span class="gdTopList__rank">{$tl['rank']}</span>
                <div class="gdTopList__info">
                    <div class="gdTopList__name">{$tl['name']}</div>
                    <div class="gdTopList__upc">UPC {$tl['upc']}</div>
                </div>
                <div class="gdTopList__clicks">{expression="number_format($tl['clicks'])"}</div>
            </li>
            {{endforeach}}
        </ol>
        {{endif}}
    </div>

</div>

<div class="gdPanel">
    <div class="gdPanel__head">
        <div>
            <div class="gdPanel__title">Top states by clicks</div>
            <div class="gdPanel__sub">Where your click-throughs are coming from geographically.</div>
        </div>
    </div>
    {{if count($data['geo_distribution']) === 0}}
    <div class="gdEmptyState" style="padding:24px 0">
        <p style="margin:0;color:var(--gd-text-subtle);font-size:13px">No geographic data yet. State is captured on each click when available.</p>
    </div>
    {{else}}
    <div class="gdGeoList">
        {{foreach $data['geo_distribution'] as $g}}
        <div class="gdGeoRow">
            <span class="gdGeoRow__state">{$g['state']}</span>
            <div class="gdGeoRow__bar">
                <div class="gdGeoRow__fill" style="width: {$g['pct']}%"></div>
            </div>
            <span class="gdGeoRow__clicks">{expression="number_format($g['clicks'])"} clicks</span>
            <span class="gdGeoRow__pct">({$g['pct']}%)</span>
        </div>
        {{endforeach}}
    </div>
    {{endif}}
</div>
TEMPLATE_EOT
];

foreach ( $gddealerV10078Templates as $tpl ) {
    $masterKey = md5( $tpl['app'] . ';' . $tpl['location'] . ';' . $tpl['group'] . ';' . $tpl['template_name'] );

    \IPS\Db::i()->replace( 'core_theme_templates', [
        'template_set_id'        => $tpl['set_id'],
        'template_app'           => $tpl['app'],
        'template_location'      => $tpl['location'],
        'template_group'         => $tpl['group'],
        'template_name'          => $tpl['template_name'],
        'template_data'          => $tpl['template_data'],
        'template_content'       => $tpl['template_content'],
        'template_master_key'    => $masterKey,
        'template_updated'       => time(),
    ] );
}

try { \IPS\Theme::master()->recompileTemplates(); } catch ( \Throwable ) {}
try { \IPS\Data\Cache::i()->clearAll(); } catch ( \Throwable ) {}
try { \IPS\Data\Store::i()->clearAll(); } catch ( \Throwable ) {}
