<?php
/**
 * @brief       GD Dealer Manager — Template sync for v1.0.30 (10030)
 *
 * Overwrites two front templates on upgrade:
 *   1. dealerReviews — dashboard review list. Adds inline edit/delete
 *      controls on each dealer response block and a bare-redirect
 *      deleteResponse flow. Response timestamps are already rendered
 *      timezone-aware by the controller (\IPS\DateTime::ts()).
 *   2. dealerProfile — public dealer profile. Refreshed so the
 *      response_at timestamp under the dealer response card reflects
 *      the viewer's timezone (controller now formats via DateTime).
 *
 * Uses \IPS\Db::i()->replace() keyed on the existing template_id so
 * the upgrade overwrites the row in place. Safe to re-run.
 */

namespace IPS\gddealer\setup;

use function defined;

if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

$dealerReviewsContent = <<<'TEMPLATE_EOT'
<div style="margin-bottom:24px">

	<div style="display:flex;gap:16px;margin-bottom:24px;flex-wrap:wrap">
		<div style="flex:1 1 160px;background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:16px;text-align:center">
			<div style="font-size:2em;font-weight:800;color:{$data['rating_color']};line-height:1">{$data['avg_overall']}</div>
			<div style="color:#666;font-size:0.85em;margin-top:4px">Overall Rating</div>
			<div style="font-size:0.72em;font-weight:600;color:{$data['rating_color']};margin-top:4px">{$data['rating_label']}</div>
			<div style="color:#999;font-size:0.8em;margin-top:4px">{$data['total']} reviews</div>
		</div>
		<div style="flex:1 1 160px;background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:16px;text-align:center">
			<div style="font-size:2em;font-weight:800;color:{$data['color_pricing']}">{$data['avg_pricing']}</div>
			<div style="color:#666;font-size:0.85em">Pricing Accuracy</div>
		</div>
		<div style="flex:1 1 160px;background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:16px;text-align:center">
			<div style="font-size:2em;font-weight:800;color:{$data['color_shipping']}">{$data['avg_shipping']}</div>
			<div style="color:#666;font-size:0.85em">Shipping Speed</div>
		</div>
		<div style="flex:1 1 160px;background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:16px;text-align:center">
			<div style="font-size:2em;font-weight:800;color:{$data['color_service']}">{$data['avg_service']}</div>
			<div style="color:#666;font-size:0.85em">Customer Service</div>
		</div>
	</div>

	{{if $data['disputes_suspended']}}
	<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:14px 18px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px">
		<div>
			<strong style="color:#991b1b">Disputes Suspended</strong>
			<span style="color:#7f1d1d;margin-left:6px">&mdash; Your ability to contest reviews has been suspended by a site administrator. Contact <a href="mailto:{$data['help_email']}" style="color:#2563eb">{$data['help_email']}</a> for more information.</span>
		</div>
	</div>
	{{endif}}

	<div style="background:#f8fafc;border:1px solid var(--i-border-color,#e0e0e0);border-radius:6px;padding:10px 14px;margin-bottom:16px;font-size:0.85em;color:#334155">
		{{if $data['disputes_unlimited']}}
			You have <strong>unlimited</strong> review contests this month (Enterprise plan).
		{{else}}
			You have <strong>{$data['disputes_remaining']}</strong> review contests remaining this month.
		{{endif}}
	</div>

	{{if count($data['rows']) === 0}}
		<div class="ipsEmptyMessage"><p>No reviews yet. Reviews appear here once customers rate your dealership.</p></div>
	{{else}}
		{{foreach $data['rows'] as $r}}
		<div style="background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:20px;margin-bottom:12px">
			<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px;flex-wrap:wrap;gap:8px">
				<div style="display:flex;gap:16px;flex-wrap:wrap;align-items:center">
					<span style="font-size:0.8em;font-weight:700;color:{$r['avg_color']};background:{$r['avg_color']}18;padding:2px 8px;border-radius:12px">{$r['avg_overall']} / 5</span>
					<span style="font-size:0.8em;color:#666">Pricing: <strong>{$r['rating_pricing']}/5</strong></span>
					<span style="font-size:0.8em;color:#666">Shipping: <strong>{$r['rating_shipping']}/5</strong></span>
					<span style="font-size:0.8em;color:#666">Service: <strong>{$r['rating_service']}/5</strong></span>
				</div>
				<span style="font-size:0.8em;color:#999">{$r['created_at']}</span>
			</div>

			{{if $r['review_body']}}
			<p style="margin:0 0 12px;color:#333">{$r['review_body']}</p>
			{{endif}}

			{{if $r['dealer_response']}}
				<div data-resp="{$r['id']}" style="background:#f0f7ff;border-left:3px solid #2563eb;padding:12px 16px;border-radius:0 6px 6px 0;margin-top:8px">
					<div class="gd-resp-head" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;gap:8px;flex-wrap:wrap">
						<div style="font-size:0.8em;color:#2563eb;font-weight:700">Your response &mdash; {$r['response_at']}</div>
						<div class="gd-resp-actions" style="display:flex;gap:8px;align-items:center">
							<a href="#" onclick="var w=this.closest('div[data-resp]');w.querySelector('.gd-resp-text').style.display='none';w.querySelector('.gd-resp-actions').style.display='none';w.querySelector('.gd-resp-edit').style.display='block';return false" style="font-size:0.75em;color:#2563eb;font-weight:600;text-decoration:none">Edit</a>
							<form method="post" action="{$r['delete_response_url']}" style="display:inline;margin:0" onsubmit="return confirm('Delete your response?')">
								<input type="hidden" name="csrfKey" value="{$csrfKey}">
								<button type="submit" style="background:none;border:none;padding:0;font-size:0.75em;color:#dc2626;font-weight:600;cursor:pointer">Delete</button>
							</form>
						</div>
					</div>
					<p class="gd-resp-text" style="margin:0;font-size:0.9em">{$r['dealer_response']}</p>
					<form class="gd-resp-edit" method="post" action="{$r['respond_url']}" style="display:none;margin-top:8px">
						<input type="hidden" name="csrfKey" value="{$csrfKey}">
						<textarea name="response" rows="3" required style="width:100%;border:1px solid #d1d5db;border-radius:4px;padding:8px;font-size:0.9em;box-sizing:border-box">{$r['dealer_response']}</textarea>
						<div style="display:flex;gap:6px;margin-top:8px">
							<button type="submit" class="ipsButton ipsButton--primary ipsButton--small">Save changes</button>
							<button type="button" onclick="var w=this.closest('div[data-resp]');w.querySelector('.gd-resp-text').style.display='block';w.querySelector('.gd-resp-actions').style.display='flex';w.querySelector('.gd-resp-edit').style.display='none';return false" class="ipsButton ipsButton--normal ipsButton--small">Cancel</button>
						</div>
					</form>
				</div>
			{{endif}}

			{{if $r['dispute_status'] === 'pending_customer'}}
				<div style="background:#fff8f0;border-left:3px solid #f59e0b;padding:10px 14px;border-radius:0 4px 4px 0;margin-top:8px;font-size:0.85em;color:#92400e">
					<strong>Contest submitted &mdash; awaiting customer response.</strong>
					{{if $r['dispute_deadline']}}<div style="font-size:0.8em;margin-top:2px">Customer has until {$r['dispute_deadline']} to respond.</div>{{endif}}
				</div>
			{{endif}}

			{{if $r['dispute_status'] === 'pending_admin'}}
				<div style="background:#eff6ff;border-left:3px solid #2563eb;padding:10px 14px;border-radius:0 4px 4px 0;margin-top:8px;font-size:0.85em;color:#1e3a8a">
					<strong>Contest under admin review.</strong> The customer has responded and admin will resolve shortly.
				</div>
			{{endif}}

			{{if $r['dispute_status'] === 'resolved_dealer'}}
				<div style="background:#f0fdf4;border-left:3px solid #16a34a;padding:10px 14px;border-radius:0 4px 4px 0;margin-top:8px;font-size:0.85em;color:#14532d">
					<strong>Contest resolved in your favor.</strong> This review no longer affects your rating average.
				</div>
			{{endif}}

			{{if $r['dispute_status'] === 'resolved_customer'}}
				<div style="background:#fef2f2;border-left:3px solid #dc2626;padding:10px 14px;border-radius:0 4px 4px 0;margin-top:8px;font-size:0.85em;color:#7f1d1d">
					<strong>Contest resolved in the customer's favor.</strong> The review stands.
				</div>
			{{endif}}

			{{if $r['dispute_status'] === 'dismissed'}}
				<div style="background:#f1f5f9;border-left:3px solid #64748b;padding:10px 14px;border-radius:0 4px 4px 0;margin-top:8px;font-size:0.85em;color:#334155">
					<strong>Contest dismissed.</strong> This review cannot be contested again.
				</div>
			{{endif}}

			{{if $r['dispute_status'] === 'none'}}
				{{if $r['dealer_response'] === ''}}
				<details style="margin-top:8px">
					<summary style="cursor:pointer;font-size:0.85em;color:#2563eb;font-weight:600">Respond to this review</summary>
					<form method="post" action="{$r['respond_url']}" style="margin-top:8px">
						<input type="hidden" name="csrfKey" value="{$csrfKey}">
						<textarea name="response" rows="3" style="width:100%;border:1px solid var(--i-border-color,#ccc);border-radius:4px;padding:8px;font-size:0.9em;box-sizing:border-box" placeholder="Write a professional response visible to all buyers..."></textarea>
						<button type="submit" class="ipsButton ipsButton--primary ipsButton--small" style="margin-top:8px">Post Response</button>
					</form>
				</details>
				{{endif}}

				{{if $data['disputes_unlimited']}}
				<details style="margin-top:8px">
					<summary style="cursor:pointer;font-size:0.85em;color:#dc2626;font-weight:600">Contest this review</summary>
					<form method="post" action="{$r['dispute_url']}" style="margin-top:8px">
						<input type="hidden" name="csrfKey" value="{$csrfKey}">
						<p style="margin:0 0 8px;font-size:0.8em;color:#666">Read the <a href="{$data['guidelines_url']}" style="color:#2563eb" target="_blank">Dispute Guidelines</a> before contesting a review.</p>
						<label style="display:block;font-size:0.8em;font-weight:600;margin-bottom:4px">Reason for contest</label>
						<textarea name="dispute_reason" rows="3" required style="width:100%;border:1px solid var(--i-border-color,#ccc);border-radius:4px;padding:8px;font-size:0.9em;box-sizing:border-box;margin-bottom:8px" placeholder="Explain why this review should be removed (e.g. never purchased from us, fraudulent, violates terms)..."></textarea>
						<label style="display:block;font-size:0.8em;font-weight:600;margin-bottom:4px">Supporting evidence (order numbers, screenshots, transaction IDs)</label>
						<textarea name="dispute_evidence" rows="3" style="width:100%;border:1px solid var(--i-border-color,#ccc);border-radius:4px;padding:8px;font-size:0.9em;box-sizing:border-box" placeholder="Paste order numbers, links, or evidence that supports your contest..."></textarea>
						<button type="submit" class="ipsButton ipsButton--negative ipsButton--small" style="margin-top:8px">Submit Contest</button>
					</form>
				</details>
				{{else}}
					{{if $data['disputes_remaining'] > 0}}
					<details style="margin-top:8px">
						<summary style="cursor:pointer;font-size:0.85em;color:#dc2626;font-weight:600">Contest this review</summary>
						<form method="post" action="{$r['dispute_url']}" style="margin-top:8px">
							<input type="hidden" name="csrfKey" value="{$csrfKey}">
							<p style="margin:0 0 8px;font-size:0.8em;color:#666">Read the <a href="{$data['guidelines_url']}" style="color:#2563eb" target="_blank">Dispute Guidelines</a> before contesting a review.</p>
							<label style="display:block;font-size:0.8em;font-weight:600;margin-bottom:4px">Reason for contest</label>
							<textarea name="dispute_reason" rows="3" required style="width:100%;border:1px solid var(--i-border-color,#ccc);border-radius:4px;padding:8px;font-size:0.9em;box-sizing:border-box;margin-bottom:8px" placeholder="Explain why this review should be removed (e.g. never purchased from us, fraudulent, violates terms)..."></textarea>
							<label style="display:block;font-size:0.8em;font-weight:600;margin-bottom:4px">Supporting evidence (order numbers, screenshots, transaction IDs)</label>
							<textarea name="dispute_evidence" rows="3" style="width:100%;border:1px solid var(--i-border-color,#ccc);border-radius:4px;padding:8px;font-size:0.9em;box-sizing:border-box" placeholder="Paste order numbers, links, or evidence that supports your contest..."></textarea>
							<button type="submit" class="ipsButton ipsButton--negative ipsButton--small" style="margin-top:8px">Submit Contest</button>
						</form>
					</details>
					{{else}}
					<div style="background:#f1f5f9;border-left:3px solid #64748b;padding:8px 12px;border-radius:0 4px 4px 0;margin-top:8px;font-size:0.8em;color:#475569">
						You have reached your monthly contest limit. Upgrade your plan for more contests.
					</div>
					{{endif}}
				{{endif}}
			{{endif}}
		</div>
		{{endforeach}}
	{{endif}}

</div>
TEMPLATE_EOT;

$dealerProfileContent = <<<'TEMPLATE_EOT'
<style>
#ipsLayout_mainArea { max-width: 100% !important; }
#ipsLayout_main { max-width: 100% !important; }
.ipsLayout_container { max-width: 1446px !important; }
.gdDealerStats { display:flex; flex-wrap:wrap; border-top:1px solid var(--i-border-color,#e8e8e8); margin-top:16px; }
.gdDealerStats > div { flex:1 1 120px; padding:16px 20px; text-align:center; min-height:80px; display:flex; flex-direction:column; justify-content:center; }
.gdDealerStats > div + div { border-left:1px solid var(--i-border-color,#e8e8e8); }
@media (max-width: 768px) {
  .gdDealerStats > div { flex:1 1 45%; min-height:60px; }
  .gdDealerStats > div + div { border-left:none; }
  .gdDealerStats > div:nth-child(odd) { border-right:1px solid var(--i-border-color,#e8e8e8); }
  .gdDealerStats > div:nth-child(n+3) { border-top:1px solid var(--i-border-color,#e8e8e8); }
  .gdProfileSidebar { width:100% !important; flex-shrink:1 !important; }
  .gdProfileButtons { justify-content:center; }
  .gdTableWrap { overflow-x:auto; -webkit-overflow-scrolling:touch; }
}
@media (max-width: 480px) {
  .gdDealerStats > div { flex:1 1 100%; border-left:none !important; border-right:none !important; }
  .gdDealerStats > div + div { border-top:1px solid var(--i-border-color,#e8e8e8); }
}
</style>

<div class="gdDealerWrapper" style="width:100%;max-width:1446px;margin:0 auto;padding:0 24px;box-sizing:border-box">

	<header class="ipsPageHeader ipsBox ipsBox--profileHeader ipsPull i-margin-bottom_block" style="width:100%;box-sizing:border-box;border-radius:8px;overflow:hidden;margin-bottom:16px">
		<div class="ipsCoverPhoto ipsCoverPhoto--profile" style="position:relative;overflow:hidden;min-height:180px">
			<div class="ipsCoverPhoto__container" style="width:100%;height:180px;overflow:hidden">
				{{if $dealer['cover_photo_url']}}
					<img src="{$dealer['cover_photo_url']}" class="ipsCoverPhoto__image" alt="" loading="lazy" style="width:100%;height:100%;object-fit:cover">
				{{else}}
					<div class="ipsFallbackImage gdDealerCoverFallback" style="background:linear-gradient(135deg,#1e3a8a 0%,#2563eb 100%);width:100%;height:180px"></div>
				{{endif}}
			</div>
		</div>
		<div class="ipsCoverPhotoMeta" style="background:#fff;border-top:none;padding:20px 24px">
			<div style="display:flex;gap:20px;align-items:flex-end;flex-wrap:wrap">
				{{if $dealer['avatar_url']}}
				<div class="ipsCoverPhoto__avatar" id="elProfilePhoto" style="margin-top:-60px">
					<span class="ipsUserPhoto ipsUserPhoto--xlarge">
						<img src="{$dealer['avatar_url']}" alt="" loading="lazy" onerror="this.style.display='none'">
					</span>
				</div>
				{{endif}}
				<div class="ipsCoverPhoto__titles" style="flex:1;min-width:200px">
					<div class="ipsCoverPhoto__title">
						<h1 style="margin:0;font-size:1.6em;font-weight:800">{$dealer['dealer_name']}</h1>
					</div>
					<div class="ipsCoverPhoto__desc" style="margin-top:6px">
						<span style="background:{$dealer['tier_color']};color:#fff;padding:2px 10px;border-radius:20px;font-size:0.8em;font-weight:700">{$dealer['tier_label']}</span>
					</div>
				</div>
				<div class="ipsCoverPhoto__buttons gdProfileButtons" style="display:flex;gap:8px;flex-wrap:wrap">
					<a href="mailto:{$dealer['contact_email']}" class="ipsButton ipsButton--primary">
						<i class="fa-solid fa-envelope" aria-hidden="true"></i>
						<span>Contact Dealer</span>
					</a>
					<a href="{$guidelinesUrl}" class="ipsButton ipsButton--inherit">
						<i class="fa-solid fa-circle-info" aria-hidden="true"></i>
						<span>Review Guidelines</span>
					</a>
				</div>
			</div>
			<div class="gdDealerStats">
				<div>
					<div style="font-size:0.72em;color:#888;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;white-space:nowrap">Overall Rating</div>
					<div style="font-size:1.6em;font-weight:800;color:{$stats['rating_color']};line-height:1">{$stats['avg_overall']}<span style="font-size:0.45em;color:#888;font-weight:400"> /5</span></div>
					<div style="font-size:0.72em;font-weight:600;color:{$stats['rating_color']};margin-top:4px">{$stats['rating_label']}</div>
				</div>
				<div>
					<div style="font-size:0.75em;color:#888;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;white-space:nowrap">Reviews</div>
					<div style="font-size:1.6em;font-weight:800;line-height:1">{$stats['total']}</div>
				</div>
				<div>
					<div style="font-size:0.75em;color:#888;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;white-space:nowrap">Member Since</div>
					<div style="font-size:1.6em;font-weight:800;line-height:1">{{if $dealer['member_since']}}{$dealer['member_since']}{{else}}&mdash;{{endif}}</div>
				</div>
				<div>
					<div style="font-size:0.75em;color:#888;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;white-space:nowrap">Active Listings</div>
					<div style="font-size:1.6em;font-weight:800;color:#16a34a;line-height:1">{$dealer['listing_count']}</div>
				</div>
			</div>
		</div>
	</header>

	{{if !$dealer['is_active']}}
	<div style="background:#f8f9fa;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:14px 18px;margin-bottom:16px">
		<strong style="color:#374151">This dealer's listings are currently inactive.</strong>
		<p style="margin:4px 0 0;color:#6b7280;font-size:0.9em">Inventory and pricing are not being updated. Existing reviews and ratings are shown below for reference.</p>
	</div>
	{{endif}}

	{{if $customerDispute}}
	<div class="ipsBox i-margin-bottom_block" style="background:#fff8f0;border:1px solid #f59e0b;border-radius:8px;padding:20px;margin-bottom:24px">
		<h2 style="margin:0 0 8px;font-size:1.05em;font-weight:700;color:#92400e">{$dealer['dealer_name']} has contested your review</h2>
		<p style="margin:0 0 12px;font-size:0.9em;color:#78350f">
			The dealer has submitted a contest against the review you left.
			{{if $customerDispute['deadline_formatted']}}You have until <strong>{$customerDispute['deadline_formatted']}</strong> to respond, or the contest will be automatically resolved in the dealer's favor.{{endif}}
		</p>
		{{if $customerDispute['dispute_reason']}}
		<div style="background:#fff;border-left:3px solid #f59e0b;padding:10px 14px;margin-bottom:12px;border-radius:0 4px 4px 0">
			<div style="font-size:0.8em;font-weight:700;color:#92400e;margin-bottom:4px">Dealer's reason</div>
			<p style="margin:0;font-size:0.9em;color:#333">{$customerDispute['dispute_reason']}</p>
		</div>
		{{endif}}
		{{if $customerDispute['dispute_evidence']}}
		<div style="background:#fff;border-left:3px solid #f59e0b;padding:10px 14px;margin-bottom:12px;border-radius:0 4px 4px 0">
			<div style="font-size:0.8em;font-weight:700;color:#92400e;margin-bottom:4px">Dealer's evidence</div>
			<p style="margin:0;font-size:0.9em;color:#333;white-space:pre-wrap">{$customerDispute['dispute_evidence']}</p>
		</div>
		{{endif}}
		<form method="post" action="{$customerDispute['respond_url']}">
			<input type="hidden" name="csrfKey" value="{$csrfKey}">
			<label style="display:block;font-size:0.85em;font-weight:600;margin-bottom:4px;color:#78350f">Your response</label>
			<textarea name="customer_response" rows="4" required class="ipsInput ipsInput--text" style="width:100%;border:1px solid #f59e0b;border-radius:4px;padding:8px;font-size:0.9em;box-sizing:border-box;margin-bottom:8px" placeholder="Explain your side of the story. Admin will review both accounts."></textarea>
			<label style="display:block;font-size:0.85em;font-weight:600;margin-bottom:4px;color:#78350f">Supporting evidence (optional)</label>
			<textarea name="customer_evidence" rows="3" class="ipsInput ipsInput--text" style="width:100%;border:1px solid #f59e0b;border-radius:4px;padding:8px;font-size:0.9em;box-sizing:border-box;margin-bottom:8px" placeholder="Paste order numbers, links, receipts, or other evidence that supports your review..."></textarea>
			<button type="submit" class="ipsButton ipsButton--primary">Submit My Response</button>
		</form>
	</div>
	{{endif}}

	<div class="ipsProfile ipsProfile--profile" style="display:flex;gap:24px;flex-wrap:wrap">
		<aside class="ipsProfile__aside gdProfileSidebar" style="width:300px;flex-shrink:0">
			<div class="ipsProfile__sticky-outer">
				<div class="ipsProfile__sticky-inner">
					<div class="ipsWidget" style="background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;margin-bottom:16px">
						<h3 class="ipsWidget__title" style="margin:0;padding:12px 16px;border-bottom:1px solid var(--i-border-color,#f0f0f0);font-size:0.9em;font-weight:700">Rating Breakdown</h3>
						<div class="ipsWidget__content i-padding_2" style="padding:16px">
							<div style="margin-bottom:14px">
								<div style="display:flex;justify-content:space-between;margin-bottom:4px">
									<span style="font-size:0.85em">Pricing Accuracy</span>
									<strong style="color:{$stats['color_pricing']}">{$stats['avg_pricing']}/5</strong>
								</div>
								<div style="background:var(--i-border-color,#e0e0e0);border-radius:4px;height:8px">
									<div style="background:{$stats['color_pricing']};border-radius:4px;height:8px;width:{$stats['pct_pricing']}%;transition:width 0.3s ease"></div>
								</div>
							</div>
							<div style="margin-bottom:14px">
								<div style="display:flex;justify-content:space-between;margin-bottom:4px">
									<span style="font-size:0.85em">Shipping Speed</span>
									<strong style="color:{$stats['color_shipping']}">{$stats['avg_shipping']}/5</strong>
								</div>
								<div style="background:var(--i-border-color,#e0e0e0);border-radius:4px;height:8px">
									<div style="background:{$stats['color_shipping']};border-radius:4px;height:8px;width:{$stats['pct_shipping']}%;transition:width 0.3s ease"></div>
								</div>
							</div>
							<div>
								<div style="display:flex;justify-content:space-between;margin-bottom:4px">
									<span style="font-size:0.85em">Customer Service</span>
									<strong style="color:{$stats['color_service']}">{$stats['avg_service']}/5</strong>
								</div>
								<div style="background:var(--i-border-color,#e0e0e0);border-radius:4px;height:8px">
									<div style="background:{$stats['color_service']};border-radius:4px;height:8px;width:{$stats['pct_service']}%;transition:width 0.3s ease"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</aside>

		<div class="ipsProfile__main" style="flex:1 1 0;min-width:0">
			{{if $canRate}}
			<div class="ipsBox i-margin-bottom_block" style="background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;margin-bottom:24px">
				<h3 class="ipsBox__header" style="margin:0;padding:14px 18px;border-bottom:1px solid var(--i-border-color,#f0f0f0);font-size:1em;font-weight:700">Leave a Review</h3>
				<div class="i-padding_2" style="padding:18px">
					<form method="post" action="{$rateUrl}">
						<input type="hidden" name="csrfKey" value="{$csrfKey}">
						<div style="display:flex;gap:20px;margin-bottom:16px;flex-wrap:wrap">
							<div style="flex:1 1 140px">
								<label style="display:block;font-size:0.85em;font-weight:600;margin-bottom:6px">Pricing Accuracy</label>
								<select name="rating_pricing" class="ipsInput ipsInput--select" required>
									<option value="">Rate...</option>
									<option value="5">★★★★★ Excellent</option>
									<option value="4">★★★★☆ Good</option>
									<option value="3">★★★☆☆ Average</option>
									<option value="2">★★☆☆☆ Poor</option>
									<option value="1">★☆☆☆☆ Terrible</option>
								</select>
							</div>
							<div style="flex:1 1 140px">
								<label style="display:block;font-size:0.85em;font-weight:600;margin-bottom:6px">Shipping Speed</label>
								<select name="rating_shipping" class="ipsInput ipsInput--select" required>
									<option value="">Rate...</option>
									<option value="5">★★★★★ Excellent</option>
									<option value="4">★★★★☆ Good</option>
									<option value="3">★★★☆☆ Average</option>
									<option value="2">★★☆☆☆ Poor</option>
									<option value="1">★☆☆☆☆ Terrible</option>
								</select>
							</div>
							<div style="flex:1 1 140px">
								<label style="display:block;font-size:0.85em;font-weight:600;margin-bottom:6px">Customer Service</label>
								<select name="rating_service" class="ipsInput ipsInput--select" required>
									<option value="">Rate...</option>
									<option value="5">★★★★★ Excellent</option>
									<option value="4">★★★★☆ Good</option>
									<option value="3">★★★☆☆ Average</option>
									<option value="2">★★☆☆☆ Poor</option>
									<option value="1">★☆☆☆☆ Terrible</option>
								</select>
							</div>
						</div>
						<textarea name="review_body" rows="4" class="ipsInput ipsInput--text" style="width:100%;box-sizing:border-box;margin-bottom:12px;border:1px solid var(--i-border-color,#ccc);border-radius:4px;padding:8px;font-size:0.9em" placeholder="Share your experience (optional but helpful)..."></textarea>
						<div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:8px">
							<span style="font-size:0.8em;color:#666">By submitting you agree to our <a href="{$guidelinesUrl}" style="color:#2563eb">review guidelines</a>.</span>
							<button type="submit" class="ipsButton ipsButton--primary">Submit Review</button>
						</div>
					</form>
				</div>
			</div>
			{{elseif $alreadyRated}}
			<div style="background:#f0f7ff;border:1px solid #bfdbfe;border-radius:8px;padding:14px 18px;margin-bottom:24px;color:#1e40af">
				You have already reviewed this dealer. Thank you for your feedback!
			</div>
			{{elseif $loginRequired}}
			<div class="ipsBox i-margin-bottom_block" style="background:#fff;border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;margin-bottom:24px">
				<div class="i-padding_2" style="padding:24px;text-align:center">
					<p style="margin:0 0 12px;color:#666">Sign in to leave a review for this dealer.</p>
					<a href="{$loginUrl}" class="ipsButton ipsButton--primary">Sign In to Review</a>
				</div>
			</div>
			{{endif}}

			<div class="gdReviewList" style="padding:16px 4px 0">
				<h3 style="margin:0 0 14px;padding:0 4px;font-size:1em;font-weight:700;color:#111827">Customer Reviews <span style="font-size:0.8em;font-weight:500;color:#6b7280;margin-left:4px">({expression="number_format($stats['total'])"})</span></h3>
				{{if count($reviews) === 0}}
				<div style="background:#fff;border:0.5px solid #e5e7eb;border-radius:12px;padding:40px 24px;text-align:center;color:#9ca3af">
					<i class="fa-regular fa-star" style="font-size:2em;display:block;margin-bottom:10px;opacity:0.4" aria-hidden="true"></i>
					No reviews yet. Be the first to review this dealer.
				</div>
				{{else}}
					{{foreach $reviews as $r}}
					<div style="background:#fff;border:0.5px solid #e5e7eb;border-radius:12px;padding:20px 22px;margin:0 0 16px;color:#1f2937">

						<div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
							<div style="width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#c9a24a,#b8862d);color:#fff;display:flex;align-items:center;justify-content:center;font-weight:500;font-size:15px;flex-shrink:0;overflow:hidden">
								{{if $r['reviewer_avatar']}}
									<img src="{$r['reviewer_avatar']}" alt="" style="width:100%;height:100%;object-fit:cover" loading="lazy">
								{{else}}
									{expression="strtoupper(substr($r['reviewer_name'], 0, 1))"}
								{{endif}}
							</div>
							<div style="display:flex;flex-direction:column;min-width:0;flex:1">
								<span style="font-weight:500;font-size:14px;color:#111827;line-height:1.3">{$r['reviewer_name']}</span>
								<span style="font-size:12px;color:#6b7280;margin-top:2px">{$r['created_at_formatted']}</span>
							</div>
							<span style="display:inline-flex;align-items:center;gap:6px;background:{$r['avg_color']}18;border:0.5px solid {$r['avg_color']}60;border-radius:20px;padding:4px 12px;font-size:13px;color:{$r['avg_color']};font-weight:500;white-space:nowrap">
								<span style="font-size:14px">{$r['avg_score']}</span>
								<span style="opacity:0.6;font-weight:400">/ 5</span>
							</span>
						</div>

						<div style="display:flex;gap:20px;margin-bottom:14px;flex-wrap:wrap">
							<div style="display:flex;align-items:center;gap:8px">
								<span style="font-size:12px;color:#6b7280;font-weight:500">Pricing</span>
								<span style="letter-spacing:1px;font-size:13px;line-height:1;color:#f59e0b">{$r['stars_pricing']}</span>
							</div>
							<div style="display:flex;align-items:center;gap:8px">
								<span style="font-size:12px;color:#6b7280;font-weight:500">Shipping</span>
								<span style="letter-spacing:1px;font-size:13px;line-height:1;color:#f59e0b">{$r['stars_shipping']}</span>
							</div>
							<div style="display:flex;align-items:center;gap:8px">
								<span style="font-size:12px;color:#6b7280;font-weight:500">Service</span>
								<span style="letter-spacing:1px;font-size:13px;line-height:1;color:#f59e0b">{$r['stars_service']}</span>
							</div>
						</div>

						{{if $r['review_body']}}
						<p style="font-size:14px;line-height:1.6;color:#374151;margin:4px 0 0">{$r['review_body']}</p>
						{{endif}}

						{{if $r['is_own_review'] and $r['dispute_status'] === 'pending_customer'}}
						<div style="background:#fef2f2;border:0.5px solid #fca5a5;border-radius:8px;padding:10px 14px;font-size:12px;color:#991b1b;margin-top:12px;display:flex;align-items:center;gap:8px">
							<span style="flex-shrink:0;color:#dc2626;font-size:14px;line-height:1">⚠</span>
							<span><strong>Action required:</strong> The dealer has contested this review. You must respond or the dispute will be resolved in their favor.
							{{if $r['dispute_respond_url']}}<a href="{$r['dispute_respond_url']}" style="color:#dc2626;font-weight:500;margin-left:6px">Respond now →</a>{{endif}}</span>
						</div>
						{{elseif $r['dispute_status'] === 'pending_customer' or $r['dispute_status'] === 'pending_admin'}}
						<div style="background:#fffbeb;border:0.5px solid #fcd34d;border-radius:8px;padding:10px 14px;font-size:12px;color:#78350f;margin-top:12px;display:flex;align-items:center;gap:8px">
							<span style="flex-shrink:0;color:#d97706;font-size:14px;line-height:1">⚠</span>
							<span>This review is currently under dispute review.</span>
						</div>
						{{endif}}

						{{if $r['dealer_response']}}
						<div style="margin-top:16px;background:#f9fafb;border-radius:10px;padding:14px 16px;border-left:3px solid #2563eb">
							<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;flex-wrap:wrap;gap:8px">
								<span style="display:inline-flex;align-items:center;gap:6px;font-size:11px;color:#2563eb;font-weight:500;text-transform:uppercase;letter-spacing:0.06em">
									<i class="fa-solid fa-reply" aria-hidden="true"></i> Dealer response{{if $r['dealer_name']}} · {$r['dealer_name']}{{endif}}
								</span>
								<span style="font-size:11px;color:#9ca3af">{$r['response_at']}</span>
							</div>
							<p style="font-size:13px;line-height:1.5;color:#374151;margin:0">{$r['dealer_response']}</p>
						</div>
						{{endif}}

						{{if $r['edit_review_url']}}
						<div style="display:flex;justify-content:flex-end;margin-top:12px">
							<a href="{$r['edit_review_url']}" style="font-size:12px;color:#2563eb;font-weight:500;text-decoration:none;display:inline-flex;align-items:center;gap:4px">
								<i class="fa-solid fa-pen-to-square" aria-hidden="true"></i> Edit your review
							</a>
						</div>
						{{endif}}

					</div>
					{{endforeach}}
				{{endif}}
			</div>
		</div>
	</div>

</div>
TEMPLATE_EOT;

$templates = [
	[
		'template_name' => 'dealerReviews',
		'template_data' => '$data, $csrfKey',
		'template_content' => $dealerReviewsContent,
	],
	[
		'template_name' => 'dealerProfile',
		'template_data' => '$dealer, $stats, $reviews, $canRate, $alreadyRated, $loginRequired, $rateUrl, $csrfKey, $loginUrl, $customerDispute, $guidelinesUrl',
		'template_content' => $dealerProfileContent,
	],
];

foreach ( $templates as $t )
{
	$existingId = NULL;
	try
	{
		$existingId = (int) \IPS\Db::i()->select( 'template_id', 'core_theme_templates', [
			'template_app=? AND template_location=? AND template_group=? AND template_name=? AND template_set_id=?',
			'gddealer', 'front', 'dealers', $t['template_name'], 1,
		] )->first();
	}
	catch ( \Exception )
	{
		$existingId = NULL;
	}

	$row = [
		'template_set_id'   => 1,
		'template_app'      => 'gddealer',
		'template_location' => 'front',
		'template_group'    => 'dealers',
		'template_name'     => $t['template_name'],
		'template_data'     => $t['template_data'],
		'template_content'  => $t['template_content'],
	];

	if ( $existingId )
	{
		$row['template_id'] = $existingId;
	}

	try
	{
		\IPS\Db::i()->replace( 'core_theme_templates', $row );
	}
	catch ( \Exception )
	{
		/* Fallback explicit update/insert if the unique-index composite
		   doesn't match the REPLACE semantics on this schema variant. */
		try
		{
			$exists = (int) \IPS\Db::i()->select( 'COUNT(*)', 'core_theme_templates', [
				'template_app=? AND template_location=? AND template_group=? AND template_name=?',
				'gddealer', 'front', 'dealers', $t['template_name'],
			] )->first();

			if ( $exists > 0 )
			{
				\IPS\Db::i()->update( 'core_theme_templates', [
					'template_data'    => $t['template_data'],
					'template_content' => $t['template_content'],
				], [
					'template_app=? AND template_location=? AND template_group=? AND template_name=?',
					'gddealer', 'front', 'dealers', $t['template_name'],
				] );
			}
			else
			{
				\IPS\Db::i()->insert( 'core_theme_templates', [
					'template_set_id'   => 1,
					'template_app'      => 'gddealer',
					'template_location' => 'front',
					'template_group'    => 'dealers',
					'template_name'     => $t['template_name'],
					'template_data'     => $t['template_data'],
					'template_content'  => $t['template_content'],
				] );
			}
		}
		catch ( \Exception ) {}
	}
}

try { unset( \IPS\Data\Store::i()->themes ); }   catch ( \Exception ) {}
try { \IPS\Data\Cache::i()->clearAll(); }        catch ( \Exception ) {}
