<?php

namespace IPS\gdloadout\modules\front\loadouts;

use IPS\Db;
use IPS\Http\Url;
use IPS\Member;
use IPS\Output;
use IPS\Request;
use IPS\Session;
use IPS\Theme;
use function defined;

if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

class _builder extends \IPS\Dispatcher\Controller
{
	public static bool $csrfProtected = TRUE;

	public function execute(): void
	{
		if ( !Member::loggedIn()->member_id )
		{
			Output::i()->error( 'no_module_permission', '2GL02/1', 403 );
			return;
		}
		parent::execute();
	}

	protected function isVip( Member $member ): bool
	{
		try
		{
			$vipGroupIds = [];
			foreach ( \IPS\Member\Group::groups( TRUE, FALSE ) as $g )
			{
				if ( mb_stripos( (string) $g->name, 'VIP' ) !== FALSE )
				{
					$vipGroupIds[] = (int) $g->g_id;
				}
			}
			if ( \in_array( (int) $member->member_group_id, $vipGroupIds, true ) ) return true;
			$secondary = $member->mgroup_others ?? '';
			if ( $secondary )
			{
				foreach ( explode( ',', $secondary ) as $sg )
				{
					if ( \in_array( (int) trim( $sg ), $vipGroupIds, true ) ) return true;
				}
			}
		}
		catch ( \Throwable ) {}
		return false;
	}

	protected function manage(): void
	{
		$member = Member::loggedIn();
		$editId = (int) ( Request::i()->loadout_id ?? Request::i()->id ?? 0 );
		$loadout = NULL;
		$items   = [];

		if ( $editId )
		{
			try
			{
				$loadout = Db::i()->select( '*', 'gd_loadouts', [ 'id=? AND member_id=?', $editId, (int) $member->member_id ] )->first();
				foreach ( Db::i()->select( '*', 'gd_loadout_items', [ 'loadout_id=?', $editId ], 'sort_order ASC' ) as $item )
				{
					if ( !empty( $item['upc'] ) )
					{
						try
						{
							$cat = Db::i()->select( 'title, brand, image_url', 'gd_catalog', [ 'upc=?', $item['upc'] ] )->first();
							$item['title'] = $cat['title'] ?? '';
							$item['brand'] = $cat['brand'] ?? '';
							$item['image_url'] = $cat['image_url'] ?? '';
						}
						catch ( \UnderflowException ) { $item['title'] = ''; }
						try
						{
							$item['price_snapshot'] = (float) Db::i()->select( 'MIN(dealer_price)', 'gd_dealer_listings', [ 'upc=? AND listing_status=?', $item['upc'], 'active' ] )->first();
						}
						catch ( \Throwable ) { $item['price_snapshot'] = null; }
					}
					$items[] = $item;
				}
			}
			catch ( \Throwable )
			{
				Output::i()->error( 'gdloadout_err_not_found', '2GL02/2', 404 );
				return;
			}
		}
		else
		{
			if ( !\IPS\gdloadout\Loadout\Limits::canCreateLoadout( $member ) )
			{
				Output::i()->error( 'gdloadout_err_limit_loadouts', '2GL02/3', 403 );
				return;
			}
		}

		$limits  = \IPS\gdloadout\Loadout\Limits::forMember( $member );
		$isVip   = $this->isVip( $member );

		$saveUrl   = (string) Url::internal( 'app=gdloadout&module=loadouts&controller=builder&do=save', 'front', 'gdloadout_builder' );
		$deleteUrl = (string) Url::internal( 'app=gdloadout&module=loadouts&controller=builder&do=delete', 'front', 'gdloadout_builder' );
		$searchUrl = (string) Url::internal( 'app=gdloadout&module=loadouts&controller=builder&do=search', 'front', 'gdloadout_builder' );
		$csrfKey   = Session::i()->csrfKey;

		$initData = json_encode( [
			'loadout'            => $loadout,
			'items'              => $items,
			'completeFirearmCore' => \IPS\gdloadout\Loadout\Slots::COMPLETE_FIREARM_CORE,
			'componentCore'      => \IPS\gdloadout\Loadout\Slots::COMPONENT_CORE,
			'accessorySlots'     => \IPS\gdloadout\Loadout\Slots::ACCESSORY_SLOTS,
			'slotCategories'     => \IPS\gdloadout\Loadout\Slots::SLOT_CATEGORIES,
			'platforms'          => \IPS\gdloadout\Loadout\Slots::PLATFORMS,
			'limits'             => $limits,
			'isVip'              => $isVip,
			'saveUrl'            => $saveUrl,
			'deleteUrl'          => $deleteUrl,
			'searchUrl'          => $searchUrl,
			'csrfKey'            => $csrfKey,
		], JSON_HEX_TAG | JSON_HEX_AMP );

		Output::i()->cssFiles = array_merge( Output::i()->cssFiles, Theme::i()->css( 'loadouts.css', 'gdloadout', 'interface' ) );
		Output::i()->jsFiles  = array_merge( Output::i()->jsFiles, Output::i()->js( 'builder.js', 'gdloadout', 'interface' ) );
		Output::i()->title    = Member::loggedIn()->language()->addToStack( 'gdloadout_builder_title' );
		Output::i()->output   = Theme::i()->getTemplate( 'loadouts', 'gdloadout', 'front' )->builder( $initData );
	}

	protected function save(): void
	{
		Session::i()->csrfCheck();

		$member = Member::loggedIn();
		$editId = (int) ( Request::i()->loadout_id ?? 0 );
		$name   = trim( Request::i()->loadout_name ?? '' );

		if ( $name === '' )
		{
			Output::i()->json( [ 'error' => Member::loggedIn()->language()->addToStack( 'gdloadout_err_name_required' ) ], 400 );
			return;
		}

		$slug        = \IPS\gdloadout\Loadout\Loadout::slugify( $name );
		$description = trim( Request::i()->loadout_description ?? '' );
		$useCase     = trim( Request::i()->loadout_use_case ?? '' );
		$visibility  = Request::i()->loadout_visibility ?? 'unlisted';

		$buildModeParam = trim( Request::i()->loadout_build_mode ?? 'complete_firearm' );
		if ( !\in_array( $buildModeParam, [ 'complete_firearm', 'component_build' ], true ) )
		{
			$buildModeParam = 'complete_firearm';
		}

		$platformParam = trim( Request::i()->loadout_platform ?? '' );
		$validPlatforms = array_keys( \IPS\gdloadout\Loadout\Slots::PLATFORMS );
		if ( $platformParam !== '' && !\in_array( $platformParam, $validPlatforms, true ) )
		{
			$platformParam = '';
		}

		if ( !\in_array( $visibility, [ 'public', 'unlisted', 'private' ], true ) )
		{
			$visibility = 'unlisted';
		}

		$isVip = $this->isVip( $member );
		if ( $visibility === 'private' && !$isVip )
		{
			$visibility = 'unlisted';
		}

		$slotsJson = Request::i()->loadout_slots ?? '[]';
		$slots     = json_decode( $slotsJson, true );
		if ( !\is_array( $slots ) ) $slots = [];

		$limits = \IPS\gdloadout\Loadout\Limits::forMember( $member );
		if ( $limits['max_slots'] > 0 && \count( $slots ) > $limits['max_slots'] )
		{
			Output::i()->json( [ 'error' => Member::loggedIn()->language()->addToStack( 'gdloadout_err_limit_slots' ) ], 400 );
			return;
		}

		if ( $editId )
		{
			try
			{
				$existing = Db::i()->select( '*', 'gd_loadouts', [ 'id=? AND member_id=?', $editId, (int) $member->member_id ] )->first();
			}
			catch ( \Throwable )
			{
				Output::i()->json( [ 'error' => Member::loggedIn()->language()->addToStack( 'gdloadout_err_not_found' ) ], 404 );
				return;
			}

			$slotsWithUpc = 0;
			foreach ( $slots as $s )
			{
				if ( !empty( $s['upc'] ) ) $slotsWithUpc++;
			}
			if ( $slotsWithUpc === 0 )
			{
				Output::i()->json( [ 'error' => 'No items to save — cannot overwrite existing build with empty loadout.' ], 400 );
				return;
			}

			$uniqueSlug = $slug;
			$counter = 1;
			while ( true )
			{
				try
				{
					Db::i()->select( 'id', 'gd_loadouts', [ 'member_id=? AND slug=? AND id!=?', (int) $member->member_id, $uniqueSlug, $editId ] )->first();
					$counter++;
					$uniqueSlug = $slug . '-' . $counter;
				}
				catch ( \Throwable ) { break; }
			}

			Db::i()->update( 'gd_loadouts', [
				'name' => $name, 'slug' => $uniqueSlug,
				'description' => $description ?: NULL, 'use_case' => $useCase ?: NULL,
				'visibility' => $visibility, 'build_mode' => $buildModeParam,
				'platform' => $platformParam ?: NULL, 'updated_at' => time(),
			], [ 'id=?', $editId ] );

			$loadoutId = $editId;

			if ( \in_array( $visibility, [ 'public', 'unlisted' ], true ) )
			{
				try
				{
					$followers = [];
					foreach ( Db::i()->select( 'member_id', 'gd_loadout_follows', [ 'loadout_id=?', $editId ] ) as $fid )
					{
						if ( (int) $fid !== (int) $member->member_id ) $followers[] = (int) $fid;
					}
					if ( $followers )
					{
						$notification = new \IPS\Notification(
							\IPS\Application::load( 'gdloadout' ), 'loadout_updated', $member, [],
							[ 'loadout_name' => $name, 'author_name' => $member->name, 'username' => $member->name, 'slug' => $uniqueSlug ]
						);
						foreach ( $followers as $fMemberId )
						{
							try { $notification->recipients->attach( Member::load( $fMemberId ) ); } catch ( \Throwable ) {}
						}
						$notification->send();
					}
				}
				catch ( \Throwable ) {}
			}

			Db::i()->delete( 'gd_loadout_items', [ 'loadout_id=?', $loadoutId ] );
		}
		else
		{
			if ( !\IPS\gdloadout\Loadout\Limits::canCreateLoadout( $member ) )
			{
				Output::i()->json( [ 'error' => Member::loggedIn()->language()->addToStack( 'gdloadout_err_limit_loadouts' ) ], 403 );
				return;
			}

			$uniqueSlug = $slug;
			$counter = 1;
			while ( true )
			{
				try
				{
					Db::i()->select( 'id', 'gd_loadouts', [ 'member_id=? AND slug=?', (int) $member->member_id, $uniqueSlug ] )->first();
					$counter++;
					$uniqueSlug = $slug . '-' . $counter;
				}
				catch ( \Throwable ) { break; }
			}

			$loadoutId = Db::i()->insert( 'gd_loadouts', [
				'member_id' => (int) $member->member_id, 'name' => $name, 'slug' => $uniqueSlug,
				'description' => $description ?: NULL, 'use_case' => $useCase ?: NULL,
				'visibility' => $visibility, 'build_mode' => $buildModeParam,
				'platform' => $platformParam ?: NULL, 'created_at' => time(),
			] );
		}

		$completeSlots  = [ 'base_firearm', 'optic', 'weapon_light', 'laser', 'suppressor', 'sling', 'rail_mount', 'scope_rings' ];
		$componentSlots = [ 'lower_receiver', 'upper_receiver', 'barrel', 'handguard', 'muzzle', 'bcg', 'buffer', 'trigger', 'stock', 'grip', 'optic', 'scope_rings', 'rail_mount', 'weapon_light', 'laser', 'suppressor', 'sling' ];
		$extraSlots     = [ 'magazine', 'holster', 'ear_eye_pro', 'cleaning', 'bipod', 'extra' ];
		$allowedForMode = array_merge(
			( $buildModeParam === 'component_build' ) ? $componentSlots : $completeSlots,
			$extraSlots
		);
		$totalCost = 0; $totalItems = 0; $order = 0;

		foreach ( $slots as $slot )
		{
			if ( empty( $slot['upc'] ) ) continue;
			$slotType = $slot['slot_type'] ?? 'extra';
			if ( !\in_array( $slotType, $allowedForMode, true ) ) continue;

			$notes = NULL;
			if ( $isVip && !empty( $slot['notes'] ) ) $notes = substr( trim( $slot['notes'] ), 0, 300 );

			Db::i()->insert( 'gd_loadout_items', [
				'loadout_id' => (int) $loadoutId, 'upc' => substr( trim( $slot['upc'] ), 0, 20 ),
				'slot_type' => $slotType, 'custom_label' => !empty( $slot['custom_label'] ) ? substr( trim( $slot['custom_label'] ), 0, 100 ) : NULL,
				'sort_order' => $order, 'notes' => $notes, 'added_at' => time(),
			] );
			$totalItems++; $order++;
			if ( isset( $slot['price'] ) && (float) $slot['price'] > 0 ) $totalCost += (float) $slot['price'];
		}

		Db::i()->update( 'gd_loadouts', [
			'total_items' => $totalItems,
			'total_min_price' => $totalCost > 0 ? round( $totalCost, 2 ) : NULL,
		], [ 'id=?', (int) $loadoutId ] );

		if ( \in_array( $visibility, [ 'public', 'unlisted' ], true ) )
		{
			try
			{
				$savedRow = Db::i()->select( '*', 'gd_loadouts', [ 'id=?', (int) $loadoutId ] )->first();
				_hub::ensureForumTopic( $savedRow );
			}
			catch ( \Throwable ) {}
		}

		$ownerName = $member->name ?? 'user';
		$loadoutSlug = $uniqueSlug ?? $slug;
		$viewUrl = (string) Url::internal(
			'app=gdloadout&module=loadouts&controller=hub&do=view&username=' . urlencode( $ownerName ) . '&slug=' . urlencode( $loadoutSlug ),
			'front', 'gdloadout_view'
		);

		Output::i()->json( [ 'ok' => true, 'loadout_id' => (int) $loadoutId, 'redirect' => $viewUrl ] );
	}

	protected function delete(): void
	{
		Session::i()->csrfCheck();
		$member = Member::loggedIn();
		$id = (int) ( Request::i()->loadout_id ?? 0 );

		try { Db::i()->select( 'id', 'gd_loadouts', [ 'id=? AND member_id=?', $id, (int) $member->member_id ] )->first(); }
		catch ( \Throwable ) { Output::i()->json( [ 'error' => Member::loggedIn()->language()->addToStack( 'gdloadout_err_not_found' ) ], 404 ); return; }

		Db::i()->delete( 'gd_loadout_items', [ 'loadout_id=?', $id ] );
		Db::i()->delete( 'gd_loadout_votes', [ 'loadout_id=?', $id ] );
		Db::i()->delete( 'gd_loadout_follows', [ 'loadout_id=?', $id ] );
		Db::i()->delete( 'gd_loadout_forum_posts', [ 'loadout_id=?', $id ] );
		Db::i()->delete( 'gd_loadouts', [ 'id=?', $id ] );
		Output::i()->json( [ 'ok' => true ] );
	}

	protected function search(): void
	{
		$query = trim( (string) ( Request::i()->q ?? '' ) );
		$page  = max( 1, (int) ( Request::i()->page ?? 1 ) );

		$categoryParam = Request::i()->category ?? '';
		$cats = [];
		if ( \is_array( $categoryParam ) )
		{
			$cats = array_values( array_filter( array_map( 'trim', $categoryParam ) ) );
		}
		elseif ( (string) $categoryParam !== '' )
		{
			if ( strpos( (string) $categoryParam, ',' ) !== false )
			{
				$cats = array_values( array_filter( array_map( 'trim', explode( ',', (string) $categoryParam ) ) ) );
			}
			else
			{
				$cats = [ trim( (string) $categoryParam ) ];
			}
		}

		if ( mb_strlen( $query ) < 2 && empty( $cats ) )
		{
			Output::i()->json( [ 'total' => 0, 'results' => [] ] );
			return;
		}

		try
		{
			$matchedUpcs = [];

			if ( $query !== '' && preg_match( '/^[0-9]{8,14}$/', $query ) )
			{
				try
				{
					$u = (string) Db::i()->select( 'upc', 'gd_catalog', [ 'upc=? AND record_status=?', $query, 'active' ] )->first();
					if ( $u !== '' ) $matchedUpcs[] = $u;
				}
				catch ( \UnderflowException ) {}
			}

			if ( !$matchedUpcs && $query !== '' )
			{
				try
				{
					foreach ( Db::i()->select( 'upc', 'gd_catalog', [ 'mpn=? AND record_status=?', $query, 'active' ], 'id ASC', 24 ) as $u )
					{
						$matchedUpcs[] = (string) $u;
					}
				}
				catch ( \Throwable ) {}
			}

			if ( $matchedUpcs )
			{
				$out = [];
				foreach ( $matchedUpcs as $u )
				{
					try
					{
						$row = Db::i()->select( '*', 'gd_catalog', [ 'upc=?', $u ] )->first();
						$price = NULL; $dealers = 0;
						try
						{
							$p = Db::i()->select( 'MIN(dealer_price) AS best_price, COUNT(DISTINCT dealer_id) AS dealer_count', 'gd_dealer_listings', [ 'upc=? AND listing_status=?', $u, 'active' ] )->first();
							$price   = ( $p['best_price'] !== NULL && (float) $p['best_price'] > 0 ) ? (float) $p['best_price'] : NULL;
							$dealers = (int) $p['dealer_count'];
						}
						catch ( \Throwable ) {}
						$out[] = [
							'upc' => $u, 'title' => $row['title'] ?? '', 'brand' => $row['brand'] ?? '',
							'best_price' => $price, 'dealer_count' => $dealers, 'in_stock' => $dealers > 0,
							'category' => $row['category'] ?? '', 'caliber' => $row['caliber'] ?? '',
							'image_url' => (string) ( $row['image_url'] ?? '' ),
						];
					}
					catch ( \Throwable ) {}
				}
				Output::i()->json( [ 'total' => \count( $out ), 'results' => $out ] );
				return;
			}

			$arr = function ( $v ) {
				if ( \is_array( $v ) ) { return array_values( array_filter( array_map( fn( $x ) => trim( (string) $x ), $v ), fn( $x ) => $x !== '' ) ); }
				$v = trim( (string) $v );
				return $v !== '' ? [ $v ] : [];
			};

			$filters = [];
			if ( $cats )
			{
				$catField = ( Request::i()->catfield ?? '' ) === 'subcategory' ? 'subcategory' : 'category';
				$filters[ $catField ] = \count( $cats ) === 1 ? $cats[0] : $cats;
			}

			foreach ( [
				'brand', 'caliber', 'action', 'casing', 'bullet_type', 'capacity',
				'holster_type', 'holster_color', 'holster_material', 'holster_hand',
				'apparel_pattern', 'apparel_size', 'apparel_material',
				'blade_shape', 'blade_length', 'blade_material', 'blade_edge', 'knife_handle',
				'hunt_call_type', 'hunt_game', 'optic_magnification', 'optic_objective',
			] as $facetKey )
			{
				$val = $arr( Request::i()->$facetKey ?? [] );
				if ( $val ) { $filters[ $facetKey ] = $val; }
			}

			if ( !empty( Request::i()->in_stock ) )  { $filters['in_stock'] = true; }
			$minPrice = (float) ( Request::i()->min_price ?? 0 );
			$maxPrice = (float) ( Request::i()->max_price ?? 0 );
			if ( $minPrice > 0 ) { $filters['min_price'] = $minPrice; }
			if ( $maxPrice > 0 ) { $filters['max_price'] = $maxPrice; }

			$sortParam = trim( (string) ( Request::i()->sort ?? 'relevance' ) );
			$allowedSorts = [ 'relevance', 'brand' ];
			$sort = \in_array( $sortParam, $allowedSorts, true ) ? $sortParam : 'relevance';

			$searcher = new \IPS\gdsearch\Search\Searcher();
			$result   = $searcher->search( $query, $filters, $sort, $page, 24 );

			$aggs = $result['aggregations'] ?? [];
			foreach ( [ 'calibers', 'actions', 'capacities', 'casings', 'bullet_types',
				'holster_types', 'holster_colors', 'holster_materials', 'holster_hands',
				'apparel_patterns', 'apparel_sizes', 'apparel_materials',
				'blade_shapes', 'blade_lengths', 'blade_materials', 'blade_edges', 'knife_handles',
				'hunt_call_types', 'hunt_games', 'optics_mags', 'optics_objs' ] as $scopedAgg )
			{
				if ( isset( $aggs[ $scopedAgg ]['values']['buckets'] ) )
				{
					$aggs[ $scopedAgg ]['buckets'] = $aggs[ $scopedAgg ]['values']['buckets'];
				}
			}

			foreach ( [ 'brands', 'calibers', 'actions', 'capacities', 'casings', 'bullet_types',
				'holster_types', 'holster_colors', 'holster_materials', 'holster_hands',
				'apparel_patterns', 'apparel_sizes', 'apparel_materials',
				'blade_shapes', 'blade_lengths', 'blade_materials', 'blade_edges', 'knife_handles',
				'hunt_call_types', 'hunt_games', 'optics_mags', 'optics_objs' ] as $aggKey )
			{
				if ( isset( $aggs[ $aggKey ]['buckets'] ) && \is_array( $aggs[ $aggKey ]['buckets'] ) )
				{
					$aggs[ $aggKey ]['buckets'] = array_values( array_filter(
						$aggs[ $aggKey ]['buckets'],
						static function ( $b ) { return trim( (string) ( $b['key'] ?? '' ) ) !== ''; }
					) );
					if ( empty( $aggs[ $aggKey ]['buckets'] ) ) { unset( $aggs[ $aggKey ] ); }
				}
				else
				{
					unset( $aggs[ $aggKey ] );
				}
			}
			unset( $aggs['categories'] );

			$cleanAggs = [];
			foreach ( $aggs as $k => $v )
			{
				if ( !empty( $v['buckets'] ) ) { $cleanAggs[ $k ] = [ 'buckets' => $v['buckets'] ]; }
			}

			$out = [];
			foreach ( ( $result['results'] ?? [] ) as $r )
			{
				$img = ''; $catTitle = ''; $catBrand = '';
				if ( !empty( $r['upc'] ) )
				{
					try {
						$cat = Db::i()->select( 'title, brand, image_url', 'gd_catalog', [ 'upc=?', $r['upc'] ] )->first();
						$catTitle = (string) ( $cat['title'] ?? '' );
						$catBrand = (string) ( $cat['brand'] ?? '' );
						$img      = (string) ( $cat['image_url'] ?? '' );
					} catch ( \Throwable ) {}
				}
				$out[] = [
					'upc'         => $r['upc'] ?? '',
					'title'       => $catTitle !== '' ? $catTitle : ( $r['title'] ?? '' ),
					'brand'       => $catBrand !== '' ? $catBrand : ( $r['brand'] ?? '' ),
					'best_price'  => $r['best_price'] ?? null,
					'dealer_count'=> $r['dealer_count'] ?? 0,
					'in_stock'    => $r['in_stock'] ?? false,
					'category'    => $r['category'] ?? '',
					'caliber'     => $r['caliber'] ?? '',
					'image_url'   => $img,
				];
			}
			Output::i()->json( [ 'total' => $result['total'] ?? 0, 'results' => $out, 'aggregations' => $cleanAggs ] );
		}
		catch ( \Throwable $e )
		{
			try { \IPS\Log::log( $e, 'gdloadout_search' ); } catch ( \Throwable ) {}
			Output::i()->json( [ 'total' => 0, 'results' => [] ] );
		}
	}
}

class builder extends _builder {}
