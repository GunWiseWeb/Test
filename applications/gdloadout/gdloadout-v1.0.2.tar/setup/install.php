<?php

if ( !\defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

$gdloadoutTemplates = [

	[
		'set_id'        => 1,
		'app'           => 'gdloadout',
		'location'      => 'front',
		'group'         => 'loadouts',
		'template_name' => 'hub',
		'template_data' => '$loadouts, $canCreate, $builderUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox">
	<div class="ipsBox_container">
		<div style="display:flex;justify-content:space-between;align-items:center;padding:16px 20px;border-bottom:1px solid var(--i-border-color,#e0e0e0)">
			<h1 class="ipsType_pageTitle">{lang="gdloadout_hub_title"}</h1>
			{{if $canCreate}}
			<a href="{$builderUrl}" class="ipsButton ipsButton--primary ipsButton--small"><i class="fa-solid fa-plus"></i> New Loadout</a>
			{{endif}}
		</div>
		{{if count($loadouts) > 0}}
		<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;padding:20px">
			{{foreach $loadouts as $lo}}
			<div style="border:1px solid var(--i-border-color,#e0e0e0);border-radius:8px;padding:16px;background:var(--i-background,#fff)">
				<div style="font-weight:700;font-size:1.1em;margin-bottom:6px">{expression="htmlspecialchars($lo['name'])"}</div>
				{{if $lo['use_case']}}
				<div style="font-size:0.85em;color:#666;margin-bottom:8px">{expression="htmlspecialchars($lo['use_case'])"}</div>
				{{endif}}
				<div style="display:flex;gap:12px;font-size:0.85em;color:#888">
					<span><i class="fa-solid fa-box"></i> {expression="(int)$lo['total_items']"} items</span>
					{{if $lo['total_min_price']}}
					<span><i class="fa-solid fa-dollar-sign"></i> {expression="number_format((float)$lo['total_min_price'],2)"}</span>
					{{endif}}
					<span><i class="fa-solid fa-arrow-up"></i> {expression="(int)$lo['upvotes']"}</span>
				</div>
			</div>
			{{endforeach}}
		</div>
		{{else}}
		<div style="text-align:center;padding:60px 20px;color:#888">
			<i class="fa-solid fa-layer-group" style="font-size:3em;margin-bottom:12px;display:block;opacity:0.4"></i>
			<p>{lang="gdloadout_hub_empty"}</p>
			{{if $canCreate}}
			<a href="{$builderUrl}" class="ipsButton ipsButton--primary" style="margin-top:16px"><i class="fa-solid fa-plus"></i> Create Your First Build</a>
			{{endif}}
		</div>
		{{endif}}
	</div>
</div>
TEMPLATE_EOT,
	],

	[
		'set_id'        => 1,
		'app'           => 'gdloadout',
		'location'      => 'front',
		'group'         => 'loadouts',
		'template_name' => 'builder',
		'template_data' => '$initData',
		'template_content' => <<<'TEMPLATE_EOT'
<script type="application/json" id="gdlo-init">{$initData}</script>
<div id="gdLoadoutBuilder">

<div class="gdlo-canvas">

	<div class="gdlo-left">
		<div class="gdlo-field">
			<input type="text" id="gdLoadoutName" placeholder="{lang="gdloadout_builder_name"}" class="gdlo-input gdlo-input--title" />
		</div>
		<div class="gdlo-field">
			<textarea id="gdLoadoutDesc" placeholder="{lang="gdloadout_builder_description"}" rows="2" class="gdlo-input"></textarea>
		</div>
		<div class="gdlo-meta-row">
			<select id="gdLoadoutUseCase" class="gdlo-select">
				<option value="">-- {lang="gdloadout_builder_use_case"} --</option>
				<option value="Home Defense">{lang="gdloadout_use_case_home_defense"}</option>
				<option value="Concealed Carry">{lang="gdloadout_use_case_concealed_carry"}</option>
				<option value="Hunting">{lang="gdloadout_use_case_hunting"}</option>
				<option value="Competition">{lang="gdloadout_use_case_competition"}</option>
				<option value="Range">{lang="gdloadout_use_case_range"}</option>
				<option value="Tactical">{lang="gdloadout_use_case_tactical"}</option>
				<option value="Collection">{lang="gdloadout_use_case_collection"}</option>
			</select>
			<select id="gdLoadoutVisibility" class="gdlo-select">
				<option value="public">{lang="gdloadout_vis_public"}</option>
				<option value="unlisted" selected>{lang="gdloadout_vis_unlisted"}</option>
			</select>
		</div>

		<div class="gdlo-section-label">Core Slots</div>
		<div id="gdSlotGrid" class="gdlo-slot-grid"></div>

		<div class="gdlo-section-label">Extras</div>
		<div id="gdExtraSlots" class="gdlo-extra-slots"></div>
		<button type="button" id="gdAddExtra" class="ipsButton ipsButton--small ipsButton--light gdlo-add-extra">{lang="gdloadout_builder_add_extra"}</button>

		<div id="gdExtraPicker" class="gdlo-picker" style="display:none">
			<div class="gdlo-picker-title">Add Slot</div>
			<div id="gdExtraChips" class="gdlo-chips"></div>
			<div class="gdlo-picker-custom">
				<input type="text" id="gdCustomSlotName" placeholder="Custom slot name..." class="gdlo-input gdlo-input--sm" />
				<button type="button" id="gdAddCustomSlot" class="ipsButton ipsButton--small ipsButton--primary">Add</button>
			</div>
		</div>
	</div>

	<div class="gdlo-right">
		<div class="gdlo-sticky">
			<div class="gdlo-panel">
				<div class="gdlo-panel-head">Product Search</div>
				<div class="gdlo-panel-body">
					<input type="text" id="gdSearchInput" placeholder="{lang="gdloadout_builder_search"}" class="gdlo-input" />
				</div>
				<div id="gdSearchResults" class="gdlo-search-results"></div>
			</div>

			<div class="gdlo-panel">
				<div class="gdlo-panel-head">{lang="gdloadout_builder_total_cost"}</div>
				<div class="gdlo-summary-body">
					<div id="gdTotalCost" class="gdlo-total-cost">$0.00</div>
					<div id="gdTotalItems" class="gdlo-total-items">0 items</div>
				</div>
				<div id="gdItemBreakdown" class="gdlo-breakdown"></div>
			</div>

			<div id="gdVipNotes" class="gdlo-panel" style="display:none">
				<div class="gdlo-panel-head">Item Notes (VIP)</div>
				<div id="gdNotesBody" class="gdlo-panel-body"></div>
			</div>

			<div class="gdlo-actions">
				<button type="button" id="gdSaveBtn" class="ipsButton ipsButton--primary gdlo-save-btn">{lang="gdloadout_builder_save"}</button>
				<button type="button" id="gdDeleteBtn" class="ipsButton ipsButton--negative" style="display:none">{lang="gdloadout_builder_delete"}</button>
			</div>
		</div>
	</div>

</div>
</div>
TEMPLATE_EOT,
	],

	[
		'set_id'        => 1,
		'app'           => 'gdloadout',
		'location'      => 'admin',
		'group'         => 'manage',
		'template_name' => 'limits',
		'template_data' => '$groups, $limits, $csrfKey, $saveUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">
		<h2 style="margin-bottom:16px">{lang="gdloadout_limits_title"}</h2>
		<p style="color:#666;margin-bottom:20px">{lang="gdloadout_limits_unlimited"}</p>
		<form method="post" action="{$saveUrl}">
			<input type="hidden" name="csrfKey" value="{$csrfKey}" />
			<table class="ipsTable ipsTable_zebra" style="width:100%">
				<thead>
					<tr>
						<th>{lang="gdloadout_limits_group"}</th>
						<th style="width:160px">{lang="gdloadout_limits_max_loadouts"}</th>
						<th style="width:160px">{lang="gdloadout_limits_max_slots"}</th>
					</tr>
				</thead>
				<tbody>
					{{foreach $groups as $gid => $gname}}
					<tr>
						<td>{expression="htmlspecialchars($gname)"}</td>
						<td><input type="number" name="group_limits[{expression="(int)$gid"}][max_loadouts]" value="{expression="isset($limits[$gid]) ? (int)$limits[$gid]['max_loadouts'] : 0"}" min="0" style="width:100%;padding:6px 10px;border:1px solid #ccc;border-radius:4px;box-sizing:border-box" /></td>
						<td><input type="number" name="group_limits[{expression="(int)$gid"}][max_slots]" value="{expression="isset($limits[$gid]) ? (int)$limits[$gid]['max_slots'] : 15"}" min="0" style="width:100%;padding:6px 10px;border:1px solid #ccc;border-radius:4px;box-sizing:border-box" /></td>
					</tr>
					{{endforeach}}
				</tbody>
			</table>
			<div style="margin-top:16px">
				<button type="submit" class="ipsButton ipsButton--primary">{lang="gdloadout_builder_save"}</button>
			</div>
		</form>
	</div>
</div>
TEMPLATE_EOT,
	],

];

foreach ( $gdloadoutTemplates as $tpl )
{
	try
	{
		\IPS\Db::i()->replace( 'core_theme_templates', [
			'template_set_id'  => (int) $tpl['set_id'],
			'template_app'     => $tpl['app'],
			'template_location' => $tpl['location'],
			'template_group'   => $tpl['group'],
			'template_name'    => $tpl['template_name'],
			'template_data'    => $tpl['template_data'],
			'template_content' => $tpl['template_content'],
			'template_updated' => time(),
			'template_version' => '1.0.2',
		] );
	}
	catch ( \Throwable ) {}
}

try
{
	\IPS\core\FrontNavigation::buildDefaultFrontNavigation();
}
catch ( \Throwable ) {}

try
{
	$existing = (int) \IPS\Db::i()->select( 'COUNT(*)', 'gd_loadout_group_limits' )->first();
	if ( $existing === 0 )
	{
		foreach ( \IPS\Db::i()->select( 'g_id', 'core_groups' ) as $gid )
		{
			try
			{
				\IPS\Db::i()->replace( 'gd_loadout_group_limits', [
					'group_id'     => (int) $gid,
					'max_loadouts' => 0,
					'max_slots'    => 15,
				] );
			}
			catch ( \Throwable ) {}
		}
	}
}
catch ( \Throwable ) {}

try { unset( \IPS\Data\Store::i()->extensions ); }   catch ( \Throwable ) {}
try { unset( \IPS\Data\Store::i()->applications ); } catch ( \Throwable ) {}
try { \IPS\Data\Cache::i()->clearAll(); }             catch ( \Throwable ) {}
