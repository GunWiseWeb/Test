<?php

namespace IPS\gdloadout\setup\upg_10030;

if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

class _upgrade
{
	public function step1(): bool
	{
		$hubContent = <<<'TEMPLATE_EOT'
<div class="gdlo-hub">
    <div class="gdlo-hub-hero">
        <div class="gdlo-hub-hero-text">
            <h1 class="gdlo-hub-title">{lang="gdloadout_hub_title"}</h1>
            <p class="gdlo-hub-subtitle">{lang="gdloadout_hub_subtitle"}</p>
        </div>
        {{if $canCreate}}
        <a href="{$builderUrl}" class="gdlo-btn gdlo-btn--primary"><i class="fa-solid fa-plus"></i> {lang="gdloadout_new_loadout"}</a>
        {{endif}}
    </div>
    <div class="gdlo-hub-tabs">
        <a href="{expression="\IPS\Http\Url::internal('app=gdloadout&module=loadouts&controller=hub', 'front', 'gdloadout_hub')"}" class="gdlo-hub-tab gdlo-hub-tab--active">{lang="gdloadout_browse_all"}</a>
        <a href="{$myLoadoutsUrl}" class="gdlo-hub-tab">{lang="gdloadout_my_loadouts"}</a>
    </div>
    <div class="gdlo-hub-filters">
        <a href="{expression="\IPS\Http\Url::internal('app=gdloadout&module=loadouts&controller=hub', 'front', 'gdloadout_hub')"}" class="gdlo-hub-pill{{if $activeUseCase === ''}} gdlo-hub-pill--active{{endif}}">All</a>
        {{foreach $useCases as $uc}}
        <a href="{expression="\IPS\Http\Url::internal('app=gdloadout&module=loadouts&controller=hub&use_case=' . urlencode($uc), 'front', 'gdloadout_hub')"}" class="gdlo-hub-pill{{if $activeUseCase === $uc}} gdlo-hub-pill--active{{endif}}">{$uc}</a>
        {{endforeach}}
    </div>
    {{if count($sections['featured']) > 0}}
    <div class="gdlo-hub-section">
        <h2 class="gdlo-hub-section-title"><i class="fa-solid fa-star"></i> {lang="gdloadout_featured"}</h2>
        <div class="gdlo-hub-grid">
            {{foreach $sections['featured'] as $loadout}}
            <div class="gdlo-hub-card gdlo-hub-card--featured">
                <div class="gdlo-hub-card-img">{{if $loadout['base_image']}}<img src="{$loadout['base_image']}" alt="{$loadout['base_title']}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><div class="gdlo-hub-card-noimg" style="display:none"><i class="fa-solid fa-gun"></i></div>{{else}}<div class="gdlo-hub-card-noimg"><i class="fa-solid fa-gun"></i></div>{{endif}}</div>
                <div class="gdlo-hub-card-body"><a href="{$loadout['view_url']}" class="gdlo-hub-card-name">{$loadout['name']}</a><div class="gdlo-hub-card-meta"><span class="gdlo-hub-card-author"><i class="fa-solid fa-user"></i> {$loadout['owner_name']}</span>{{if $loadout['mode_label']}}<span class="gdlo-hub-tag">{$loadout['mode_label']}</span>{{endif}}{{if $loadout['platform']}}<span class="gdlo-hub-tag">{$loadout['platform']}</span>{{endif}}</div><div class="gdlo-hub-price">{{if $loadout['total_min_price'] > 0}}<span class="gdlo-hub-price-val">{expression="'$' . number_format((float)$loadout['total_min_price'], 0)"}</span>{{else}}<span class="gdlo-hub-price-na">{lang="gdloadout_no_price_yet"}</span>{{endif}}<span class="gdlo-hub-price-parts">{$loadout['total_items']} {lang="gdloadout_parts"}</span></div><div class="gdlo-hub-card-stats"><span aria-label="{lang="gdloadout_upvote_loadout"}"><i class="fa-solid fa-heart" aria-hidden="true"></i> {$loadout['upvotes']}</span><span aria-label="{lang="gdloadout_follow_loadout"}"><i class="fa-solid fa-bell" aria-hidden="true"></i> {$loadout['follow_count']}</span></div></div>
                <div class="gdlo-hub-actions"><a href="{$loadout['view_url']}" class="gdlo-hub-btn gdlo-hub-btn--view"><i class="fa-solid fa-eye"></i> {lang="gdloadout_view_build"}</a><form method="post" action="{$copyUrl}" class="gdlo-hub-copy-form"><input type="hidden" name="csrfKey" value="{$csrfKey}" /><input type="hidden" name="loadout_id" value="{$loadout['id']}" /><button type="submit" class="gdlo-hub-btn gdlo-hub-btn--copy"><i class="fa-solid fa-copy"></i> {lang="gdloadout_copy_build"}</button></form></div>
            </div>
            {{endforeach}}
        </div>
    </div>
    {{endif}}
    {{if count($sections['trending']) > 0}}
    <div class="gdlo-hub-section">
        <h2 class="gdlo-hub-section-title"><i class="fa-solid fa-fire"></i> {lang="gdloadout_trending"}</h2>
        <div class="gdlo-hub-grid">
            {{foreach $sections['trending'] as $loadout}}
            <div class="gdlo-hub-card">
                <div class="gdlo-hub-card-img">{{if $loadout['base_image']}}<img src="{$loadout['base_image']}" alt="{$loadout['base_title']}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><div class="gdlo-hub-card-noimg" style="display:none"><i class="fa-solid fa-gun"></i></div>{{else}}<div class="gdlo-hub-card-noimg"><i class="fa-solid fa-gun"></i></div>{{endif}}</div>
                <div class="gdlo-hub-card-body"><a href="{$loadout['view_url']}" class="gdlo-hub-card-name">{$loadout['name']}</a><div class="gdlo-hub-card-meta"><span class="gdlo-hub-card-author"><i class="fa-solid fa-user"></i> {$loadout['owner_name']}</span>{{if $loadout['mode_label']}}<span class="gdlo-hub-tag">{$loadout['mode_label']}</span>{{endif}}{{if $loadout['platform']}}<span class="gdlo-hub-tag">{$loadout['platform']}</span>{{endif}}</div><div class="gdlo-hub-price">{{if $loadout['total_min_price'] > 0}}<span class="gdlo-hub-price-val">{expression="'$' . number_format((float)$loadout['total_min_price'], 0)"}</span>{{else}}<span class="gdlo-hub-price-na">{lang="gdloadout_no_price_yet"}</span>{{endif}}<span class="gdlo-hub-price-parts">{$loadout['total_items']} {lang="gdloadout_parts"}</span></div><div class="gdlo-hub-card-stats"><span aria-label="{lang="gdloadout_upvote_loadout"}"><i class="fa-solid fa-heart" aria-hidden="true"></i> {$loadout['upvotes']}</span><span aria-label="{lang="gdloadout_follow_loadout"}"><i class="fa-solid fa-bell" aria-hidden="true"></i> {$loadout['follow_count']}</span></div></div>
                <div class="gdlo-hub-actions"><a href="{$loadout['view_url']}" class="gdlo-hub-btn gdlo-hub-btn--view"><i class="fa-solid fa-eye"></i> {lang="gdloadout_view_build"}</a><form method="post" action="{$copyUrl}" class="gdlo-hub-copy-form"><input type="hidden" name="csrfKey" value="{$csrfKey}" /><input type="hidden" name="loadout_id" value="{$loadout['id']}" /><button type="submit" class="gdlo-hub-btn gdlo-hub-btn--copy"><i class="fa-solid fa-copy"></i> {lang="gdloadout_copy_build"}</button></form></div>
            </div>
            {{endforeach}}
        </div>
    </div>
    {{endif}}
    {{if count($sections['top_rated']) > 0}}
    <div class="gdlo-hub-section">
        <h2 class="gdlo-hub-section-title"><i class="fa-solid fa-trophy"></i> {lang="gdloadout_top_rated"}</h2>
        <div class="gdlo-hub-grid">
            {{foreach $sections['top_rated'] as $loadout}}
            <div class="gdlo-hub-card">
                <div class="gdlo-hub-card-img">{{if $loadout['base_image']}}<img src="{$loadout['base_image']}" alt="{$loadout['base_title']}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><div class="gdlo-hub-card-noimg" style="display:none"><i class="fa-solid fa-gun"></i></div>{{else}}<div class="gdlo-hub-card-noimg"><i class="fa-solid fa-gun"></i></div>{{endif}}</div>
                <div class="gdlo-hub-card-body"><a href="{$loadout['view_url']}" class="gdlo-hub-card-name">{$loadout['name']}</a><div class="gdlo-hub-card-meta"><span class="gdlo-hub-card-author"><i class="fa-solid fa-user"></i> {$loadout['owner_name']}</span>{{if $loadout['mode_label']}}<span class="gdlo-hub-tag">{$loadout['mode_label']}</span>{{endif}}{{if $loadout['platform']}}<span class="gdlo-hub-tag">{$loadout['platform']}</span>{{endif}}</div><div class="gdlo-hub-price">{{if $loadout['total_min_price'] > 0}}<span class="gdlo-hub-price-val">{expression="'$' . number_format((float)$loadout['total_min_price'], 0)"}</span>{{else}}<span class="gdlo-hub-price-na">{lang="gdloadout_no_price_yet"}</span>{{endif}}<span class="gdlo-hub-price-parts">{$loadout['total_items']} {lang="gdloadout_parts"}</span></div><div class="gdlo-hub-card-stats"><span aria-label="{lang="gdloadout_upvote_loadout"}"><i class="fa-solid fa-heart" aria-hidden="true"></i> {$loadout['upvotes']}</span><span aria-label="{lang="gdloadout_follow_loadout"}"><i class="fa-solid fa-bell" aria-hidden="true"></i> {$loadout['follow_count']}</span></div></div>
                <div class="gdlo-hub-actions"><a href="{$loadout['view_url']}" class="gdlo-hub-btn gdlo-hub-btn--view"><i class="fa-solid fa-eye"></i> {lang="gdloadout_view_build"}</a><form method="post" action="{$copyUrl}" class="gdlo-hub-copy-form"><input type="hidden" name="csrfKey" value="{$csrfKey}" /><input type="hidden" name="loadout_id" value="{$loadout['id']}" /><button type="submit" class="gdlo-hub-btn gdlo-hub-btn--copy"><i class="fa-solid fa-copy"></i> {lang="gdloadout_copy_build"}</button></form></div>
            </div>
            {{endforeach}}
        </div>
    </div>
    {{endif}}
    {{if count($sections['recent']) > 0}}
    <div class="gdlo-hub-section">
        <h2 class="gdlo-hub-section-title"><i class="fa-solid fa-clock"></i> {lang="gdloadout_recent"}</h2>
        <div class="gdlo-hub-grid">
            {{foreach $sections['recent'] as $loadout}}
            <div class="gdlo-hub-card">
                <div class="gdlo-hub-card-img">{{if $loadout['base_image']}}<img src="{$loadout['base_image']}" alt="{$loadout['base_title']}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><div class="gdlo-hub-card-noimg" style="display:none"><i class="fa-solid fa-gun"></i></div>{{else}}<div class="gdlo-hub-card-noimg"><i class="fa-solid fa-gun"></i></div>{{endif}}</div>
                <div class="gdlo-hub-card-body"><a href="{$loadout['view_url']}" class="gdlo-hub-card-name">{$loadout['name']}</a><div class="gdlo-hub-card-meta"><span class="gdlo-hub-card-author"><i class="fa-solid fa-user"></i> {$loadout['owner_name']}</span>{{if $loadout['mode_label']}}<span class="gdlo-hub-tag">{$loadout['mode_label']}</span>{{endif}}{{if $loadout['platform']}}<span class="gdlo-hub-tag">{$loadout['platform']}</span>{{endif}}</div><div class="gdlo-hub-price">{{if $loadout['total_min_price'] > 0}}<span class="gdlo-hub-price-val">{expression="'$' . number_format((float)$loadout['total_min_price'], 0)"}</span>{{else}}<span class="gdlo-hub-price-na">{lang="gdloadout_no_price_yet"}</span>{{endif}}<span class="gdlo-hub-price-parts">{$loadout['total_items']} {lang="gdloadout_parts"}</span></div><div class="gdlo-hub-card-stats"><span aria-label="{lang="gdloadout_upvote_loadout"}"><i class="fa-solid fa-heart" aria-hidden="true"></i> {$loadout['upvotes']}</span><span aria-label="{lang="gdloadout_follow_loadout"}"><i class="fa-solid fa-bell" aria-hidden="true"></i> {$loadout['follow_count']}</span></div></div>
                <div class="gdlo-hub-actions"><a href="{$loadout['view_url']}" class="gdlo-hub-btn gdlo-hub-btn--view"><i class="fa-solid fa-eye"></i> {lang="gdloadout_view_build"}</a><form method="post" action="{$copyUrl}" class="gdlo-hub-copy-form"><input type="hidden" name="csrfKey" value="{$csrfKey}" /><input type="hidden" name="loadout_id" value="{$loadout['id']}" /><button type="submit" class="gdlo-hub-btn gdlo-hub-btn--copy"><i class="fa-solid fa-copy"></i> {lang="gdloadout_copy_build"}</button></form></div>
            </div>
            {{endforeach}}
        </div>
    </div>
    {{endif}}
    {{if count($sections['budget']) > 0}}
    <div class="gdlo-hub-section">
        <h2 class="gdlo-hub-section-title"><i class="fa-solid fa-piggy-bank"></i> {lang="gdloadout_budget"}</h2>
        <div class="gdlo-hub-grid">
            {{foreach $sections['budget'] as $loadout}}
            <div class="gdlo-hub-card">
                <div class="gdlo-hub-card-img">{{if $loadout['base_image']}}<img src="{$loadout['base_image']}" alt="{$loadout['base_title']}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='flex'" /><div class="gdlo-hub-card-noimg" style="display:none"><i class="fa-solid fa-gun"></i></div>{{else}}<div class="gdlo-hub-card-noimg"><i class="fa-solid fa-gun"></i></div>{{endif}}</div>
                <div class="gdlo-hub-card-body"><a href="{$loadout['view_url']}" class="gdlo-hub-card-name">{$loadout['name']}</a><div class="gdlo-hub-card-meta"><span class="gdlo-hub-card-author"><i class="fa-solid fa-user"></i> {$loadout['owner_name']}</span>{{if $loadout['mode_label']}}<span class="gdlo-hub-tag">{$loadout['mode_label']}</span>{{endif}}{{if $loadout['platform']}}<span class="gdlo-hub-tag">{$loadout['platform']}</span>{{endif}}</div><div class="gdlo-hub-price">{{if $loadout['total_min_price'] > 0}}<span class="gdlo-hub-price-val">{expression="'$' . number_format((float)$loadout['total_min_price'], 0)"}</span>{{else}}<span class="gdlo-hub-price-na">{lang="gdloadout_no_price_yet"}</span>{{endif}}<span class="gdlo-hub-price-parts">{$loadout['total_items']} {lang="gdloadout_parts"}</span></div><div class="gdlo-hub-card-stats"><span aria-label="{lang="gdloadout_upvote_loadout"}"><i class="fa-solid fa-heart" aria-hidden="true"></i> {$loadout['upvotes']}</span><span aria-label="{lang="gdloadout_follow_loadout"}"><i class="fa-solid fa-bell" aria-hidden="true"></i> {$loadout['follow_count']}</span></div></div>
                <div class="gdlo-hub-actions"><a href="{$loadout['view_url']}" class="gdlo-hub-btn gdlo-hub-btn--view"><i class="fa-solid fa-eye"></i> {lang="gdloadout_view_build"}</a><form method="post" action="{$copyUrl}" class="gdlo-hub-copy-form"><input type="hidden" name="csrfKey" value="{$csrfKey}" /><input type="hidden" name="loadout_id" value="{$loadout['id']}" /><button type="submit" class="gdlo-hub-btn gdlo-hub-btn--copy"><i class="fa-solid fa-copy"></i> {lang="gdloadout_copy_build"}</button></form></div>
            </div>
            {{endforeach}}
        </div>
    </div>
    {{endif}}
</div>
TEMPLATE_EOT;

		try
		{
			\IPS\Db::i()->replace( 'core_theme_templates', [
				'template_set_id'       => 1,
				'template_app'          => 'gdloadout',
				'template_location'     => 'front',
				'template_group'        => 'loadouts',
				'template_name'         => 'hub',
				'template_data'         => '$sections, $canCreate, $builderUrl, $activeUseCase, $useCases, $myLoadoutsUrl, $copyUrl, $csrfKey',
				'template_content'      => $hubContent,
				'template_updated'      => time(),
				'template_version'      => '1.0.30',
				'template_master_key'   => '',
				'template_has_hookpoints' => 0,
			] );
		}
		catch ( \Throwable ) {}

		$newStrings = [
			'gdloadout_copy_build'   => 'Copy Build',
			'gdloadout_view_build'   => 'View',
			'gdloadout_parts'        => 'parts',
			'gdloadout_no_price_yet' => 'No price yet',
			'gdloadout_copy_private' => 'Private loadouts cannot be copied',
		];

		try
		{
			foreach ( \IPS\Db::i()->select( 'lang_id', 'core_sys_lang' ) as $langId )
			{
				foreach ( $newStrings as $key => $val )
				{
					try
					{
						\IPS\Db::i()->replace( 'core_sys_lang_words', [
							'lang_id'      => (int) $langId,
							'word_app'     => 'gdloadout',
							'word_key'     => $key,
							'word_default' => $val,
							'word_js'      => 0,
							'word_export'  => 1,
						] );
					}
					catch ( \Throwable ) {}
				}
			}
		}
		catch ( \Throwable ) {}

		try { unset( \IPS\Data\Store::i()->extensions ); }   catch ( \Throwable ) {}
		try { unset( \IPS\Data\Store::i()->applications ); } catch ( \Throwable ) {}
		try { \IPS\Data\Cache::i()->clearAll(); }            catch ( \Throwable ) {}

		return TRUE;
	}
}

class upgrade extends _upgrade {}
