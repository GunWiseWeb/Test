<?php
/**
 * @brief       GD Master Catalog — ACP Products Controller
 * @package     IPS Community Suite
 * @subpackage  GD Master Catalog
 * @since       12 Apr 2026
 *
 * Product search/browse by UPC, title, brand, category.
 * Inline edit with field locking (Section 2.2.3).
 * Admin Review queue with one-click resolve.
 */

namespace IPS\gdcatalog\modules\admin\catalog;

/* To prevent PHP errors (extending class does not exist) revealing path */

use IPS\gdcatalog\Catalog\Product;
use IPS\gdcatalog\Catalog\Category;
use IPS\gdcatalog\Conflict\FieldLock;
use IPS\gdcatalog\Search\OpenSearchIndexer;
use function defined;

if ( !defined( '\IPS\SUITE_UNIQUE_KEY' ) )
{
	header( ( $_SERVER['SERVER_PROTOCOL'] ?? 'HTTP/1.0' ) . ' 403 Forbidden' );
	exit;
}

class _products extends \IPS\Dispatcher\Controller
{
	public static bool $csrfProtected = TRUE;

	public function execute(): void
	{
		\IPS\Dispatcher::i()->checkAcpPermission( 'catalog_manage' );
		parent::execute();
	}

	/**
	 * v1.0.23: Recursively collect all descendant category IDs for a given
	 * parent. Walks the gd_categories tree, returning a flat array of IDs.
	 *
	 * Self-protected against infinite recursion via $visited tracking.
	 * Returns empty array if $parentId has no children (leaf node).
	 *
	 * @param  int    $parentId   The category ID to find descendants of.
	 * @param  array  $visited    Internal recursion guard.
	 * @return int[]
	 */
	protected static function collectCategoryDescendants( int $parentId, array $visited = [] ): array
	{
		if ( in_array( $parentId, $visited, true ) )
		{
			return [];
		}
		$visited[] = $parentId;

		$descendants = [];
		try
		{
			foreach ( \IPS\Db::i()->select( 'id', 'gd_categories', [ 'parent_id=?', $parentId ] ) as $childId )
			{
				$childId = (int) $childId;
				if ( $childId <= 0 || in_array( $childId, $visited, true ) )
				{
					continue;
				}
				$descendants[] = $childId;

				/* Recurse to capture grandchildren */
				$grandchildren = self::collectCategoryDescendants( $childId, $visited );
				foreach ( $grandchildren as $gc )
				{
					$descendants[] = $gc;
				}
			}
		}
		catch ( \Throwable )
		{
			/* If query fails, return what we have so far - the calling code
			 * will fall back to exact-match behavior for the parent. */
		}

		return $descendants;
	}

	/**
	 * Product list with search/filter.
	 *
	 * Products and categories are flattened into scalar arrays and
	 * all dynamic URLs (edit, approve, form action) are pre-built in
	 * the controller. The template then only uses plain `{$row['key']}`
	 * access per Rule #12 — no nested `{url="...{$x->upc}"}` tokens.
	 */
	protected function manage()
	{
		$where   = [];
		$search  = \IPS\Request::i()->q ?? '';
		$status  = \IPS\Request::i()->status ?? '';
		$catId   = (int) ( \IPS\Request::i()->category ?? 0 );

		if ( $search !== '' )
		{
			$where[] = [
				'(upc LIKE ? OR title LIKE ? OR brand LIKE ?)',
				'%' . $search . '%', '%' . $search . '%', '%' . $search . '%'
			];
		}

		if ( $status !== '' )
		{
			$where[] = [ 'record_status=?', $status ];
		}

		/* v1.0.28: Image status filter - expanded for HEAD-validation states.
		 *
		 * Values:
		 *   missing   - image_url is NULL or empty string
		 *   present   - image_url has a value (regardless of validation)
		 *   unchecked - has URL but never validated yet (image_validated IS NULL)
		 *   ok        - validated and status 200-399
		 *   broken    - validated and status >= 400 or = 0 (network errors)
		 */
		$imageStatus = (string) ( \IPS\Request::i()->image_status ?? '' );
		$validImageStatuses = [ 'missing', 'present', 'unchecked', 'ok', 'broken' ];
		if ( !in_array( $imageStatus, $validImageStatuses, true ) )
		{
			$imageStatus = '';
		}

		if ( $imageStatus === 'missing' )
		{
			$where[] = [ 'image_url IS NULL OR image_url = ?', '' ];
		}
		elseif ( $imageStatus === 'present' )
		{
			$where[] = [ 'image_url IS NOT NULL AND image_url != ?', '' ];
		}
		elseif ( $imageStatus === 'unchecked' )
		{
			$where[] = [ 'image_url IS NOT NULL AND image_url != ? AND image_validated IS NULL', '' ];
		}
		elseif ( $imageStatus === 'ok' )
		{
			$where[] = [ 'image_validated = 1 AND image_http_status >= 200 AND image_http_status < 400' ];
		}
		elseif ( $imageStatus === 'broken' )
		{
			$where[] = [ 'image_validated = 1 AND (image_http_status >= 400 OR image_http_status = 0)' ];
		}

		/* v1.0.23: Parent-aware category filter.
		 *
		 * gd_categories is hierarchical (Ammunition parent has children
		 * Handgun Ammo, Rifle Ammo, Shotgun Ammo, etc). When admin selects
		 * a parent category in the filter dropdown, they expect to see ALL
		 * products in that parent OR any of its descendants.
		 *
		 * For example: selecting "Ammunition" (id=17) should match
		 * category_id IN (17, 18, 19, 20, 21, 22) since those subcategories
		 * have parent_id=17.
		 *
		 * Strategy: collect the selected category's ID plus all its
		 * descendant IDs (recursively, in case of multi-level hierarchy),
		 * then filter with IN clause. */
		if ( $catId > 0 )
		{
			$descendantIds = self::collectCategoryDescendants( $catId );
			$descendantIds[] = $catId;
			$descendantIds = array_unique( $descendantIds );

			if ( count( $descendantIds ) === 1 )
			{
				/* Leaf category - exact match */
				$where[] = [ 'category_id=?', $catId ];
			}
			else
			{
				/* Parent with children - IN clause.
				 * Build placeholders dynamically since IPS\Db needs them. */
				$placeholders = implode( ',', array_fill( 0, count( $descendantIds ), '?' ) );
				$where[] = array_merge(
					[ 'category_id IN (' . $placeholders . ')' ],
					$descendantIds
				);
			}
		}

		$page    = max( 1, (int) ( \IPS\Request::i()->page ?? 1 ) );
		$perPage = 50;

		$total = (int) \IPS\Db::i()->select( 'COUNT(*)', 'gd_catalog', $where )->first();

		$products = [];
		foreach (
			\IPS\Db::i()->select( '*', 'gd_catalog', $where, 'last_updated DESC', [ ( $page - 1 ) * $perPage, $perPage ] ) as $row
		)
		{
			$product = Product::constructFromData( $row );

			$editUrl = (string) \IPS\Http\Url::internal(
				'app=gdcatalog&module=catalog&controller=products&do=edit&upc=' . urlencode( (string) $product->upc )
			);
			$approveUrl = (string) \IPS\Http\Url::internal(
				'app=gdcatalog&module=catalog&controller=products&do=resolveReview&upc=' . urlencode( (string) $product->upc )
			)->csrf();

			$products[] = [
				'upc'                => (string) $product->upc,
				'title'              => (string) ( $product->title ?? '' ),
				'brand'              => (string) ( $product->brand ?? '' ),
				'caliber'            => (string) ( $product->caliber ?? '' ),
				'msrp'               => $product->msrp !== null ? '$' . number_format( (float) $product->msrp, 2 ) : '—',
				'record_status'      => (string) ( $product->record_status ?? '' ),
				'primary_source'     => (string) ( $product->primary_source ?? '' ),
				'edit_url'           => $editUrl,
				'approve_url'        => $approveUrl,

				/* v1.0.28: Image validation state for the image badge column */
				'image_url'          => (string) ( $product->image_url ?? '' ),
				'image_validated'    => $product->image_validated !== null ? (int) $product->image_validated : null,
				'image_http_status'  => $product->image_http_status !== null ? (int) $product->image_http_status : null,
			];
		}

		$categories = [];
		foreach ( Category::roots() as $cat )
		{
			$categories[] = [
				'id'   => (int) $cat->id,
				'name' => (string) $cat->name,
			];
		}

		$formActionUrl = (string) \IPS\Http\Url::internal(
			'app=gdcatalog&module=catalog&controller=products'
		);

		$pagination = \IPS\Theme::i()->getTemplate( 'global', 'core', 'global' )->pagination(
			\IPS\Http\Url::internal( 'app=gdcatalog&module=catalog&controller=products' ),
			(int) ceil( $total / $perPage ),
			$page,
			$perPage
		);

		$productCount  = \count( $products );
		$categoryCount = \count( $categories );

		\IPS\Output::i()->title  = \IPS\Member::loggedIn()->language()->addToStack( 'gdcatalog_products_title' );
		\IPS\Output::i()->output = \IPS\Theme::i()->getTemplate( 'catalog', 'gdcatalog', 'admin' )->productList(
			$products, $categories, $search, $status, $catId, $imageStatus,
			$total, $pagination, $formActionUrl, $productCount, $categoryCount
		);
	}

	/**
	 * Edit a single product.
	 */
	protected function edit()
	{
		$upc = \IPS\Request::i()->upc;

		try
		{
			$product = Product::load( $upc );
		}
		catch ( \OutOfRangeException )
		{
			\IPS\Output::i()->error( 'node_error', '2GDC102/1', 404 );
			return;
		}

		$locks = FieldLock::loadForProduct( $upc );

		$form = new \IPS\Helpers\Form;

		/* Editable fields - v1.0.27 expanded with master record fields. */
		$editableFields = [
			/* Identity */
			'title'          => [ 'Text', 255 ],
			'mpn'            => [ 'Text', 50 ],
			'brand'          => [ 'Text', 100 ],
			'manufacturer'   => [ 'Text', 100 ],
			'importer'       => [ 'Text', 100 ],
			'model'          => [ 'Text', 100 ],

			/* Classification */
			'gun_type'       => [ 'Text', 50 ],

			/* Core specs */
			'caliber'        => [ 'Text', 50 ],
			'action_type'    => [ 'Text', 50 ],
			'capacity'       => [ 'Number', null ],
			'barrel_length'  => [ 'Number', null ],
			'overall_length' => [ 'Number', null ],
			'weight_oz'      => [ 'Number', null ],

			/* Configuration / appearance */
			'finish'         => [ 'Text', 100 ],
			'safety_type'    => [ 'Text', 100 ],
			'stock_type'     => [ 'Text', 100 ],
			'sight_type'     => [ 'Text', 100 ],
			'receiver_type'  => [ 'Text', 255 ],
			'frame_material' => [ 'Text', 100 ],

			/* Pricing + content */
			'msrp'           => [ 'Number', null ],
			'description'    => [ 'TextArea', null ],
		];

		foreach ( $editableFields as $field => $config )
		{
			$isLocked = $product->isFieldLocked( $field );
			$formClass = $config[0] === 'TextArea'
				? \IPS\Helpers\Form\TextArea::class
				: ( $config[0] === 'Number' ? \IPS\Helpers\Form\Number::class : \IPS\Helpers\Form\Text::class );

			$form->add( new $formClass(
				'gdcatalog_product_' . $field,
				$product->$field ?? '',
				FALSE,
				$config[0] === 'Number' ? [ 'decimals' => 2 ] : []
			));
		}

		/* Boolean flags */
		$form->add( new \IPS\Helpers\Form\YesNo( 'gdcatalog_product_nfa_item', $product->nfa_item ) );
		$form->add( new \IPS\Helpers\Form\YesNo( 'gdcatalog_product_requires_ffl', $product->requires_ffl ) );
		$form->add( new \IPS\Helpers\Form\YesNo( 'gdcatalog_product_is_ammo', $product->is_ammo ) );

		/* Status */
		$form->add( new \IPS\Helpers\Form\Select(
			'gdcatalog_product_status', $product->record_status, TRUE,
			[ 'options' => [
				'active'       => 'Active',
				'discontinued' => 'Discontinued',
				'admin_review' => 'Admin Review',
				'pending'      => 'Pending',
			]]
		));

		if ( $values = $form->values() )
		{
			\IPS\Session::i()->csrfCheck();

			foreach ( $editableFields as $field => $config )
			{
				$product->$field = $values[ 'gdcatalog_product_' . $field ];
			}

			$product->nfa_item      = (int) $values['gdcatalog_product_nfa_item'];
			$product->requires_ffl  = (int) $values['gdcatalog_product_requires_ffl'];
			$product->is_ammo       = (int) $values['gdcatalog_product_is_ammo'];
			$product->record_status = $values['gdcatalog_product_status'];
			$product->last_updated  = date( 'Y-m-d H:i:s' );
			$product->save();

			/* Reindex */
			OpenSearchIndexer::i()->indexProduct( $product );

			\IPS\Output::i()->redirect(
				\IPS\Http\Url::internal( 'app=gdcatalog&module=catalog&controller=products' ),
				'saved'
			);
		}

		\IPS\Output::i()->title = $product->title . ' (' . $product->upc . ')';

		/* Render a small "Locked Fields" notice above the Form output, if any.
		 * Rule #8: admin form page uses \IPS\Helpers\Form — the form itself is
		 * unchanged; only an informational banner is prepended. No raw-HTML
		 * form markup. */
		$lockNotice = '';
		if ( \count( $locks ) )
		{
			$lockNotice = '<div class="ipsBox ipsPull"><div class="ipsBox_body ipsPad"><h2 class="ipsType_sectionHead" style="margin:0 0 12px">'
				. \IPS\Member::loggedIn()->language()->addToStack( 'gdcatalog_product_locked_fields' )
				. '</h2><ul class="ipsList_reset">';
			foreach ( $locks as $lock )
			{
				$unlockUrl = (string) \IPS\Http\Url::internal(
					'app=gdcatalog&module=catalog&controller=compliance&do=unlock&id=' . (int) $lock->id
				)->csrf();
				$lockNotice .= '<li style="margin-bottom:6px"><code>' . htmlspecialchars( $lock->field_name ?? '' ) . '</code>'
					. ' <span class="ipsBadge ipsBadge--neutral">' . htmlspecialchars( $lock->lock_type ?? '' ) . '</span> '
					. '<a href="' . htmlspecialchars( $unlockUrl ) . '" class="ipsButton ipsButton--negative ipsButton--small">Unlock</a></li>';
			}
			$lockNotice .= '</ul></div></div>';
		}

		/* v1.0.19: Image preview block.
		 *
		 * Show the product image at the top of the edit page if image_url
		 * is populated. Helps admins visually identify products when editing,
		 * especially for Sports South imports where the title alone can be
		 * ambiguous.
		 *
		 * Wrapped in try/catch + URL validation so a malformed image_url
		 * doesn't break the entire edit page. Falls back to no preview if
		 * the URL doesn't look valid. */
		$imagePreview = '';
		$imageUrl = trim( (string) ( $product->image_url ?? '' ) );

		if ( $imageUrl !== '' && ( str_starts_with( $imageUrl, 'http://' ) || str_starts_with( $imageUrl, 'https://' ) ) )
		{
			$safeUrl = htmlspecialchars( $imageUrl, ENT_QUOTES, 'UTF-8' );
			$imagePreview = '<div class="ipsBox ipsPull" style="margin-bottom:16px">'
				. '<div class="ipsBox_body ipsPad" style="text-align:center">'
				. '<img src="' . $safeUrl . '" alt="Product image" '
				. 'style="max-width:300px;max-height:300px;border:1px solid var(--i-border-color, #e0e0e0);border-radius:4px;background:#fff;padding:8px" '
				. 'onerror="this.style.display=\'none\';this.nextElementSibling.style.display=\'block\'">'
				. '<div style="display:none;color:var(--i-color-text-muted, #888);padding:24px">Image could not be loaded</div>'
				. '<div style="margin-top:8px;font-size:0.85em;color:var(--i-color-text-muted, #888)">'
				. '<a href="' . $safeUrl . '" target="_blank" rel="noopener">View full size</a>'
				. '</div>'
				. '</div></div>';
		}

		\IPS\Output::i()->output = $imagePreview . $lockNotice . (string) $form;
	}

	/**
	 * Lock a field on a product.
	 */
	protected function lockField()
	{
		\IPS\Session::i()->csrfCheck();

		$upc   = \IPS\Request::i()->upc;
		$field = \IPS\Request::i()->field;

		$product = Product::load( $upc );
		$product->lockField( $field );
		$product->save();

		\IPS\Output::i()->redirect(
			\IPS\Http\Url::internal( 'app=gdcatalog&module=catalog&controller=products&do=edit&upc=' . urlencode( $upc ) ),
			'Field locked'
		);
	}

	/**
	 * Unlock a field on a product.
	 */
	protected function unlockField()
	{
		\IPS\Session::i()->csrfCheck();

		$upc   = \IPS\Request::i()->upc;
		$field = \IPS\Request::i()->field;

		$product = Product::load( $upc );
		$product->unlockField( $field );
		$product->save();

		\IPS\Output::i()->redirect(
			\IPS\Http\Url::internal( 'app=gdcatalog&module=catalog&controller=products&do=edit&upc=' . urlencode( $upc ) ),
			'Field unlocked'
		);
	}

	/**
	 * Admin review queue — resolve a product out of admin_review status.
	 */
	protected function resolveReview()
	{
		\IPS\Session::i()->csrfCheck();

		$upc = \IPS\Request::i()->upc;
		$product = Product::load( $upc );

		$product->record_status = Product::STATUS_ACTIVE;
		$product->last_updated  = date( 'Y-m-d H:i:s' );
		$product->save();

		OpenSearchIndexer::i()->indexProduct( $product );

		\IPS\Output::i()->redirect(
			\IPS\Http\Url::internal( 'app=gdcatalog&module=catalog&controller=products&status=admin_review' ),
			'Product approved'
		);
	}
}

class products extends _products {}
