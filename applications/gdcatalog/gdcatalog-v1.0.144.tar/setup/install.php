<?php
/**
 * @brief       GD Master Catalog — Install routine
 * @package     IPS Community Suite
 * @subpackage  GD Master Catalog
 * @since       12 Apr 2026
 *
 * Runs after schema.json tables are created.
 * Seeds the six distributor feed records and the category taxonomy.
 */

/* Seed the six distributor feed records with priority hierarchy (Section 2.2.1) */

$sportsSouthFieldMapping = json_encode([
    'ITUPC'   => 'upc',
    'SHDESC'  => 'title',
    'IDESC'   => 'description',
    'CATID'   => 'category_id',
    'CPRC'    => 'msrp',
    'PICREF'  => 'image_url',
    'IMODEL'  => 'model',
    'MFGINO'  => 'mpn',
    'WTPBX'   => 'weight_lbs',
    'LENGTH'  => 'overall_length',
]);

$sportsSouthCategoryMapping = json_encode( [
    '5'  => 23,  '6'  => 23,  '26' => 2,   '64' => 3,   '96' => 4,
    '40' => 8,   '58' => 8,   '94' => 15,
    '48' => 16,  '59' => 16,
    '49' => 23,  '70' => 23,  '71' => 23,  '72' => 23,  '86' => 23,
    '90' => 23,  '91' => 23,  '36' => 23,  '12' => 23,  '4'  => 23,
    '18' => 38,
    '9'  => 44,  '10' => 44,  '32' => 44,  '39' => 44,  '41' => 44,
    '46' => 44,  '50' => 44,  '52' => 44,  '55' => 44,  '78' => 44,
    '79' => 44,  '80' => 44,
    '8'  => 58,  '23' => 58,  '37' => 58,  '63' => 58,  '66' => 58,
    '67' => 58,  '74' => 58,  '77' => 58,  '81' => 58,
    '1'  => 58,  '2'  => 58,  '13' => 58,  '14' => 58,
    '30' => 58,  '82' => 58,  '65' => 58,
    '28' => 72,  '84' => 72,
    '15' => 83,  '44' => 83,
    '17' => 94,  '87' => 94,
    '31' => 103, '51' => 103, '53' => 103, '75' => 103,
    '83' => 103, '25' => 103,
    '7'  => 114, '19' => 114, '21' => 114, '22' => 114,
    '27' => 114, '45' => 114,
    '93' => 31,
    '20' => 130, '62' => 130,
] );

$distributors = [
    ['feed_name' => 'RSR Group Primary',        'distributor' => 'rsr_group',     'priority' => 1, 'field_mapping' => null,                    'category_mapping' => null],
    ['feed_name' => 'Sports South Primary',      'distributor' => 'sports_south',  'priority' => 2, 'field_mapping' => $sportsSouthFieldMapping, 'category_mapping' => $sportsSouthCategoryMapping],
    ['feed_name' => "Davidson's Primary",        'distributor' => 'davidsons',     'priority' => 3, 'field_mapping' => null,                    'category_mapping' => null],
    ['feed_name' => "Lipsey's Primary",          'distributor' => 'lipseys',       'priority' => 4, 'field_mapping' => null,                    'category_mapping' => null],
    ['feed_name' => 'Zanders Sporting Goods',    'distributor' => 'zanders',       'priority' => 5, 'field_mapping' => null,                    'category_mapping' => null],
    ['feed_name' => 'Bill Hicks Primary',        'distributor' => 'bill_hicks',    'priority' => 6, 'field_mapping' => null,                    'category_mapping' => null],
];

/* Default conflict detection fields per Section 2.11.2 */
$defaultConflictFields = json_encode([
	'restricted_states' => true,
	'nfa_item'          => true,
	'requires_ffl'      => true,
	'caliber'           => true,
	'rounds_per_box'    => true,
	'category'          => false,
	'manufacturer'      => false,
	'description'       => false,
]);

/* Only seed default feeds on a fresh install — never wipe existing feed config */
$existingFeedCount = (int) \IPS\Db::i()->select( 'COUNT(*)', 'gd_distributor_feeds' )->first();
if ( $existingFeedCount === 0 )
{
    foreach ( $distributors as $dist )
    {
        try {
            \IPS\Db::i()->insert( 'gd_distributor_feeds', [
                'feed_name'                => $dist['feed_name'],
                'distributor'              => $dist['distributor'],
                'priority'                 => $dist['priority'],
                'feed_url'                 => '',
                'feed_format'              => 'xml',
                'auth_type'                => 'none',
                'auth_credentials'         => NULL,
                'field_mapping'            => $dist['field_mapping'] ?? null,
                'category_mapping'         => $dist['category_mapping'] ?? null,
                'import_schedule'          => '6hr',
                'conflict_detection_fields'=> $defaultConflictFields,
                'active'                   => 0,
                'last_run'                 => NULL,
                'last_record_count'        => 0,
                'last_run_status'          => NULL,
            ]);
        } catch ( \Throwable ) {}
    }
}

/* Seed category taxonomy (Section 2.4) — expanded v1.0.49 */
$categories = [
	'Handguns' => [
		'Pistols', 'Revolvers', 'Derringers', 'Single-Shot Pistols', 'Flare Pistols',
	],
	'Rifles' => [
		'Semi-Automatic Rifles', 'Bolt-Action Rifles', 'Lever-Action Rifles',
		'Pump-Action Rifles', 'Single-Shot Rifles', 'Break-Action Rifles',
		'Muzzleloaders', 'Rimfire Rifles',
	],
	'Shotguns' => [
		'Semi-Automatic Shotguns', 'Pump-Action Shotguns', 'Break-Action Shotguns',
		'Over/Under Shotguns', 'Side-by-Side Shotguns', 'Single-Shot Shotguns',
	],
	'Ammunition' => [
		'Handgun Ammunition', 'Rifle Ammunition', 'Shotgun Ammunition',
		'Rimfire Ammunition', 'Centerfire Ammunition', 'Specialty & Exotic',
		'Blanks & Less-Lethal',
	],
	'NFA Items' => [
		'Suppressors', 'Short-Barreled Rifles (SBR)', 'Short-Barreled Shotguns (SBS)',
		'Machine Guns', 'Any Other Weapons (AOW)', 'Destructive Devices',
	],
	'Magazines' => [
		'Handgun Magazines', 'Rifle Magazines', 'Shotgun Magazines',
		'Drum Magazines', 'Extended Magazines',
	],
	'Optics' => [
		'Red Dot Sights', 'Holographic Sights', 'Rifle Scopes',
		'LPVOs (1-6x and similar)', 'Prism Scopes', 'Night Vision Optics',
		'Thermal Optics', 'Magnifiers', 'Laser Sights', 'Iron Sights',
		'Rangefinders', 'Spotting Scopes', 'Binoculars',
	],
	'Parts & Accessories' => [
		'Barrels', 'Triggers & Trigger Groups', 'Stocks & Chassis',
		'Grips & Grip Panels', 'Rails & Mounts', 'Handguards & Forends',
		'Muzzle Devices', 'Bolts & Bolt Carriers', 'Buffers & Springs',
		'Slides', 'Frames & Receivers', 'Sight Mounts', 'Magazine Wells',
		'Scope Rings', 'Upper Receivers', 'Lower Receivers',
	],
	'Holsters & Carry' => [
		'IWB Holsters', 'OWB Holsters', 'Shoulder Holsters', 'Ankle Holsters',
		'Appendix Carry (AIWB)', 'Duty Holsters', 'Vehicle Holsters',
		'Pocket Holsters', 'Chest Rigs & Plate Carriers', 'Magazine Pouches',
	],
	'Storage & Safety' => [
		'Gun Safes', 'Handgun Safes', 'Long Gun Cases (Hard)',
		'Long Gun Cases (Soft)', 'Handgun Cases', 'Lock Boxes',
		'Trigger Locks', 'Cable Locks', 'Vault Doors', 'Safe Accessories',
	],
	'Cleaning & Maintenance' => [
		'Cleaning Kits', 'Lubricants & CLP', 'Solvents & Degreasers',
		'Bore Snakes & Brushes', 'Patches & Jags', 'Ultrasonic Cleaners',
		'Cleaning Rods', 'Gun Vises & Cradles',
	],
	'Tactical Gear' => [
		'Weapon Lights', 'Bipods & Monopods', 'Slings & Swivels',
		'Foregrips & Vertical Grips', 'Suppressors & Solvent Traps',
		'Cheek Rests & Risers', 'Shell Holders & Carriers',
		'Shooting Bags & Rests', 'Ear & Eye Protection', 'Gloves & Apparel',
		'Flashlights & Headlamps',
	],
	'Hunting Gear' => [
		'Game Calls', 'Scent Control', 'Hunting Blinds', 'Feeders & Attractants',
		'Trail Cameras', 'Tree Stands', 'Field Dressing Tools', 'Decoys', 'Archery',
	],
	'Training & Safety' => [
		'Firearm Training Tools', 'Dry-Fire Systems', 'Safety Flags',
		'Snap Caps & Dummy Rounds', 'Books & DVDs',
	],
	'Electronics & Comms' => [
		'Radio & Communication', 'GPS Devices', 'Rangefinder Apps',
	],
	'Gunsmithing Tools' => [],
];

/* Only seed categories on a fresh install — never wipe existing category config */
$existingCategoryCount = (int) \IPS\Db::i()->select( 'COUNT(*)', 'gd_categories' )->first();
if ( $existingCategoryCount === 0 )
{
    $position = 0;
    foreach ( $categories as $parentName => $children )
    {
        $slug = mb_strtolower( preg_replace( '/[^a-z0-9]+/i', '-', $parentName ) );
        $slug = trim( $slug, '-' );

        try {
            $parentId = \IPS\Db::i()->insert( 'gd_categories', [
                'parent_id'     => 0,
                'name'          => $parentName,
                'slug'          => $slug,
                'position'      => $position++,
                'product_count' => 0,
            ]);
        } catch ( \Throwable ) {
            try { $parentId = (int) \IPS\Db::i()->select( 'id', 'gd_categories', [ 'slug=?', $slug ] )->first(); } catch ( \Throwable ) { continue; }
        }

        $childPos = 0;
        foreach ( $children as $childName )
        {
            $childSlug = $slug . '-' . mb_strtolower( preg_replace( '/[^a-z0-9]+/i', '-', $childName ) );
            $childSlug = trim( $childSlug, '-' );

            try {
                \IPS\Db::i()->insert( 'gd_categories', [
                    'parent_id'     => $parentId,
                    'name'          => $childName,
                    'slug'          => $childSlug,
                    'position'      => $childPos++,
                    'product_count' => 0,
                ]);
            } catch ( \Throwable ) {}
        }
    }
}

/* Re-point Sports South CATID 30 to Knives on fresh install */
try {
	$kId = (int) \IPS\Db::i()->select( 'id', 'gd_categories', [ 'slug=?', 'knives' ] )->first();
	if ( $kId ) {
		$row = \IPS\Db::i()->select( 'id, category_mapping', 'gd_distributor_feeds', [ 'distributor=?', 'sports_south' ] )->first();
		$map = json_decode( (string) ( $row['category_mapping'] ?? '{}' ), true );
		if ( !is_array( $map ) ) { $map = []; }
		$map['30'] = $kId;
		\IPS\Db::i()->update( 'gd_distributor_feeds', [ 'category_mapping' => json_encode( $map ) ], [ 'id=?', (int) $row['id'] ] );
	}
} catch ( \Throwable ) {}

/* Seed templates directly into core_theme_templates to bypass IPS XML import
 * bug that corrupts template comments during theme.xml installation. */
$gdcatalogTemplates = [
	[
		'template_name' => 'feedList',
		'template_data' => '$feeds, $feedCounts, $addUrl, $reorderUrl, $csrfKey, $reExtractUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">

		<div style="display:flex;gap:16px;margin-bottom:24px">
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$feedCounts['total']}</div>
				<div>Configured Feeds</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$feedCounts['active']}</div>
				<div>Active Feeds</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$feedCounts['urls']}</div>
				<div>URLs Configured</div>
			</div>
		</div>

		<p class="ipsType_light" style="margin-bottom:16px">{lang="gdcatalog_feeds_help"}</p>

		{{if count($feeds) === 0}}
			<div class="ipsEmptyMessage"><p>{lang="gdcatalog_feeds_empty"}</p></div>
		{{else}}
		<table class="ipsTable ipsTable_zebra" style="width:100%">
			<thead>
				<tr>
					<th style="width:5%">#</th>
					<th>{lang="gdcatalog_feed_name"}</th>
					<th>{lang="gdcatalog_feed_distributor"}</th>
					<th>{lang="gdcatalog_feed_format"}</th>
					<th>{lang="gdcatalog_feed_schedule"}</th>
					<th>{lang="gdcatalog_feed_active"}</th>
					<th>{lang="gdcatalog_feed_last_run"}</th>
					<th>{lang="gdcatalog_feed_last_count"}</th>
					<th>{lang="gdcatalog_feed_last_status"}</th>
					<th style="width:100px">Actions</th>
				</tr>
			</thead>
			<tbody>
				{{foreach $feeds as $feed}}
				<tr>
					<td>{$feed['priority']}</td>
					<td><strong>{$feed['feed_name']}</strong></td>
					<td>{$feed['distributor_label']}</td>
					<td>{$feed['feed_format']}</td>
					<td>{$feed['import_schedule']}</td>
					<td>
						{{if $feed['active']}}
							<span class="ipsBadge ipsBadge--positive">{lang="gdcatalog_feed_active"}</span>
						{{else}}
							<span class="ipsBadge ipsBadge--neutral">Inactive</span>
						{{endif}}
					</td>
					<td>
						{{if $feed['last_run']}}
							{$feed['last_run']}
						{{else}}
							&mdash;
						{{endif}}
					</td>
					<td>{expression="number_format( $feed['last_record_count'] )"}</td>
					<td>
						{{if $feed['last_run_status'] === 'completed'}}
							<span class="ipsBadge ipsBadge--positive">OK</span>
						{{elseif $feed['last_run_status'] === 'failed'}}
							<span class="ipsBadge ipsBadge--negative">Failed</span>
						{{elseif $feed['last_run_status'] === 'running'}}
							<span class="ipsBadge ipsBadge--warning">Running</span>
						{{else}}
							&mdash;
						{{endif}}
					</td>
					<td><a href="{$feed['edit_url']}" class="ipsButton ipsButton--primary ipsButton--small">Edit</a></td>
				</tr>
				{{endforeach}}
			</tbody>
		</table>
		{{endif}}

	</div>
</div>
TEMPLATE_EOT,
	],
	[
		'template_name' => 'conflictLog',
		'template_data' => '$entries, $filterField, $filterSource, $filterRule, $filterUpc, $total, $pagination, $entryCount, $formActionUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">

		<div style="display:flex;gap:16px;margin-bottom:24px">
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{expression="number_format( $total )"}</div>
				<div>Total Conflict Entries</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$entryCount}</div>
				<div>Showing On This Page</div>
			</div>
		</div>

		<form method="get" action="{$formActionUrl}" style="display:flex;gap:8px;padding:12px 16px;border-bottom:1px solid var(--i-border-color, #e0e0e0);align-items:center;flex-wrap:wrap">
			<input type="text" name="upc" value="{$filterUpc}" placeholder="UPC" class="ipsInput ipsInput--text" style="flex:1;min-width:140px">
			<input type="text" name="field" value="{$filterField}" placeholder="Field name" class="ipsInput ipsInput--text" style="flex:1;min-width:140px">
			<input type="text" name="source" value="{$filterSource}" placeholder="Distributor" class="ipsInput ipsInput--text" style="flex:1;min-width:140px">
			<select name="rule" class="ipsInput ipsInput--select" style="min-width:160px">
				<option value="">All rules</option>
				<option value="priority" {{if $filterRule === 'priority'}}selected{{endif}}>Priority</option>
				<option value="longest" {{if $filterRule === 'longest'}}selected{{endif}}>Longest</option>
				<option value="highest_res" {{if $filterRule === 'highest_res'}}selected{{endif}}>Highest Res</option>
				<option value="highest_val" {{if $filterRule === 'highest_val'}}selected{{endif}}>Highest Val</option>
				<option value="flagged_for_review" {{if $filterRule === 'flagged_for_review'}}selected{{endif}}>Flagged</option>
				<option value="any_true" {{if $filterRule === 'any_true'}}selected{{endif}}>Any True</option>
				<option value="admin_override" {{if $filterRule === 'admin_override'}}selected{{endif}}>Admin Override</option>
			</select>
			<button type="submit" class="ipsButton ipsButton--primary ipsButton--small">Filter</button>
		</form>

		{{if $entryCount === 0}}
			<div class="ipsEmptyMessage"><p>{lang="gdcatalog_conflicts_empty"}</p></div>
		{{else}}
		<table class="ipsTable ipsTable_zebra" style="width:100%">
			<thead>
				<tr>
					<th>{lang="gdcatalog_conflict_upc"}</th>
					<th>{lang="gdcatalog_conflict_field"}</th>
					<th>{lang="gdcatalog_conflict_winner"}</th>
					<th>{lang="gdcatalog_conflict_winner_val"}</th>
					<th>{lang="gdcatalog_conflict_loser"}</th>
					<th>{lang="gdcatalog_conflict_loser_val"}</th>
					<th>{lang="gdcatalog_conflict_rule"}</th>
					<th>{lang="gdcatalog_conflict_date"}</th>
				</tr>
			</thead>
			<tbody>
				{{foreach $entries as $entry}}
				<tr>
					<td><code>{$entry['upc']}</code></td>
					<td>{$entry['field_name']}</td>
					<td>{$entry['winning_source']}</td>
					<td>{$entry['winning_value']}</td>
					<td>{$entry['losing_source']}</td>
					<td>{$entry['losing_value']}</td>
					<td><span class="ipsBadge ipsBadge--neutral">{$entry['rule_applied']}</span></td>
					<td>{$entry['resolved_at']}</td>
				</tr>
				{{endforeach}}
			</tbody>
		</table>
		{{endif}}

		<div style="margin-top:16px">{$pagination}</div>

	</div>
</div>
TEMPLATE_EOT,
	],
	[
		'template_name' => 'compliancePanel',
		'template_data' => '$tab, $counts, $tabUrls, $pendingFlags, $pendingConflicts, $allLocks, $adminFlags, $addRestrictionUrl',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div style="display:flex;justify-content:flex-end;padding:10px 16px;border-bottom:1px solid var(--i-border-color, #e0e0e0)">
		<a href="{$addRestrictionUrl}" class="ipsButton ipsButton--primary ipsButton--small">Add State Restriction</a>
	</div>
	<div class="ipsBox_body ipsPad">

		<div style="display:flex;gap:16px;margin-bottom:24px">
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$counts['new']}</div>
				<div>{lang="gdcatalog_compliance_tab_new"}</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$counts['conflicts']}</div>
				<div>{lang="gdcatalog_compliance_tab_conflicts"}</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$counts['locks']}</div>
				<div>{lang="gdcatalog_compliance_tab_locks"}</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$counts['admin']}</div>
				<div>{lang="gdcatalog_compliance_tab_admin"}</div>
			</div>
		</div>

		<div style="display:flex;gap:8px;padding:12px 16px;border-bottom:1px solid var(--i-border-color, #e0e0e0);justify-content:center">
			<a href="{$tabUrls['new']}" class="ipsButton {{if $tab === 'new'}}ipsButton--primary{{else}}ipsButton--soft{{endif}} ipsButton--small">{lang="gdcatalog_compliance_tab_new"} <span class="ipsBadge ipsBadge--neutral" style="margin-left:6px">{$counts['new']}</span></a>
			<a href="{$tabUrls['conflicts']}" class="ipsButton {{if $tab === 'conflicts'}}ipsButton--primary{{else}}ipsButton--soft{{endif}} ipsButton--small">{lang="gdcatalog_compliance_tab_conflicts"} <span class="ipsBadge ipsBadge--neutral" style="margin-left:6px">{$counts['conflicts']}</span></a>
			<a href="{$tabUrls['locks']}" class="ipsButton {{if $tab === 'locks'}}ipsButton--primary{{else}}ipsButton--soft{{endif}} ipsButton--small">{lang="gdcatalog_compliance_tab_locks"} <span class="ipsBadge ipsBadge--neutral" style="margin-left:6px">{$counts['locks']}</span></a>
			<a href="{$tabUrls['admin']}" class="ipsButton {{if $tab === 'admin'}}ipsButton--primary{{else}}ipsButton--soft{{endif}} ipsButton--small">{lang="gdcatalog_compliance_tab_admin"} <span class="ipsBadge ipsBadge--neutral" style="margin-left:6px">{$counts['admin']}</span></a>
		</div>

		{{if $tab === 'new'}}
			{{if $counts['new'] === 0}}
				<div class="ipsEmptyMessage"><p>{lang="gdcatalog_compliance_empty_new"}</p></div>
			{{else}}
			<table class="ipsTable ipsTable_zebra" style="width:100%">
				<thead>
					<tr>
						<th>UPC</th>
						<th>Type</th>
						<th>Value</th>
						<th>Distributor</th>
						<th>First Seen</th>
						<th style="width:220px">Actions</th>
					</tr>
				</thead>
				<tbody>
					{{foreach $pendingFlags as $flag}}
					<tr>
						<td><code>{$flag['upc']}</code></td>
						<td>{$flag['flag_type']}</td>
						<td><strong>{$flag['flag_value']}</strong></td>
						<td>{$flag['distributor_id']}</td>
						<td>{$flag['first_seen_at']}</td>
						<td>
							<a href="{$flag['approve_url']}" class="ipsButton ipsButton--primary ipsButton--small">{lang="gdcatalog_compliance_approve"}</a>
							<a href="{$flag['reject_url']}" class="ipsButton ipsButton--negative ipsButton--small">{lang="gdcatalog_compliance_reject"}</a>
						</td>
					</tr>
					{{endforeach}}
				</tbody>
			</table>
			{{endif}}
		{{endif}}

		{{if $tab === 'conflicts'}}
			{{if $counts['conflicts'] === 0}}
				<div class="ipsEmptyMessage"><p>{lang="gdcatalog_compliance_empty_conflicts"}</p></div>
			{{else}}
			<table class="ipsTable ipsTable_zebra" style="width:100%">
				<thead>
					<tr>
						<th>UPC</th>
						<th>Field</th>
						<th>Current</th>
						<th>Incoming</th>
						<th>Auto-resolve</th>
						<th style="width:260px">Actions</th>
					</tr>
				</thead>
				<tbody>
					{{foreach $pendingConflicts as $conflict}}
					<tr>
						<td><code>{$conflict['upc']}</code></td>
						<td>{$conflict['field_name']}</td>
						<td>{$conflict['current_value']}</td>
						<td>{$conflict['incoming_value']}</td>
						<td>{$conflict['auto_resolve_at']}</td>
						<td>
							<a href="{$conflict['accept_url']}" class="ipsButton ipsButton--primary ipsButton--small">{lang="gdcatalog_compliance_accept_incoming"}</a>
							<a href="{$conflict['keep_url']}" class="ipsButton ipsButton--secondary ipsButton--small">{lang="gdcatalog_compliance_keep_existing"}</a>
							<a href="{$conflict['custom_url']}" class="ipsButton ipsButton--secondary ipsButton--small">{lang="gdcatalog_compliance_set_custom"}</a>
						</td>
					</tr>
					{{endforeach}}
				</tbody>
			</table>
			{{endif}}
		{{endif}}

		{{if $tab === 'locks'}}
			{{if $counts['locks'] === 0}}
				<div class="ipsEmptyMessage"><p>{lang="gdcatalog_compliance_empty_locks"}</p></div>
			{{else}}
			<table class="ipsTable ipsTable_zebra" style="width:100%">
				<thead>
					<tr>
						<th>UPC</th>
						<th>Field</th>
						<th>Locked Value</th>
						<th>Type</th>
						<th>Reason</th>
						<th>Locked At</th>
						<th style="width:120px">Actions</th>
					</tr>
				</thead>
				<tbody>
					{{foreach $allLocks as $lock}}
					<tr>
						<td><code>{$lock['upc']}</code></td>
						<td>{$lock['field_name']}</td>
						<td>{$lock['locked_value']}</td>
						<td>
							{{if $lock['is_hard_lock']}}
								<span class="ipsBadge ipsBadge--negative">{lang="gdcatalog_lock_type_hard"}</span>
							{{else}}
								<span class="ipsBadge ipsBadge--warning">{lang="gdcatalog_lock_type_distributor"}</span>
							{{endif}}
						</td>
						<td>{$lock['lock_reason']}</td>
						<td>{$lock['locked_at']}</td>
						<td>
							<a href="{$lock['unlock_url']}" class="ipsButton ipsButton--negative ipsButton--small" data-confirm>{lang="gdcatalog_lock_unlock"}</a>
						</td>
					</tr>
					{{endforeach}}
				</tbody>
			</table>
			{{endif}}
		{{endif}}

		{{if $tab === 'admin'}}
			{{if $counts['admin'] === 0}}
				<div class="ipsEmptyMessage"><p>{lang="gdcatalog_compliance_empty_admin"}</p></div>
			{{else}}
			<table class="ipsTable ipsTable_zebra" style="width:100%">
				<thead>
					<tr>
						<th>UPC</th>
						<th>Scope</th>
						<th>Type</th>
						<th>Value</th>
						<th>Set By</th>
						<th>Date</th>
						<th>Source</th>
					</tr>
				</thead>
				<tbody>
					{{foreach $adminFlags as $flag}}
					<tr>
						<td><code>{$flag['upc']}</code></td>
						<td>
							{{if $flag['listing_id']}}
								Listing
							{{else}}
								Product
							{{endif}}
						</td>
						<td>{$flag['flag_type']}</td>
						<td><strong>{$flag['flag_value']}</strong></td>
						<td>{$flag['admin_reviewed_by']}</td>
						<td>{$flag['admin_reviewed_at']}</td>
						<td>{$flag['source']}</td>
					</tr>
					{{endforeach}}
				</tbody>
			</table>
			{{endif}}
		{{endif}}

	</div>
</div>
TEMPLATE_EOT,
	],
	[
		'template_name' => 'dashboard',
		'template_data' => '$totalProducts, $activeProducts, $reviewProducts, $categoryCounts, $distributorStats, $osExists, $osStats, $pendingConflicts, $pendingCompliance, $lockedFields, $reindexQueue',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">
		<div style="display:flex;gap:16px;margin-bottom:24px">
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{expression="number_format($totalProducts)"}</div>
				<div>Total Products</div>
				<div style="color:#666">Active: {expression="number_format($activeProducts)"} | Review: {expression="number_format($reviewProducts)"}</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$pendingConflicts}</div>
				<div>Pending Conflicts</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$pendingCompliance}</div>
				<div>Pending Compliance Flags</div>
			</div>
		</div>

		<h2 class="ipsType_sectionHead" style="margin:0 0 12px">Distributor Feeds</h2>

		{{if count($distributorStats) === 0}}
			<div class="ipsEmptyMessage"><p>{lang="gdcatalog_dash_feeds_empty"}</p></div>
		{{else}}
		<table class="ipsTable ipsTable_zebra" style="width:100%">
			<thead><tr><th>#</th><th>Feed</th><th>Products</th><th>Status</th><th>Last Run</th><th>Last Status</th><th style="width:140px">Action</th></tr></thead>
			<tbody>
				{{foreach $distributorStats as $ds}}
				<tr>
					<td>{$ds['priority']}</td>
					<td><strong>{$ds['feed_name']}</strong></td>
					<td>{expression="number_format($ds['product_count'])"}</td>
					<td>
						{{if $ds['active']}}
							<span class="ipsBadge ipsBadge--positive">Active</span>
						{{else}}
							<span class="ipsBadge ipsBadge--neutral">Inactive</span>
						{{endif}}
					</td>
					<td>
						{{if $ds['last_run_start']}}
							{$ds['last_run_start']}
						{{else}}
							&mdash;
						{{endif}}
					</td>
					<td>
						{{if $ds['last_status']}}
							{$ds['last_status']}
						{{else}}
							&mdash;
						{{endif}}
					</td>
					<td>
						{{if $ds['active']}}
							<a href="{$ds['run_import_url']}" class="ipsButton ipsButton--primary ipsButton--small">Run Import</a>
						{{endif}}
					</td>
				</tr>
				{{endforeach}}
			</tbody>
		</table>
		{{endif}}
	</div>
</div>
TEMPLATE_EOT,
	],
	[
		'template_name' => 'productList',
		'template_data' => '$products, $categories, $search, $status, $catId, $imageStatus, $total, $pagination, $formActionUrl, $productCount, $categoryCount, $addProductUrl, $importCsvUrl, $downloadCsvTemplateUrl, $missingField, $catOptions, $bulkMoveUrl, $csrfKey, $totalMatching',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div style="display:flex;gap:8px;padding:10px 16px;border-bottom:1px solid var(--i-border-color, #e0e0e0)">
		<a href="{$addProductUrl}" class="ipsButton ipsButton--primary ipsButton--small">+ Add Product</a>
		<a href="{$importCsvUrl}" class="ipsButton ipsButton--secondary ipsButton--small">Import CSV</a>
		<a href="{$downloadCsvTemplateUrl}" class="ipsButton ipsButton--soft ipsButton--small">CSV Template</a>
	</div>
	<div class="ipsBox_body ipsPad">

		<div style="display:flex;gap:16px;margin-bottom:24px">
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{expression="number_format( (int) $total )"}</div>
				<div>Total Matching Products</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$productCount}</div>
				<div>Showing On This Page</div>
			</div>
			<div class="ipsBox" style="flex:1;padding:16px;text-align:center">
				<div style="font-size:2em;font-weight:bold">{$categoryCount}</div>
				<div>Categories</div>
			</div>
		</div>

		<form method="get" action="{$formActionUrl}" style="display:flex;gap:8px;padding:12px 16px;border-bottom:1px solid var(--i-border-color, #e0e0e0);align-items:center;flex-wrap:wrap">
			<input type="hidden" name="app" value="gdcatalog">
			<input type="hidden" name="module" value="catalog">
			<input type="hidden" name="controller" value="products">
			<input type="text" name="q" value="{$search}" placeholder="Search UPC, title, or brand..." class="ipsInput ipsInput--text" style="flex:1;min-width:200px">
			<select name="status" class="ipsInput ipsInput--select" style="min-width:140px">
				<option value="">All statuses</option>
				<option value="active" {{if $status === 'active'}}selected{{endif}}>Active</option>
				<option value="discontinued" {{if $status === 'discontinued'}}selected{{endif}}>Discontinued</option>
				<option value="admin_review" {{if $status === 'admin_review'}}selected{{endif}}>Admin Review</option>
				<option value="pending" {{if $status === 'pending'}}selected{{endif}}>Pending</option>
			</select>
			<select name="category" class="ipsInput ipsInput--select" style="min-width:160px">
				<option value="0">All categories</option>
				{{foreach $categories as $cat}}
					<option value="{$cat['id']}" {{if $catId === $cat['id']}}selected{{endif}}>{$cat['name']}</option>
				{{endforeach}}
			</select>
			<select name="image_status" class="ipsInput ipsInput--select" style="min-width:160px">
				<option value="">All images</option>
				<option value="missing" {{if $imageStatus === 'missing'}}selected{{endif}}>No Image</option>
				<option value="broken" {{if $imageStatus === 'broken'}}selected{{endif}}>Broken Image</option>
				<option value="ok" {{if $imageStatus === 'ok'}}selected{{endif}}>Image OK</option>
				<option value="unchecked" {{if $imageStatus === 'unchecked'}}selected{{endif}}>Not Checked</option>
			</select>
			<select name="missing_field" class="ipsInput ipsInput--select" style="min-width:180px">
				<option value="">All products</option>
				<optgroup label="Firearms">
					<option value="caliber" {{if $missingField === 'caliber'}}selected{{endif}}>Missing: Caliber</option>
					<option value="capacity" {{if $missingField === 'capacity'}}selected{{endif}}>Missing: Capacity</option>
					<option value="action_type" {{if $missingField === 'action_type'}}selected{{endif}}>Missing: Action Type</option>
					<option value="barrel_length" {{if $missingField === 'barrel_length'}}selected{{endif}}>Missing: Barrel Length</option>
					<option value="weight_lbs" {{if $missingField === 'weight_lbs'}}selected{{endif}}>Missing: Weight</option>
					<option value="overall_length" {{if $missingField === 'overall_length'}}selected{{endif}}>Missing: Overall Length</option>
					<option value="gun_type" {{if $missingField === 'gun_type'}}selected{{endif}}>Missing: Gun Type</option>
					<option value="safety_type" {{if $missingField === 'safety_type'}}selected{{endif}}>Missing: Safety</option>
					<option value="sight_type" {{if $missingField === 'sight_type'}}selected{{endif}}>Missing: Sights</option>
					<option value="stock_material" {{if $missingField === 'stock_material'}}selected{{endif}}>Missing: Stock</option>
					<option value="trigger_type" {{if $missingField === 'trigger_type'}}selected{{endif}}>Missing: Trigger</option>
					<option value="gauge" {{if $missingField === 'gauge'}}selected{{endif}}>Missing: Gauge</option>
				</optgroup>
				<optgroup label="Ammo">
					<option value="bullet_type" {{if $missingField === 'bullet_type'}}selected{{endif}}>Missing: Bullet Type</option>
					<option value="rounds_per_box" {{if $missingField === 'rounds_per_box'}}selected{{endif}}>Missing: Rounds/Box</option>
				</optgroup>
				<optgroup label="Optics">
					<option value="magnification" {{if $missingField === 'magnification'}}selected{{endif}}>Missing: Magnification</option>
				</optgroup>
				<optgroup label="General">
					<option value="image_url" {{if $missingField === 'image_url'}}selected{{endif}}>Missing: Image</option>
					<option value="brand" {{if $missingField === 'brand'}}selected{{endif}}>Missing: Brand</option>
					<option value="mpn" {{if $missingField === 'mpn'}}selected{{endif}}>Missing: MPN</option>
					<option value="metal_finish" {{if $missingField === 'metal_finish'}}selected{{endif}}>Missing: Finish</option>
				</optgroup>
			</select>
			<button type="submit" class="ipsButton ipsButton--primary ipsButton--small">Filter</button>
		</form>

		{{if $productCount === 0}}
			<div class="ipsEmptyMessage"><p>{lang="gdcatalog_products_empty"}</p></div>
		{{else}}
		<form method="post" action="{$bulkMoveUrl}" id="gdBulkForm">
			<input type="hidden" name="csrfKey" value="{$csrfKey}">
			<input type="hidden" name="bulk_mode" value="selected" id="gdBulkMode">

			<div id="gdBulkBar" style="display:none;padding:12px 16px;background:var(--i-color-info-bg, #e8f4fd);border:1px solid var(--i-color-info-border, #bee5eb);border-radius:4px;margin-bottom:12px;align-items:center;gap:10px;flex-wrap:wrap">
				<span><strong id="gdBulkCount">0</strong> {lang="gdcatalog_bulk_selected"}</span>
				<span id="gdBulkAllWrap" style="display:none">
					&mdash; <a href="#" id="gdBulkSelectAll">{lang="gdcatalog_bulk_select_all_matching"} (<span id="gdBulkTotalMatching">{$totalMatching}</span>)</a>
					<span id="gdBulkAllLabel" style="display:none">&mdash; {lang="gdcatalog_bulk_all_selected"}</span>
				</span>
				<span style="margin-left:auto;display:flex;gap:8px;align-items:center">
					<label>{lang="gdcatalog_bulk_move_to"}:</label>
					<select name="bulk_target_category" class="ipsInput ipsInput--select" style="min-width:200px">
						<option value="0">{lang="gdcatalog_bulk_choose_category"}</option>
						{{foreach $catOptions as $groupName => $groupChildren}}
							<optgroup label="{$groupName}">
								{{foreach $groupChildren as $cid => $cname}}
									<option value="{$cid}">{$cname}</option>
								{{endforeach}}
							</optgroup>
						{{endforeach}}
					</select>
					<button type="submit" class="ipsButton ipsButton--primary ipsButton--small">{lang="gdcatalog_bulk_apply"}</button>
				</span>
			</div>

		<table class="ipsTable ipsTable_zebra" style="width:100%" id="gdBulkTable" data-total-matching="{$totalMatching}">
			<thead>
				<tr>
					<th style="width:40px"><input type="checkbox" id="gdMasterCheckbox"></th>
					<th>{lang="gdcatalog_product_upc"}</th>
					<th style="width:60px">Image</th>
					<th>{lang="gdcatalog_product_title"}</th>
					<th>{lang="gdcatalog_product_brand"}</th>
					<th>{lang="gdcatalog_product_caliber"}</th>
					<th>{lang="gdcatalog_product_msrp"}</th>
					<th>{lang="gdcatalog_product_status"}</th>
					<th>Missing</th>
					<th>{lang="gdcatalog_product_primary_source"}</th>
					<th style="width:180px">Actions</th>
				</tr>
			</thead>
			<tbody>
				{{foreach $products as $product}}
				<tr>
					<td><input type="checkbox" name="bulk_upc[]" value="{$product['upc']}" class="gdBulkCheckbox"></td>
					<td><code>{$product['upc']}</code></td>
					<td>
						{{if $product['image_url']}}
							{{if $product['image_http_status'] >= 400}}
								<span class="ipsBadge ipsBadge--negative" title="Broken image">&#10007;</span>
							{{else}}
								<img src="{$product['image_url']}" style="width:40px;height:40px;object-fit:contain" loading="lazy">
							{{endif}}
						{{else}}
							<span class="ipsBadge ipsBadge--neutral" title="No image">&mdash;</span>
						{{endif}}
					</td>
					<td>{$product['title']}</td>
					<td>{$product['brand']}</td>
					<td>{$product['caliber']}</td>
					<td>{$product['msrp']}</td>
					<td>
						{{if $product['record_status'] === 'active'}}
							<span class="ipsBadge ipsBadge--positive">{lang="gdcatalog_status_active"}</span>
						{{elseif $product['record_status'] === 'admin_review'}}
							<span class="ipsBadge ipsBadge--warning">{lang="gdcatalog_status_admin_review"}</span>
						{{elseif $product['record_status'] === 'discontinued'}}
							<span class="ipsBadge ipsBadge--negative">{lang="gdcatalog_status_discontinued"}</span>
						{{else}}
							<span class="ipsBadge ipsBadge--neutral">{lang="gdcatalog_status_pending"}</span>
						{{endif}}
					</td>
					<td style="font-size:0.75em">
						{{if count($product['missing_fields']) === 0}}
							<span class="ipsBadge ipsBadge--positive">Complete</span>
						{{else}}
							{{foreach $product['missing_fields'] as $mf}}
							<span class="ipsBadge ipsBadge--warning" style="margin:1px">{$mf}</span>
							{{endforeach}}
						{{endif}}
					</td>
					<td>{$product['primary_source']}</td>
					<td>
						<a href="{$product['edit_url']}" class="ipsButton ipsButton--primary ipsButton--small">Edit</a>
						{{if $product['record_status'] === 'admin_review'}}
							<a href="{$product['approve_url']}" class="ipsButton ipsButton--secondary ipsButton--small">Approve</a>
						{{endif}}
					</td>
				</tr>
				{{endforeach}}
			</tbody>
		</table>
		</form>
		{{endif}}

		<div style="margin-top:16px">{$pagination|raw}</div>

	</div>
</div>
TEMPLATE_EOT,
	],
	[
		'template_name' => 'uploadFeedForm',
		'template_data' => '$uploadActionUrl, $csrfKey, $backUrl, $feedName',
		'template_content' => <<<'TEMPLATE_EOT'
<div class="ipsBox ipsPull">
	<div class="ipsBox_body ipsPad">
		<h2 style="margin:0 0 16px">Upload Feed File: {$feedName}</h2>
		<p class="ipsType_light" style="margin-bottom:16px">Select an XML, JSON, or CSV feed file to upload. After uploading, use the Run Import button on the feed list to process it.</p>
		<form method="post" action="{$uploadActionUrl}" enctype="multipart/form-data">
			<input type="hidden" name="csrfKey" value="{$csrfKey}">
			<div style="margin-bottom:16px">
				<label style="display:block;font-weight:600;margin-bottom:8px">Feed File (XML, JSON, or CSV)</label>
				<input type="file" name="feed_file" accept=".xml,.json,.csv" required>
			</div>
			<div style="display:flex;gap:8px">
				<button type="submit" class="ipsButton ipsButton--primary">Upload File</button>
				<a href="{$backUrl}" class="ipsButton ipsButton--soft">Cancel</a>
			</div>
		</form>
	</div>
</div>
TEMPLATE_EOT,
	],
];

\IPS\Db::i()->delete( 'core_theme_templates', [
    'template_set_id=? AND template_app=? AND template_location=? AND template_group=?',
    1, 'gdcatalog', 'admin', 'catalog',
]);

foreach ( $gdcatalogTemplates as $tpl )
{
    try {
        \IPS\Db::i()->insert( 'core_theme_templates', [
            'template_set_id'   => 1,
            'template_app'      => 'gdcatalog',
            'template_location' => 'admin',
            'template_group'    => 'catalog',
            'template_name'     => $tpl['template_name'],
            'template_data'     => $tpl['template_data'],
            'template_content'  => $tpl['template_content'],
        ]);
    } catch ( \Exception $e ) {}
}

try
{
    \IPS\Db::i()->update( 'core_tasks', [ 'enabled' => 1 ], [ 'app=? AND `key`=?', 'core', 'queue' ] );
}
catch ( \Throwable ) {}

/* v1.0.122 (Phase 6): after the $gdcatalogTemplates delete/insert pass
 * above, walk dev/html/ and REPLACE INTO for every .phtml file present.
 * This keeps fresh installs and upgrades converging on the same set of
 * templates without duplicating template bodies inside a giant nowdoc
 * array (rule #52). Adds any template that exists in the checked-out
 * repo but not in $gdcatalogTemplates (feedList is in the array; new
 * templates like testSourcePreview are picked up here). Idempotent —
 * REPLACE ensures re-running just overwrites with current dev/html
 * bodies.
 */
try
{
    $devRoot = \IPS\ROOT_PATH . '/applications/gdcatalog/dev/html';
    if ( is_dir( $devRoot ) )
    {
        $it = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $devRoot, \FilesystemIterator::SKIP_DOTS ) );
        foreach ( $it as $f )
        {
            if ( !$f->isFile() || strtolower( $f->getExtension() ) !== 'phtml' ) { continue; }
            $rel = trim( str_replace( $devRoot, '', $f->getPathname() ), "/\\" );
            $parts = preg_split( '#[/\\\\]#', $rel );
            if ( count( $parts ) < 3 ) { continue; }
            $location = (string) $parts[0];
            $group    = (string) $parts[1];
            $name     = pathinfo( (string) end( $parts ), PATHINFO_FILENAME );
            $raw      = (string) @file_get_contents( $f->getPathname() );
            if ( $raw === '' ) { continue; }
            $params = '';
            if ( preg_match( '#<ips:template\s+parameters="([^"]*)"\s*/>#', $raw, $m ) )
            {
                $params = (string) $m[1];
            }
            $content = preg_replace( '#^\s*<ips:template[^>]*/>\s*\r?\n?#', '', $raw, 1 );

            try
            {
                \IPS\Db::i()->replace( 'core_theme_templates', [
                    'template_set_id'   => 1,
                    'template_app'      => 'gdcatalog',
                    'template_location' => $location,
                    'template_group'    => $group,
                    'template_name'     => $name,
                    'template_data'     => $params,
                    'template_updated'  => time(),
                    'template_version'  => '1.0.122',
                    'template_content'  => (string) $content,
                ] );
            }
            catch ( \Throwable ) {}
        }
    }
}
catch ( \Throwable ) {}
